fn is_root(&self) -> bool {
        self.mnt.is_root() && self.dentry.is_root_of_mount()
    }