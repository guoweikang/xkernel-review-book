fn getattr(&self) -> VfsResult<Metadata> {
        let mut metadata =
            self.getattr_nosec(GetattrRequestMask::empty(), GetattrQueryFlags::empty())?;
        metadata.device = self.mnt.synthetic_device_id();
        Ok(metadata)
    }