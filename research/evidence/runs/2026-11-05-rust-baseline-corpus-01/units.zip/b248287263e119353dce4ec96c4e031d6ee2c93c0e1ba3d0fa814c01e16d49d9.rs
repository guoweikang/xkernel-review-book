fn file_accessed(&self) {
        if !self.flags().contains(OpenFlags::NO_ATIME) {
            self.path().touch_atime();
        }
    }