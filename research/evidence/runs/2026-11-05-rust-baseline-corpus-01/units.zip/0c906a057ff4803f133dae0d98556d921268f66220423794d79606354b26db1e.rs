fn write_end_set_size(&self, len: u64) -> VfsResult<()> {
        let inode = self.inode().ok_or(VfsError::InvalidInput)?;
        if len > inode.size() {
            inode.set_size(len);
        }
        Ok(())
    }