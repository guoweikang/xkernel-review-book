fn set_times(
        &self,
        atime: Option<SetattrTime>,
        mtime: Option<SetattrTime>,
        cred: &Cred,
    ) -> VfsResult<()> {
        if atime.is_none() && mtime.is_none() {
            return Ok(());
        }

        self.check_writable_mount()?;
        let metadata = self.metadata();
        let is_owner = cred.fsuid() == metadata.uid;
        let is_touch = matches!(
            (atime, mtime),
            (Some(SetattrTime::Current(_)), Some(SetattrTime::Current(_)))
        );
        if !is_touch {
            if !is_owner && !cred.has_cap_fowner() {
                return Err(VfsError::OperationNotPermitted);
            }
        } else if !is_owner && !cred.has_cap_fowner() {
            self.permission(Permission::MAY_WRITE, cred)?;
        }

        self.dentry.update_metadata(MetadataUpdate {
            atime: atime.map(SetattrTime::value),
            mtime: mtime.map(SetattrTime::value),
            ..Default::default()
        })
    }