fn set_private_data<T>(&self, value: Arc<T>)
    where
        T: Any + Send + Sync + 'static,
    {
        self.private_data.lock().insert_arc(value);
    }