fn simple_statfs(fs_type: u32) -> StatFs {
    StatFs {
        fs_type,
        block_size: PAGE_SIZE_4K as u32,
        blocks: 0,
        blocks_free: 0,
        blocks_available: 0,
        file_count: 0,
        free_file_count: 0,
        name_length: MAX_NAME_LEN as u32,
        fragment_size: 0,
    }
}