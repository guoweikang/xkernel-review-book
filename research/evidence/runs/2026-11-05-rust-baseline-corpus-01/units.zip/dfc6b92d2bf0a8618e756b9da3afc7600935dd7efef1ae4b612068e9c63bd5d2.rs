fn poll(&self, _file: &VfsFile) -> Option<IoEvents> {
        None
    }