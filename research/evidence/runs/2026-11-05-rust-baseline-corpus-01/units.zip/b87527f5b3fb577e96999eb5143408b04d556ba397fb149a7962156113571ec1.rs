fn weak_inode(&self) -> Weak<VfsInode> {
        Arc::downgrade(&self.inode())
    }