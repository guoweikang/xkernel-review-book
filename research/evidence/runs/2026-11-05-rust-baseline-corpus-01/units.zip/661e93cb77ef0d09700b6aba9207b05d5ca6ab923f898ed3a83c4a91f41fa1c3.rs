fn children_count(&self) -> usize {
        self.0.children_count()
    }