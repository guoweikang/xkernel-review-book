const fn new(get_tree: GetTreeFn) -> Self {
        Self {
            get_tree,
            reconfigure: None,
        }
    }