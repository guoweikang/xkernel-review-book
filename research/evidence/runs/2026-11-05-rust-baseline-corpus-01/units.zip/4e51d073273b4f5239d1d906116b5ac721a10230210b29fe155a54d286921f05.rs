fn alloc_clone(
        &self,
        flags: FMode,
        open_flags: OpenFlags,
        f_op: Arc<dyn FileOperations>,
    ) -> VfsResult<Arc<Self>> {
        let mut file = VfsFileBuilder::cloned_from(self, flags, open_flags, f_op);
        file.mark_opened()?;
        file.finish()
    }