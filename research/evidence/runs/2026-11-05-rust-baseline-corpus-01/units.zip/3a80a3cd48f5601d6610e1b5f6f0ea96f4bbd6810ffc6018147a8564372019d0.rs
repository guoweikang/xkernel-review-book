fn generic_read_dir(_buf: &mut [u8], _offset: u64) -> VfsResult<usize> {
    Err(VfsError::IsADirectory)
}