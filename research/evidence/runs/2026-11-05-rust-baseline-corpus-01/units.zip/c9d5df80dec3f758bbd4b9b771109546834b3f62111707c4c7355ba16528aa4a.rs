fn cancel_waiter(&self, wake: &mut WakeQueue) {
        let discarded = {
            let mut blocked = BLOCKED_OWNERS.lock();
            let parent = self
                .0
                .state(&mut blocked)
                .blocker
                .take()
                .and_then(|weak| weak.upgrade());
            let discarded = if let Some(parent) = parent {
                // SAFETY: the blocker relation records membership in this
                // exact list, and the global guard serializes all list edits.
                let removed = unsafe {
                    parent
                        .state(&mut blocked)
                        .requests
                        .cursor_mut_from_ptr(Arc::as_ptr(&self.0))
                        .remove()
                };
                if removed.is_some() {
                    parent.note_pop();
                }
                self.0.state(&mut blocked).wait.take()
            } else {
                // A detached request may already belong to a notification
                // list. Leave its registration for that list's consumer.
                None
            };
            remove_blocked_owner(&mut blocked, &self.0);
            self.0.wake_blocked(&mut blocked, wake);
            discarded
        };
        drop(discarded);
    }