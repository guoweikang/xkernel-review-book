fn visible_len(&self) -> VfsResult<u64> {
        self.inode()
            .map(|inode| inode.size())
            .ok_or(VfsError::InvalidInput)
    }