fn write_iter(&self, iocb: &mut Kiocb<'_>, iter: &mut IovIterSource<'_>) -> VfsResult<usize> {
        scalar_write_iter(iocb, iter, |file, buf, offset| {
            self.write(file, buf, offset)
        })
    }