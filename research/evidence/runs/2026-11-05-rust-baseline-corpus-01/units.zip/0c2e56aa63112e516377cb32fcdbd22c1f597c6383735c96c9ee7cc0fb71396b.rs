fn dentry(&self) -> &Dentry {
        &self.dentry
    }