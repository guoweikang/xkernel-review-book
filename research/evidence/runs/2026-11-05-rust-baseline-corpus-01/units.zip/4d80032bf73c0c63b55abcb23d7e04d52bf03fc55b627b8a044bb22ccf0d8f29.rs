fn was_created(&self) -> bool {
        self.mode().contains(FMode::CREATED)
    }