fn ioctl(
        &self,
        _file: &VfsFile,
        _cred: &kcred::Cred,
        _cmd: u32,
        _arg: usize,
    ) -> VfsResult<usize> {
        Err(VfsError::NotATty)
    }