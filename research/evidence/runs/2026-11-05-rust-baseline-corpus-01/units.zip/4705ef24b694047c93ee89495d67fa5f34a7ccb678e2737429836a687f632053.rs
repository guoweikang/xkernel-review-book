fn simple_empty(dentry: &Dentry) -> VfsResult<bool> {
    Ok(!dentry.has_positive_children())
}