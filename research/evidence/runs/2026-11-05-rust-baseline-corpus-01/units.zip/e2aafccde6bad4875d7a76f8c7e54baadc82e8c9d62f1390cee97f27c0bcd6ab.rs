fn ptr_eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.mnt, &other.mnt) && self.dentry.ptr_eq(&other.dentry)
    }