fn posix<T>(files: &T) -> Self {
        Self::Posix(core::ptr::from_ref(files).addr())
    }