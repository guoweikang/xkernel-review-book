fn fallocate(&self, flags: FallocateFlags, offset: u64, len: u64) -> VfsResult<()> {
        let inode = self.inode();
        let operations = self.operations();
        if !operations.supported_fallocate_modes().contains(flags) {
            return Err(VfsError::from(LinuxError::EOPNOTSUPP));
        }
        let _data_guard = inode.lock_data();
        let _invalidate_guard = self.mapping().lock_invalidate_exclusive();
        operations.fallocate(self, flags, offset, len)
    }