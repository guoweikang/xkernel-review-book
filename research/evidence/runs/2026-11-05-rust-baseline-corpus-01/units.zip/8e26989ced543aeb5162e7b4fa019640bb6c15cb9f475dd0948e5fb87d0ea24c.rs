fn requests_no_controlling_tty(&self) -> bool {
        self.flags.contains(OpenFlags::NO_CONTROLLING_TTY)
    }