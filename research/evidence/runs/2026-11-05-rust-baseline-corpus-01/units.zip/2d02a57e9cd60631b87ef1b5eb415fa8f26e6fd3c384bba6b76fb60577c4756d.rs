fn upgrade(&self) -> Option<Blocker> {
        self.0.upgrade().map(Blocker)
    }