fn write(&self, buf: &[u8]) -> VfsResult<usize> {
        let mut iter = iov_iter_kvec_source(buf);
        self.write_iter(&mut iter)
    }