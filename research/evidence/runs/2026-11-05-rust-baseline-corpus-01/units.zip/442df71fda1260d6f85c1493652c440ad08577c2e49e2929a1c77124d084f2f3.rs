fn file_update_time(&self) -> VfsResult<()> {
        self.path().update_cmtime()
    }