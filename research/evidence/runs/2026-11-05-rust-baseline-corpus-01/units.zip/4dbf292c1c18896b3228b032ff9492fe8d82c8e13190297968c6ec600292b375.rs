fn inode(&self) -> VfsResult<&Arc<VfsInode>> {
        Ok(self.location()?.inode())
    }