fn lock_invalidate_exclusive(&self) -> RwLockWriteGuard<'_, ()> {
        self.invalidate_lock.write()
    }