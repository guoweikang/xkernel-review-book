fn max_file_size(&self) -> u64 {
        self.path().max_file_size()
    }