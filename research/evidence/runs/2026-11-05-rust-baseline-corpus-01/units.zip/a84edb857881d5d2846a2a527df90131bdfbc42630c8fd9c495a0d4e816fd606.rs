fn end(&self) -> i64 {
        self.bounds().1
    }