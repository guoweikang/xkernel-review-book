fn new_root(root_fs: &Arc<SuperBlock>, user_ns: Arc<UserNamespace>) -> Arc<Self> {
        let root = Mount::new_root(root_fs);
        let namespace = Arc::new(Self {
            id: NamespaceId::new(),
            user_ns,
            root: root.clone(),
            mounts: Mutex::default(),
        });
        namespace.mounts.lock().insert(root.mount_id(), root);
        namespace
    }