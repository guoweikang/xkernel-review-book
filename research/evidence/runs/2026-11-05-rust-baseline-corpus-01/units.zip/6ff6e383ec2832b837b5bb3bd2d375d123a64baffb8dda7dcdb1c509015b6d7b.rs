const fn cred(&self) -> &'a kcred::Cred {
        self.cred
    }