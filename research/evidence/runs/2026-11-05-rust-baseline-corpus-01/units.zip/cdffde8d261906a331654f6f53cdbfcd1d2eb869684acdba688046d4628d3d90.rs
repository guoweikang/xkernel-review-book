fn supports_read(&self) -> bool {
        false
    }