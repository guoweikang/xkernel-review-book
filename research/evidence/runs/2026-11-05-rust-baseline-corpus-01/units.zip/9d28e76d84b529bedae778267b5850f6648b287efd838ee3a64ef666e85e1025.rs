fn hold_wait_tree() -> impl Sized {
    BLOCKED_OWNERS.lock()
}