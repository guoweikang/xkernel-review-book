fn visible_root_path(&self) -> Path {
        self.root_path().resolve_final_mount()
    }