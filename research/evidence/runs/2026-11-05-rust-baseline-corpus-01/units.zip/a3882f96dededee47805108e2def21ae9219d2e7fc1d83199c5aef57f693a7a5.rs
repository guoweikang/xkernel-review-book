fn with_residency(
        inode: WeakVfsInode,
        ops: &'static dyn AddressSpaceOperations,
        residency: Option<Arc<dyn CacheResidency>>,
    ) -> Arc<Self> {
        Arc::new(Self {
            inode,
            ops,
            object_id: VmObjectId::File(FileObjectId::from_raw(
                NEXT_ADDRESS_SPACE_ID.fetch_add(1, Ordering::Relaxed),
            )),
            invalidate_lock: RwLock::new(()),
            views: Mutex::new(BTreeMap::new()),
            i_pages: MappingPages::with_residency(residency),
        })
    }