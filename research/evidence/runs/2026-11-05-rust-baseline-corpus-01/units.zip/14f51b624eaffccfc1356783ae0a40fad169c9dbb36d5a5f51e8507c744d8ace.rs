fn vfs_open(mut self, path: Path) -> VfsResult<Arc<VfsFile>> {
        self.bind_location(FileLocation::from_path(path));
        self.do_dentry_open()
    }