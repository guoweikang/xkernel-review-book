fn pipe_generation(&self) -> u64 {
        self.pipe_generation
    }