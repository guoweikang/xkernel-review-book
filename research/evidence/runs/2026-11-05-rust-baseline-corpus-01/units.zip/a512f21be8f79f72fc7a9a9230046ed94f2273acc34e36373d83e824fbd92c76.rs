fn remount(
        &self,
        target: &Path,
        context: &mut FsContext<'_>,
        mount_flags: MountFlags,
    ) -> VfsResult<()> {
        let mounts = self.mounts.lock();
        let mount = Self::registered_mount_at(&mounts, target)?;
        mount.super_block().reconfigure(context)?;
        mount.set_flags(mount_flags);
        Ok(())
    }