fn statfs(&self, super_block: &SuperBlock) -> VfsResult<StatFs> {
        Ok(simple_statfs(super_block.magic()))
    }