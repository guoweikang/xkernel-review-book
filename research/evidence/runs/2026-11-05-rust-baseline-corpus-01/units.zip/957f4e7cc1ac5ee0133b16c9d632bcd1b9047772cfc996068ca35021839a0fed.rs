fn length(&self) -> i64 {
        if self.end() == i64::MAX {
            0
        } else {
            self.end() - self.start() + 1
        }
    }