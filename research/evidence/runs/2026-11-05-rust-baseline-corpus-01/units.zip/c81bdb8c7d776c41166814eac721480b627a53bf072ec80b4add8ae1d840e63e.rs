fn can_poll(&self) -> bool {
        self.poll_handler().is_some()
    }