fn set_flags(&self, flags: MountFlags) {
        self.mnt.set_flags(flags);
    }