fn set_nonblocking(&self, flag: bool) {
        if flag {
            self.flags
                .fetch_or(OpenFlags::NONBLOCK.bits(), Ordering::AcqRel);
        } else {
            self.flags
                .fetch_and(!OpenFlags::NONBLOCK.bits(), Ordering::AcqRel);
        }
    }