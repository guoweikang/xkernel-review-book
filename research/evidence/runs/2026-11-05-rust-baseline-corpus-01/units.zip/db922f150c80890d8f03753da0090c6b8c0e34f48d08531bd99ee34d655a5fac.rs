const fn data(&self) -> Option<&'a [u8]> {
        self.data
    }