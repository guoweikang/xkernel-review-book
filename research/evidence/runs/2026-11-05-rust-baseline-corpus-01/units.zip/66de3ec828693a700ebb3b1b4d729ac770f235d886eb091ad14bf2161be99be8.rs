fn record(&self) -> FileLock {
        // SAFETY: this unique owner is detached from every installed list;
        // wait-tree handles neither read nor modify installed ranges.
        unsafe { self.0.record() }
    }