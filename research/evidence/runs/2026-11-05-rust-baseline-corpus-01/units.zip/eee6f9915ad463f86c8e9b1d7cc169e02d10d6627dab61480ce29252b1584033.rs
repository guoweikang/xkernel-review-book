const fn sb_flags_mask(&self) -> SuperBlockFlags {
        self.sb_flags_mask
    }