fn permission(&self, permission: Permission, cred: &Cred) -> VfsResult<()> {
        self.inode().permission(permission, cred)
    }