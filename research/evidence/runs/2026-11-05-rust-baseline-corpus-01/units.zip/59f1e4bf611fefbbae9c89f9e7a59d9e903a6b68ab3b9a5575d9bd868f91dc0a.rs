fn shrink_after_io_error(&mut self) {
        self.ra_pages /= 4;
    }