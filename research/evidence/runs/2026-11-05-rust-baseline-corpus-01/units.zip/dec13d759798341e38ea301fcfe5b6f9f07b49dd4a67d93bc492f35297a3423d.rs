fn parent(&self) -> Option<Self> {
        if !self.dentry.ptr_eq(&self.mnt.mnt.mnt_root) {
            return Some(self.with_dentry(self.dentry.parent()?));
        }
        self.mnt.location()?.parent()
    }