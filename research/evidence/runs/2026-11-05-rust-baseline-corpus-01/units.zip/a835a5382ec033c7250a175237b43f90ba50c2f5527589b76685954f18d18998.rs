fn path(&self) -> &Path {
        self.location.path()
    }