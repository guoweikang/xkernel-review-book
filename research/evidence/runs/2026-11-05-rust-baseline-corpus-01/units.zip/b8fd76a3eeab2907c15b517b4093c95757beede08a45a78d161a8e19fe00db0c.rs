fn sync_readahead(&self, offset: u64, count: usize, file_len: u64) -> u64 {
        let end = offset.saturating_add(count as u64).min(file_len);
        self.prepare_readahead(
            offset / PAGE_SIZE_4K as u64..end.div_ceil(PAGE_SIZE_4K as u64),
            None,
            file_len,
        );
        end
    }