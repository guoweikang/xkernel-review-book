const fn pages_skipped(self) -> usize {
        self.pages_skipped
    }