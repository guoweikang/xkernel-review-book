fn is_blocked(&self) -> bool {
        let mut guard = BLOCKED_OWNERS.lock();
        let blocked = self.0.state(&mut guard);
        blocked.blocker.is_some() || blocked.wait.is_some()
    }