fn is_regular_file(&self) -> bool {
        self.node_type() == NodeType::RegularFile
    }