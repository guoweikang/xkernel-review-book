const fn sync_mode(self) -> WritebackSyncMode {
        self.sync_mode
    }