fn size(&self) -> u64 {
        let inode = self.inode();
        if inode.node_type() == NodeType::BlockDevice
            && let Some(claim) = self.private_data_get::<block::BlockDeviceClaim>()
        {
            return claim.device().size();
        }
        inode.size()
    }