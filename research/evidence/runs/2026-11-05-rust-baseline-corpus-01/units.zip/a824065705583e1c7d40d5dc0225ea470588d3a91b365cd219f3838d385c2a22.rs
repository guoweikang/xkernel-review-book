fn register(
        &self,
        context: &mut PollContext<'_>,
        events: IoEvents,
    ) -> Result<(), PollRegisterError> {
        if events.intersects(self.events) {
            context.register_weak(&self.source)?;
        }
        Ok(())
    }