fn from_path_state(
        path: Path,
        flags: FMode,
        open_flags: OpenFlags,
        f_op: Arc<dyn FileOperations>,
        cred: Arc<Cred>,
    ) -> Self {
        let mut file = Self::empty(flags, open_flags, cred);
        file.bind_location(FileLocation::from_path(path));
        file.install_operations(f_op);
        file
    }