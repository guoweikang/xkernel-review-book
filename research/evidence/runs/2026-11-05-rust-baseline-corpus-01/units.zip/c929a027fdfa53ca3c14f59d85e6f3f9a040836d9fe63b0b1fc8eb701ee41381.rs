fn advance(&mut self, len: usize) {
        self.ki_pos = self.ki_pos.saturating_add(len as u64);
    }