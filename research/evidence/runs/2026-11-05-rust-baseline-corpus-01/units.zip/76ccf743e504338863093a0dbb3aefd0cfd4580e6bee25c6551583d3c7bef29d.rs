fn fsync(&self, _file: &VfsFile, _data_only: bool) -> VfsResult<()> {
        Ok(())
    }