fn parent_matches(&self, other: &Arc<LockNode>) -> bool {
        self.0
            .state(&mut BLOCKED_OWNERS.lock())
            .blocker
            .as_ref()
            .is_some_and(|parent| Weak::ptr_eq(parent, &Arc::downgrade(other)))
    }