fn root_path(&self) -> Path {
        self.root.root_path()
    }