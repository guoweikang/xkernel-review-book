fn sync_filesystem(&self) -> VfsResult<()> {
        self.super_block().sync_fs()
    }