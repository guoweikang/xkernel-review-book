fn mode(&self) -> FMode {
        FMode::from_bits_truncate(self.mode.load(Ordering::Acquire))
    }