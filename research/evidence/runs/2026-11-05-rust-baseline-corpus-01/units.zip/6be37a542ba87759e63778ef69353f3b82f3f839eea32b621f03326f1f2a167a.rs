fn mapping(&self) -> &AddressSpace {
        self.address_space
    }