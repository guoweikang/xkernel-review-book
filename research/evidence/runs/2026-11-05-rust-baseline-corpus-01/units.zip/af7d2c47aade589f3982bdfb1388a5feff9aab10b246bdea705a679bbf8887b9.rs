fn empty(flags: FMode, open_flags: OpenFlags, cred: Arc<Cred>) -> Self {
        Self {
            cred,
            mode: flags,
            operations: None,
            location: None,
            private_data: TypeMap::default(),
            flags: open_flags,
            position: 0,
            pipe_generation: 0,
            created_under: None,
        }
    }