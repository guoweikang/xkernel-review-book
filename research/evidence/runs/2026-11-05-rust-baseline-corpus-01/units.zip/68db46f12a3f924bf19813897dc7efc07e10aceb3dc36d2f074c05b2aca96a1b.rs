fn ki_pos(&self) -> u64 {
        self.ki_pos
    }