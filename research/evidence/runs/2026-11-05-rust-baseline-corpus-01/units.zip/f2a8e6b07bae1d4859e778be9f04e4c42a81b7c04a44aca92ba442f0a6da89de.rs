fn generic_file_write_iter_with_checks(
        &mut self,
        iter: &mut IovIterSource<'_>,
        checks: impl FnOnce(u64, &mut usize) -> VfsResult<()>,
    ) -> VfsResult<usize> {
        let mapping = self.file().mapping();
        mapping.write_iter_with_checks(self, iter, checks)
    }