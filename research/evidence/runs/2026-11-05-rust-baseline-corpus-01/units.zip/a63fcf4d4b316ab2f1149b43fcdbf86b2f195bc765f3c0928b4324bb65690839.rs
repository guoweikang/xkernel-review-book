fn test_lock(
        &self,
        file: &VfsFile,
        request: &crate::FileLock,
    ) -> VfsResult<Option<crate::FileLock>> {
        Ok(file
            .inode()
            .existing_file_locks()
            .and_then(|context| context.test(request)))
    }