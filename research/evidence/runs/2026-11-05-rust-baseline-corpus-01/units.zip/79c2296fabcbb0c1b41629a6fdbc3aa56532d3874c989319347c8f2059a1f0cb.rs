fn from_path(path: Path) -> Self {
        let inode = path.inode();
        let mapping = inode.address_space();
        Self {
            path,
            inode,
            mapping,
        }
    }