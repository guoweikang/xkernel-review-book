const fn sb_flags(&self) -> SuperBlockFlags {
        self.sb_flags
    }