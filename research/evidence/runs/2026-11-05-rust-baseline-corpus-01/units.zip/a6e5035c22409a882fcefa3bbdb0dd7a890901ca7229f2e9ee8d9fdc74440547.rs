fn test_lock(&self, request: &crate::FileLock) -> VfsResult<Option<crate::FileLock>> {
        self.operations().test_lock(self, request)
    }