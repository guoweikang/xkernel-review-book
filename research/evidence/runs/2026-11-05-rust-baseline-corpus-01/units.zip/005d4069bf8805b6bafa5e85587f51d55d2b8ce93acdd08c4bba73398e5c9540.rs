fn is_symlink(&self) -> bool {
        self.node_type() == NodeType::Symlink
    }