fn mapping(&self) -> &Arc<AddressSpace> {
        &self.mapping
    }