fn is_same_inode(&self, other: &Self) -> bool {
        self.dentry.is_same_inode(&other.dentry)
    }