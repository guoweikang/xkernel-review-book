fn mapping(&self) -> &Arc<AddressSpace> {
        self.location.mapping()
    }