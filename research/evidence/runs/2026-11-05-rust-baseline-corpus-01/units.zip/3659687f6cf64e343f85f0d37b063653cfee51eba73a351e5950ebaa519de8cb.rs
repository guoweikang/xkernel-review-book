fn new(source: WeakPollSet, events: IoEvents) -> Self {
        Self { source, events }
    }