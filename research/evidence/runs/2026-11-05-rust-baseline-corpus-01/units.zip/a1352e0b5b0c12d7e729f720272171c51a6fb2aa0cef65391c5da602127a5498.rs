fn drop(&mut self) {
        if let Some(address_space) = self.address_space.upgrade() {
            address_space.unregister_view(self.id);
        }
    }