fn set_operations(&mut self, operations: &'static FsContextOperations) {
        self.operations = Some(operations);
    }