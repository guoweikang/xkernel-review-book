const fn device_backed(name: &'static str, init_fs_context: InitFsContextFn) -> Self {
        Self {
            name,
            init_fs_context,
            fs_flags: FileSystemTypeFlags::REQUIRES_DEV,
        }
    }