fn ofd(file: &VfsFile) -> Self {
        Self::Ofd(core::ptr::from_ref(file).addr())
    }