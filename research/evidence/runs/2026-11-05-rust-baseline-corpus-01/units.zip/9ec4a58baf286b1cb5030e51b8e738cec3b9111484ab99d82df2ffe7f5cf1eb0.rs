fn getattr_nosec(
        &self,
        request_mask: GetattrRequestMask,
        query_flags: GetattrQueryFlags,
    ) -> VfsResult<Metadata> {
        self.inode().getattr(self, request_mask, query_flags)
    }