fn read_folio(&self, _mapping: &AddressSpace, _folio: FolioRead) -> VfsResult<()> {
        Err(VfsError::NoSuchDevice)
    }