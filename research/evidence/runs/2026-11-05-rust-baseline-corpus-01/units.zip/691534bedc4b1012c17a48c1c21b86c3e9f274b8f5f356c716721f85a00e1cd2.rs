fn len(&self) -> usize {
        self.0.iter().count()
    }