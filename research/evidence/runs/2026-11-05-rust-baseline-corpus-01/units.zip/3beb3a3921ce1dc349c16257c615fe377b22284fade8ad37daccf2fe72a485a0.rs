fn is_readonly(&self) -> bool {
        self.flags().contains(MountFlags::RDONLY)
    }