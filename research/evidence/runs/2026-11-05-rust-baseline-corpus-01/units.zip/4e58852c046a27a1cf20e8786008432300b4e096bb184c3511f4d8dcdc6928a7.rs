fn window(&self) -> (Range<PageIndex>, Option<PageIndex>) {
        let end = self.start.saturating_add(self.size_pages);
        (self.start..end, Some(end - self.async_size_pages))
    }