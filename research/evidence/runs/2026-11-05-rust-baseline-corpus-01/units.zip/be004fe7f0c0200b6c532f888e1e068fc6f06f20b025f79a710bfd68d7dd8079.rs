fn read_folios(
        &mut self,
        mut read: impl FnMut(&AddressSpace, FolioRead) -> VfsResult<()>,
    ) -> VfsResult<()> {
        let mut result = Ok(());
        while let Some(folio) = self.next_folio() {
            let attempt = read(self.address_space, folio);
            // Attempt every reserved page, preserving the first read error.
            result = result.and(attempt);
        }
        result
    }