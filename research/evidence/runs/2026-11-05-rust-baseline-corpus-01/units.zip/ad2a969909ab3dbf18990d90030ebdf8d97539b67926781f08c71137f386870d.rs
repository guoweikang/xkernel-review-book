fn new_detached(fs: &Arc<SuperBlock>, flags: MountFlags, devname: Option<&str>) -> Self {
        Self::try_new_detached(fs, flags, devname, None)
            .expect("unchecked mount activation cannot reject flags")
            .expect("a dying or dead superblock cannot be mounted")
    }