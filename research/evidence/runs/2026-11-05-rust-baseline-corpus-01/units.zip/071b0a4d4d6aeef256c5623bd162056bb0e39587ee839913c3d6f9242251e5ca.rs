fn new(record: FileLock) -> Self {
        Self(Arc::new(LockNode::new(record)))
    }