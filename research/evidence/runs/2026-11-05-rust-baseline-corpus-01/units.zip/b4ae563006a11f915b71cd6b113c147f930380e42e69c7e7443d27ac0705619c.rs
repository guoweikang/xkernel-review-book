fn update(&mut self, request: &FileLock, waiter: Option<&Waiter>, wake: &mut WakeQueue) {
        let mut list = core::mem::take(if request.owner.is_flock() {
            &mut self.flock
        } else {
            &mut self.posix
        });
        let (mut start, mut end) = request.bounds();
        let mut remaining = LockList::new();
        let mut merged = None;
        while let Some(mut lock) = list.pop_front() {
            let record = lock.record();
            if record.owner != request.owner {
                remaining.push_back(lock);
                continue;
            }
            if record.kind == request.kind && record.end() >= start - 1 && record.start() - 1 <= end
            {
                start = start.min(record.start());
                end = end.max(record.end());
                if merged.is_none() {
                    // Preserve the first record's identity and descendants.
                    // Expansion needs neither allocation nor the global lock.
                    merged = Some(lock);
                } else {
                    lock.detach_blocked(wake);
                }
            } else if record.start() <= end && start <= record.end() {
                lock.detach_blocked(wake);
                if record.start() < start && record.end() > end {
                    let split = OwnedLock::new(FileLock::range(
                        record.owner,
                        record.pid,
                        record.kind,
                        end + 1,
                        record.end(),
                    ));
                    lock.set_bounds(record.start(), start - 1);
                    remaining.push_back(lock);
                    remaining.push_back(split);
                    Self::append_remaining(&mut list, &mut remaining);
                    break;
                }
                if record.start() < start {
                    lock.set_bounds(record.start(), start - 1);
                    remaining.push_back(lock);
                } else if record.end() > end {
                    lock.set_bounds(end + 1, record.end());
                    remaining.push_back(lock);
                }
            } else {
                remaining.push_back(lock);
            }
        }
        if request.kind != FileLockType::Unlock {
            let lock = if let Some(mut lock) = merged {
                lock.set_bounds(start, end);
                lock
            } else {
                OwnedLock::new(FileLock::range(
                    request.owner,
                    request.pid,
                    request.kind,
                    start,
                    end,
                ))
            };
            Self::install(&mut remaining, lock, waiter);
        }
        if request.owner.is_flock() {
            self.flock = remaining;
        } else {
            self.posix = remaining;
        }
    }