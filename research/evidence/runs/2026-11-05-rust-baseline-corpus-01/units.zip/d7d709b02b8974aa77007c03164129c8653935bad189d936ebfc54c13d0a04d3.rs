const fn new(pos: u64, len: usize, copied: usize) -> Self {
        Self { pos, len, copied }
    }