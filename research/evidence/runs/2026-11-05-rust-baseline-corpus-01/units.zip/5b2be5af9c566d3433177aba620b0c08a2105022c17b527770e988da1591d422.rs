fn position(&self) -> u64 {
        *self.position.lock()
    }