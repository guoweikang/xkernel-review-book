fn capture_poll_source(
        &self,
        _file: &VfsFile,
    ) -> Result<Option<FilePollSource>, PollRegisterError> {
        Ok(None)
    }