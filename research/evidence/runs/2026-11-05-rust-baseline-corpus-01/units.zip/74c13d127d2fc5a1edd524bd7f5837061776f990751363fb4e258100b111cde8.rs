fn new(file: &'a VfsFile, ki_pos: u64) -> Self {
        let flags = KiocbFlags::from_open_flags(file.flags());
        Self {
            file,
            ki_pos,
            flags,
        }
    }