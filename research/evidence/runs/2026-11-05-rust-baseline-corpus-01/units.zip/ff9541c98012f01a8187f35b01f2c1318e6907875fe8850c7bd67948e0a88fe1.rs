fn inode(&self) -> &Arc<VfsInode> {
        &self.inode
    }