fn owner(&self) -> FileLockOwner {
        self.owner
    }