fn initial() -> VfsResult<Arc<Self>> {
        INIT_MNT_NS.get().cloned().ok_or(VfsError::InvalidInput)
    }