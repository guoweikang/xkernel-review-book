fn set_ki_pos(&mut self, ki_pos: u64) {
        self.ki_pos = ki_pos;
    }