fn mmap(&self, mapper: &mut dyn MmapMapper) -> VfsResult<()> {
        self.operations().mmap(self, mapper)
    }