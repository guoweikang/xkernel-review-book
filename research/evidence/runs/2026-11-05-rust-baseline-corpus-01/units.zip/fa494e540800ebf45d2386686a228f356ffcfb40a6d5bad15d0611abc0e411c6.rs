fn is_mount_readonly(&self) -> bool {
        self.mnt.is_readonly()
    }