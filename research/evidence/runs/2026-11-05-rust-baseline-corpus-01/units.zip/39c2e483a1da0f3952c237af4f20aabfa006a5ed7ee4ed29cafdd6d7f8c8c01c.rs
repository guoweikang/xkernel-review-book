fn move_blocked(&self, target: &Blocker) {
        self.0.move_blocked(&target.0, &mut BLOCKED_OWNERS.lock());
    }