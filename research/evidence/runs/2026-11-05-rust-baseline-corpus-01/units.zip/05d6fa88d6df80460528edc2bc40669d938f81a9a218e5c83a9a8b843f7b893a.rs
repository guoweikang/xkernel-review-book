fn is_effectively_readonly(&self) -> bool {
        self.is_mount_readonly() || self.super_block().is_readonly()
    }