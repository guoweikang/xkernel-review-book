fn accept_waiters(&self, waiter: &Waiter) {
        waiter.0.move_blocked(&self.0, &mut BLOCKED_OWNERS.lock());
    }