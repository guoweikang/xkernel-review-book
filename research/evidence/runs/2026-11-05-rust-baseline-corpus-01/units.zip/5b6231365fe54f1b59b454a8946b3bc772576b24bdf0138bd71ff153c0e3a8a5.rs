fn rename(
        &self,
        old_name: &str,
        new_dir: &Self,
        new_name: &str,
        flags: RenameFlags,
        cred: &Cred,
    ) -> VfsResult<()> {
        self.rename_tracked(old_name, new_dir, new_name, flags, cred)
            .map(|_| ())
    }