fn truncate_setsize_after_backing_change(&self, len: u64) -> VfsResult<()> {
        let _invalidate_guard = self.invalidate_lock.write();
        self.truncate_setsize(len)
    }