fn vfs_symlink(
        &self,
        candidate: &Dentry,
        target: &str,
        cred: &Cred,
    ) -> VfsResult<()> {
        self.check_writable_mount()?;
        self.may_modify_directory(cred)?;
        let dir_inode = self.inode();
        dir_inode.symlink(candidate, target, cred)
    }