fn next_folio(&mut self) -> Option<FolioRead> {
        let folio = self.folios.next()?;
        self.index += 1;
        Some(folio)
    }