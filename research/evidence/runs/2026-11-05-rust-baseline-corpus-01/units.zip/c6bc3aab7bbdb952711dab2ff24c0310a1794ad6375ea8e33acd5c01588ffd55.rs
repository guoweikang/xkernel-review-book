fn prepare_readahead(
        &self,
        range: core::ops::Range<PageIndex>,
        marker: Option<PageIndex>,
        file_len: u64,
    ) {
        let last_index = range.end.min(file_len.div_ceil(PAGE_SIZE_4K as u64));
        let mut index = range.start;
        while let Some(run) = self.i_pages.next_miss_range(index..last_index) {
            #[cfg(unittest)]
            super::tests::observe_readahead_run(self, &run);
            match self.i_pages.readahead_folios(run.clone(), |folios| {
                let mut marked = folios.map(|mut folio| {
                    if Some(folio.index()) == marker {
                        folio.mark_readahead();
                    }
                    folio
                });
                let mut control = ReadaheadControl {
                    address_space: self,
                    index: run.start,
                    folios: &mut marked,
                };
                // Consumed failures can be retried; the cache removes the
                // unconsumed suffix when this callback returns.
                let _ = if control.count() == 1 {
                    // A batch boundary must not shorten the window. Initialize
                    // a single reservation directly, without batch staging.
                    control.read_folios(|mapping, folio| self.ops.read_folio(mapping, folio))
                } else {
                    self.ops.readahead(&mut control)
                };
            }) {
                // Only the first candidate was occupied; later misses still need I/O.
                Ok(0) => index = run.start + 1,
                Ok(prepared) => index = run.start + prepared as u64,
                Err(_) => break,
            }
        }
    }