const fn requires_device(&self) -> bool {
        self.fs_flags.contains(FileSystemTypeFlags::REQUIRES_DEV)
    }