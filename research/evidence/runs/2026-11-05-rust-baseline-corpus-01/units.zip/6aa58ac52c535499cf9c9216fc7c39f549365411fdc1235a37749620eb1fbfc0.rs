fn copy_chunk_from(
        &self,
        input: &VfsFile,
        input_pos: u64,
        output: &VfsFile,
        output_pos: u64,
        len: usize,
    ) -> Option<KResult<usize>> {
        let _ = (input, input_pos, output, output_pos, len);
        None
    }