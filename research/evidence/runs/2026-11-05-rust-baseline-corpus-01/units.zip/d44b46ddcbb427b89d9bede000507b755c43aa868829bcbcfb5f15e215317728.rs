fn touch_atime(&self) {
        if self.is_effectively_readonly() {
            return;
        }

        let mount_flags = self.mnt.flags();
        let super_block_flags = self.super_block().flags();
        if mount_flags.contains(MountFlags::NOATIME)
            || super_block_flags.contains(SuperBlockFlags::NOATIME)
            || (self.inode().node_type() == NodeType::Directory
                && (mount_flags.contains(MountFlags::NODIRATIME)
                    || super_block_flags.contains(SuperBlockFlags::NODIRATIME)))
        {
            return;
        }

        let inode = self.inode();
        let now = inode.current_time();
        let times = inode.times();
        if mount_flags.contains(MountFlags::RELATIME)
            && times.modified_at < times.accessed_at
            && times.changed_at < times.accessed_at
            && now
                .duration_since(times.accessed_at)
                .unwrap_or(TimeSpan::ZERO)
                < TimeSpan::from_secs(24 * 60 * 60)
        {
            return;
        }
        if times.accessed_at == now {
            return;
        }

        // Linux treats atime persistence as best effort so a read that already
        // completed is never converted into an update-time failure.
        let _ = inode.update_time(self.dentry(), now, InodeUpdateTime::Access);
    }