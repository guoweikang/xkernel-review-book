fn prepare(
        &mut self,
        inode: &VfsInode,
        start: u64,
        length: &mut u64,
        max_file_size: u64,
        supported_flags: FiemapFlags,
    ) -> VfsResult<()> {
        if *length == 0 {
            return Err(VfsError::InvalidInput);
        }

        if start >= max_file_size {
            return Err(VfsError::FileTooLarge);
        }
        if *length > max_file_size || max_file_size - *length < start {
            *length = max_file_size - start;
        }

        let accepted_flags = supported_flags | FiemapFlags::SYNC;
        let unsupported_bits = self.flags.bits() & !accepted_flags.bits();
        if unsupported_bits != 0 {
            self.flags = FiemapFlags::from_bits_retain(unsupported_bits);
            return Err(VfsError::from(kerrno::LinuxError::EBADR));
        }

        if self.flags.contains(FiemapFlags::SYNC) {
            inode.sync(true)?;
        }
        Ok(())
    }