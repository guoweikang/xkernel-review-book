fn is_enabled(&self) -> bool {
        self.ra_pages != 0
    }