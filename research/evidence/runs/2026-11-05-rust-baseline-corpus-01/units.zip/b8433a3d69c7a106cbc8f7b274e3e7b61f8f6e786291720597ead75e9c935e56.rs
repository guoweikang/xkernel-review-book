fn rename_tracked(
        &self,
        old_name: &str,
        new_dir: &Self,
        new_name: &str,
        flags: RenameFlags,
        cred: &Cred,
    ) -> VfsResult<RenameOutcome> {
        if !Arc::ptr_eq(&self.mnt, &new_dir.mnt) {
            return Err(VfsError::CrossesDevices);
        }
        self.check_writable_mount()?;

        // The identities the event sources need are captured here, inside the
        // callback the rename runs under its namespace lock, from the very
        // dentries being moved and replaced. A path lookup afterwards could
        // describe a different object entirely. Only the replacement link
        // count needs a backend metadata query.
        let mut moved = false;
        let mut source_meta = None;
        let mut replaced_meta = None;
        let mut replaced_nlink = None;
        self.dentry.as_dir()?.rename_with(
            old_name,
            new_dir.dentry.as_dir()?,
            new_name,
            flags,
            |source, target| {
                // The callback only runs when the rename really moves an
                // entry: kvfs returns early, without calling it, for a rename
                // between two links of one inode.
                moved = true;
                self.may_modify_directory(cred)?;
                if !self.ptr_eq(new_dir) {
                    new_dir.may_modify_directory(cred)?;
                }

                let old_path = self.with_dentry(source.clone());
                self.check_sticky(&old_path, cred)?;
                old_path.check_not_mountpoint()?;
                // The source's type is all the move halves need, and the
                // cached copy has it; the replaced target's `nlink` drives a
                // retirement decision, so it is read authoritatively.
                source_meta = Some(old_path.inode());
                if target.is_really_positive() {
                    let new_path = new_dir.with_dentry(target.clone());
                    new_dir.check_sticky(&new_path, cred)?;
                    new_path.check_not_mountpoint()?;
                    replaced_meta = Some(new_path.inode());
                    replaced_nlink = Some(
                        new_path
                            .getattr()
                            .map_or_else(|_| new_path.identity().nlink, |meta| meta.nlink),
                    );
                }
                Ok(())
            },
        )?;
        Ok(RenameOutcome {
            moved,
            source: source_meta,
            replaced: replaced_meta,
            replaced_nlink,
        })
    }