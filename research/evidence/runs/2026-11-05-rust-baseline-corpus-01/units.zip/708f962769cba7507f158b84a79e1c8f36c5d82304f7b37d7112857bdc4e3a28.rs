fn downgrade(&self) -> WeakBlocker {
        WeakBlocker(Arc::downgrade(&self.0))
    }