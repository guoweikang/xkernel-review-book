fn set_flags(&self, flags: MountFlags) {
        self.mnt_flags.store(flags.bits(), Ordering::Relaxed);
    }