fn readahead_for_fault(&self, file_offset: u64, file_end: Option<u64>) -> VfsResult<()> {
        let start_index = file_offset / PAGE_SIZE_4K as u64;
        if self
            .i_pages
            .next_miss_range(start_index..start_index.saturating_add(1))
            .is_none()
        {
            return Ok(());
        }

        let _invalidate_guard = self.invalidate_lock.read();
        let file_len = self.visible_len()?.min(file_end.unwrap_or(u64::MAX));
        if file_offset >= file_len {
            return Ok(());
        }
        let end_index = start_index
            .saturating_add(MAX_FAULT_READAHEAD_PAGES as u64)
            .min(file_len.div_ceil(PAGE_SIZE_4K as u64));
        self.prepare_readahead(start_index..end_index, None, file_len);
        Ok(())
    }