fn inode(&self) -> &Arc<VfsInode> {
        self.location.inode()
    }