fn path_below(&self, root: &Self) -> VfsResult<PathBuf> {
        match self.render_from(root)? {
            RenderedPath::Reachable(path) => Ok(path),
            RenderedPath::Unreachable(_) => Err(VfsError::NotFound),
        }
    }