fn init_mount_tree(root_fs: &Arc<SuperBlock>) -> Arc<Self> {
        Arc::clone(INIT_MNT_NS.call_once(|| {
            Self::build_initial_mount_tree(root_fs)
                .expect("initial mount namespace tree must be created")
        }))
    }