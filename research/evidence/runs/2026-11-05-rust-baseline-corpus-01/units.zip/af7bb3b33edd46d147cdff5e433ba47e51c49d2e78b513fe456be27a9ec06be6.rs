fn iter(&self) -> impl Iterator<Item = FileLock> + '_ {
        self.0.iter().map(|node| {
            // SAFETY: the list owns the range. Its shared borrow excludes
            // removal into OwnedLock, the only capability permitting mutation.
            unsafe { node.record() }
        })
    }