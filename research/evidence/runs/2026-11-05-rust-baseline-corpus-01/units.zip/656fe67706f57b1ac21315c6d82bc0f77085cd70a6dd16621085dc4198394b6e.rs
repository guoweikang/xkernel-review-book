fn flush(&self) -> VfsResult<()> {
        self.operations().flush(self)
    }