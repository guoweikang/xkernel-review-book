fn new_pseudo_super_block(
    file_system_type: &'static FileSystemType,
    magic: u32,
    dentry_operations: &'static dyn DentryOperations,
) -> Arc<SuperBlock> {
    SuperBlock::new_with_dentry_operations(
        file_system_type,
        &PSEUDO_SUPER_OPERATIONS,
        dentry_operations,
        magic,
        PAGE_SIZE_4K as u64,
        MAX_LFS_FILESIZE,
        |_| pseudo_fs_root_dentry(),
    )
}