fn ioctl(&self, cred: &Cred, cmd: u32, arg: usize) -> VfsResult<usize> {
        self.operations().ioctl(self, cred, cmd, arg)
    }