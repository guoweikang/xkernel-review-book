const fn follows_final(self) -> bool {
        self.contains(Self::FOLLOW_FINAL)
    }