const fn flags(&self) -> FiemapFlags {
        self.flags
    }