fn noop_fsync(_data_only: bool) -> VfsResult<()> {
    Ok(())
}