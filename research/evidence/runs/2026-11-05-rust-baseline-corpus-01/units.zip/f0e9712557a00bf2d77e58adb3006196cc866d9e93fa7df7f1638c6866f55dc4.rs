fn complete_folio(&mut self, src: &[u8]) -> VfsResult<()> {
        let mut folio = self.next_folio().ok_or(VfsError::InvalidInput)?;
        if src.len() != PAGE_SIZE_4K {
            return Err(VfsError::InvalidInput);
        }
        folio.data().copy_from_slice(src);
        folio.complete(Ok(()))
    }