fn display_path(&self) -> VfsResult<String> {
        Ok(self.absolute_path()?.to_string())
    }