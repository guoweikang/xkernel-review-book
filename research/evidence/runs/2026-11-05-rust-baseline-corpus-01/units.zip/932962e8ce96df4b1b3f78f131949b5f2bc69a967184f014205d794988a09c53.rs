fn inode(&self) -> Arc<VfsInode> {
        self.dentry.vfs_inode()
    }