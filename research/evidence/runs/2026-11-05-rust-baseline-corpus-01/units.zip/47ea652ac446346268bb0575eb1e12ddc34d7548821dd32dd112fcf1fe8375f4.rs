fn state<'a>(
        &'a self,
        _guard: &'a mut MutexGuard<'_, BlockedOwners>,
    ) -> &'a mut FileLockBlocked {
        // SAFETY: every caller passes the guard of BLOCKED_OWNERS, the sole
        // lock protecting this cell. Borrowing the guard exclusively prevents
        // simultaneous references to any node's mutable linkage.
        unsafe { &mut *self.blocked.get() }
    }