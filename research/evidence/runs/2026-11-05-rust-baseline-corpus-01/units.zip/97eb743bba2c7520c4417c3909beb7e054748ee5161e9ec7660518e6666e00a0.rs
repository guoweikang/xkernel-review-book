fn reconfigure(&mut self) -> VfsResult<()> {
        self.operations()?.reconfigure(self)
    }