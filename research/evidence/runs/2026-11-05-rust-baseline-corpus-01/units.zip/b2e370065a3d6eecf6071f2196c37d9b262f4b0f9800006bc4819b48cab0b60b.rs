fn writepages_control(&self, control: &mut WritebackControl) -> VfsResult<()> {
        let _invalidate_guard = self.invalidate_lock.read();
        self.ops.writepages(self, control)
    }