fn check_not_mountpoint(&self) -> VfsResult<()> {
        if self.is_mountpoint() {
            return Err(VfsError::ResourceBusy);
        }
        Ok(())
    }