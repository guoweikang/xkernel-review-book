fn check_sticky(&self, victim: &Self, cred: &Cred) -> VfsResult<()> {
        let dir = self.metadata();
        if !dir.mode.permission().contains(NodePermission::STICKY) {
            return Ok(());
        }

        // Linux `__check_sticky()` exempts the victim owner, the directory
        // owner, and `CAP_FOWNER`.
        if cred.has_cap(kcred::CAP_FOWNER)
            || cred.fsuid() == dir.uid
            || cred.fsuid() == victim.metadata().uid
        {
            Ok(())
        } else {
            Err(VfsError::OperationNotPermitted)
        }
    }