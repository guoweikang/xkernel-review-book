fn set_created_under(&mut self, parent: Arc<VfsInode>, name: &str) {
        self.created_under = Some((parent, String::from(name)));
    }