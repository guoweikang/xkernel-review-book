fn truncate(&self, len: u64) -> VfsResult<()> {
        self.verify_mode(FMode::WRITE)?;
        self.path().truncate_opened(len)
    }