fn attach(&self, mountpoint: &Path, fs: &Arc<SuperBlock>) -> VfsResult<Arc<Mount>> {
        self.attach_with_flags_and_devname(mountpoint, fs, MountFlags::empty(), None)
    }