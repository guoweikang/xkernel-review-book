fn poll_wait(&self, waker: &Waker) -> Poll<()> {
        // Clone and drop arbitrary wakers outside the wait-tree lock.
        let waker = waker.clone();
        let mut guard = BLOCKED_OWNERS.lock();
        let blocked = self.0.state(&mut guard);
        if blocked.blocker.is_none() && blocked.wait.is_none() {
            drop(guard);
            return Poll::Ready(());
        }
        let old = blocked.wait.replace(waker);
        drop(guard);
        drop(old);
        Poll::Pending
    }