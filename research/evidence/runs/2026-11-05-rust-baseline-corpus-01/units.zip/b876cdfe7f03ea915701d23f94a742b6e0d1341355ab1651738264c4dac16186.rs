fn sync_filesystem(&self) -> VfsResult<()> {
        self.path().sync_filesystem()
    }