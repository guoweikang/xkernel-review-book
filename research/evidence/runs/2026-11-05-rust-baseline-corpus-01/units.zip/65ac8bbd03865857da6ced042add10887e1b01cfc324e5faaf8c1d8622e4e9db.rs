fn simple_unlink(dir: &VfsInode, dentry: &Dentry) -> VfsResult<()> {
    __simple_unlink(dir, dentry);
    Ok(())
}