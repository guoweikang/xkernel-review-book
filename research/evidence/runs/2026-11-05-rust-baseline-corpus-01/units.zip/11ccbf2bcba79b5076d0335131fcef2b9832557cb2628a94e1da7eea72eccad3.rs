fn set_bounds(&mut self, start: i64, end: i64) {
        // SAFETY: &mut self excludes all range readers through this owner.
        // The node is detached; shared handles access disjoint waiting state.
        unsafe { *self.0.bounds.get() = (start, end) };
    }