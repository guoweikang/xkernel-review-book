fn detach_blocked(&mut self, wake: &mut WakeQueue) {
        // The count summarizes `blocked.requests` and is maintained by the
        // BLOCKED_OWNERS-guarded push/pop paths. A zero read means
        // wake_blocked would find nothing, so the detach skips the global
        // mutex even while shared handles (a transient Blocker clone) are
        // alive. Detach runs under the owning inode's state mutex, which
        // also serializes any blocking registration targeting this node, so
        // the read cannot miss an in-flight push.
        if self.0.waiter_count.load(Ordering::Acquire) == 0 {
            return;
        }
        self.0.wake_blocked(&mut BLOCKED_OWNERS.lock(), wake);
    }