fn is_root(&self) -> bool {
        self.mnt_location.lock().is_none()
    }