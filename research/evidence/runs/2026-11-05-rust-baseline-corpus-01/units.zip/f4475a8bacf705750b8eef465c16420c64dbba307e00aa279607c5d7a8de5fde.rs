fn mark_opened(&mut self) -> VfsResult<()> {
        self.mode.remove(FMode::CAN_READ | FMode::CAN_WRITE);
        let operations = self.operations.as_ref().ok_or(VfsError::InvalidInput)?;
        if self.mode.contains(FMode::READ) && operations.supports_read() {
            self.mode.insert(FMode::CAN_READ);
        }
        if self.mode.contains(FMode::WRITE) && operations.supports_write() {
            self.mode.insert(FMode::CAN_WRITE);
        }
        self.mode |= FMode::OPENED;
        Ok(())
    }