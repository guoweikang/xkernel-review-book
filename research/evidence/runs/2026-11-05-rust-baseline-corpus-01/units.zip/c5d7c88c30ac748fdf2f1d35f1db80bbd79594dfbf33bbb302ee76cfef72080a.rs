fn generic_file_write_iter(&mut self, iter: &mut IovIterSource<'_>) -> VfsResult<usize> {
        let mapping = self.file().mapping();
        mapping.write_iter(self, iter)
    }