fn new(mnt: Arc<Mount>, dentry: Dentry) -> Self {
        Self { mnt, dentry }
    }