fn wait_tree_unlocked() -> bool {
    BLOCKED_OWNERS.try_lock().is_some()
}