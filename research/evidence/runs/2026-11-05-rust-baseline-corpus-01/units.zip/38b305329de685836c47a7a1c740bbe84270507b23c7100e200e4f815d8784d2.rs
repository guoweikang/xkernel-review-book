fn metadata(&self) -> Metadata {
        self.dentry.vfs_inode().metadata()
    }