fn new_root_with_flags(fs: &Arc<SuperBlock>, flags: MountFlags) -> Arc<Self> {
        Self::new_root_with_flags_and_devname(fs, flags, None)
    }