fn set_position(&self, position: u64) {
        *self.position_lock() = position;
    }