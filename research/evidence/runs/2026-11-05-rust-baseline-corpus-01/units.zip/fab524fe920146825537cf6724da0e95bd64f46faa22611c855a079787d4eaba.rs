fn remove_blocked_owner(blocked: &mut BlockedOwners, waiter: &Arc<LockNode>) {
    if let Some(requests) = blocked.get_mut(&waiter.owner) {
        requests.remove(&Arc::as_ptr(waiter).addr());
        if requests.is_empty() {
            blocked.remove(&waiter.owner);
        }
    }
}