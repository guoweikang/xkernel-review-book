fn capture_poll_source(&self) -> Result<Option<FilePollSource>, PollRegisterError> {
        self.operations().capture_poll_source(self)
    }