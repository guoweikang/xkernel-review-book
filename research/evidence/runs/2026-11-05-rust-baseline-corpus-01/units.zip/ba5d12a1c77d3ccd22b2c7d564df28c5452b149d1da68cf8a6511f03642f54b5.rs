fn flock(file: &VfsFile) -> Self {
        Self::Flock(core::ptr::from_ref(file).addr())
    }