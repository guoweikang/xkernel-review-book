fn supported_fallocate_modes(&self) -> FallocateFlags {
        self.operations().supported_fallocate_modes()
    }