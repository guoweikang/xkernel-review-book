fn is_mountpoint(&self) -> bool {
        self.dentry.as_dir().is_ok() && self.mnt.child_mount_at(&self.dentry).is_some()
    }