fn get_filesystem_type(name: &str) -> Option<&'static FileSystemType> {
    FILE_SYSTEMS
        .lock()
        .iter()
        .copied()
        .find(|file_system_type| file_system_type.name == name)
}