fn position_lock(&self) -> MutexGuard<'_, u64> {
        self.position.lock()
    }