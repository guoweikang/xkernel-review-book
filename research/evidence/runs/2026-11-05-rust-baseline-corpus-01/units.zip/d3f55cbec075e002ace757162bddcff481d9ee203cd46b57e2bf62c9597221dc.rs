fn advance_readahead(&self, range: core::ops::Range<PageIndex>, marker: Option<PageIndex>) {
        let _invalidate = self.invalidate_lock.read();
        let Ok(file_len) = self.visible_len() else {
            return;
        };
        self.prepare_readahead(range, marker, file_len);
    }