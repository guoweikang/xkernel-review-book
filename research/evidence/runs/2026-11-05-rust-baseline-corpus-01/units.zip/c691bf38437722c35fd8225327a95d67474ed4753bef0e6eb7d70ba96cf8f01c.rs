fn readahead(&self, control: &mut ReadaheadControl<'_>) -> VfsResult<()> {
        control.read_folios(|mapping, folio| self.read_folio(mapping, folio))
    }