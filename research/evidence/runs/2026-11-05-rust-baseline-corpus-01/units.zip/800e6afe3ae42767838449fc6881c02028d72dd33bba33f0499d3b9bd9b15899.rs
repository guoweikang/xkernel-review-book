fn components_to_path(components: &[String]) -> PathBuf {
        iter::once("/")
            .chain(components.iter().map(String::as_str).rev())
            .collect()
    }