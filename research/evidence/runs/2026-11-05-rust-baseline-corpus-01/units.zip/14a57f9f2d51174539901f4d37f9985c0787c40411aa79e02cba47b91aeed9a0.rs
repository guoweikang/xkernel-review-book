fn close_file(self: Arc<Self>, owner: crate::FileLockOwner) -> VfsResult<()> {
        let result = self.flush();
        if !self.is_path() {
            self.remove_posix_locks(owner);
        }
        result
    }