fn covered_mount(&self) -> Option<Arc<Self>> {
        self.covers.lock().clone()
    }