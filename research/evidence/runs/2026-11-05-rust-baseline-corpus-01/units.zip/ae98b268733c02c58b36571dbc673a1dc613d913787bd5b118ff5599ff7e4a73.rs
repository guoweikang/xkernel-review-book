fn set_private_data<T>(&mut self, value: Arc<T>)
    where
        T: Any + Send + Sync + 'static,
    {
        self.private_data.insert_arc(value);
    }