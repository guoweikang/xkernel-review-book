const fn follow() -> Self {
        Self::FOLLOW_FINAL
    }