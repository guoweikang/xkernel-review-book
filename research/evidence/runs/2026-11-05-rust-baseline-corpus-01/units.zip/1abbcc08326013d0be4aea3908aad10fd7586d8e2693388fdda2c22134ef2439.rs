fn location(&self) -> Option<Path> {
        self.mnt_location.lock().clone()
    }