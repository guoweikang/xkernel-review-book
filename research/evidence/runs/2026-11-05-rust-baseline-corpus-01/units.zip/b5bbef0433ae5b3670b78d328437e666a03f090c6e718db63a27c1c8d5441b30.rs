fn children_count(&self) -> usize {
        self.state(&mut BLOCKED_OWNERS.lock())
            .requests
            .iter()
            .count()
    }