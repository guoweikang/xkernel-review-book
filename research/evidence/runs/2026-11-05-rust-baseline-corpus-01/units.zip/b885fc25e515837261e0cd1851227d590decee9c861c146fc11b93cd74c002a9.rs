fn conflicts_with(&self, other: &Self) -> bool {
        self.owner != other.owner
            && self.overlaps(other)
            && (self.kind == FileLockType::Write || other.kind == FileLockType::Write)
    }