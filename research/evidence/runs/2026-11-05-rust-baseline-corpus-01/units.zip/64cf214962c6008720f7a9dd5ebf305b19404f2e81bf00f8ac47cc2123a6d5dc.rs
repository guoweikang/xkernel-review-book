fn is_blocking(&self) -> bool {
        self.inode().flags().contains(NodeFlags::BLOCKING)
    }