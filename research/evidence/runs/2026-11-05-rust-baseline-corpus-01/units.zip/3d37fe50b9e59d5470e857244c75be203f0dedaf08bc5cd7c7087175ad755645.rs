fn kind(&self) -> FileLockType {
        self.kind
    }