fn mode(&self) -> FMode {
        self.mode
    }