fn created_under(&self) -> Option<(&Arc<VfsInode>, &str)> {
        self.created_under
            .as_ref()
            .map(|(parent, name)| (parent, name.as_str()))
    }