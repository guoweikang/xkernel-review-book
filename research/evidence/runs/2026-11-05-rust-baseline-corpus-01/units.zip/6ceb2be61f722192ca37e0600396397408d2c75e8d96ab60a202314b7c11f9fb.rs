fn unlink(&self, name: &str, cred: &Cred) -> VfsResult<()> {
        self.unlink_with_pathname(name, false, cred)
    }