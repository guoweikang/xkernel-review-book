fn start(&self) -> i64 {
        self.bounds().0
    }