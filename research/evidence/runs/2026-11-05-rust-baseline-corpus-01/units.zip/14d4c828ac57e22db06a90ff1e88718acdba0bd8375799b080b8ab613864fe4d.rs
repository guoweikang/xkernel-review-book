fn generic_file_read_iter(&mut self, iter: &mut IovIterDest<'_>) -> VfsResult<usize> {
        let mapping = self.file().mapping();
        mapping.read_iter(self, iter)
    }