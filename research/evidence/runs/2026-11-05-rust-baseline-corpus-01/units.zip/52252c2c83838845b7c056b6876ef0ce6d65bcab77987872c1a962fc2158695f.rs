fn read_from(&self, buf: &mut [u8], pos: &mut u64) -> VfsResult<usize> {
        let mut iter = iov_iter_kvec_dest(buf);
        self.read_iter_from(&mut iter, pos)
    }