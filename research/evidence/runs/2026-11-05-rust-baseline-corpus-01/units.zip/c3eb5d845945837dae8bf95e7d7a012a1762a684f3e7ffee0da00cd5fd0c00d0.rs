fn vfs_mkdir(
        &self,
        candidate: &Dentry,
        permission: NodePermission,
        umask: NodePermission,
        cred: &Cred,
    ) -> VfsResult<()> {
        self.check_writable_mount()?;
        self.may_modify_directory(cred)?;
        let dir_inode = self.inode();
        let allowed_permission =
            NodePermission::all() & !(NodePermission::SET_UID | NodePermission::SET_GID);
        let mode = dir_inode.prepare_create_mode(
            Umode::new(NodeType::Directory, permission),
            umask,
            allowed_permission,
            NodeType::Directory,
            cred,
        );
        dir_inode.mkdir(candidate, mode, cred)
    }