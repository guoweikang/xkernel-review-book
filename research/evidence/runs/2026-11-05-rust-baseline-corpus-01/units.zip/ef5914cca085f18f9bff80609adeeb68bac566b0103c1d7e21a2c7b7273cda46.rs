fn try_new(
        fs: &Arc<SuperBlock>,
        flags: MountFlags,
        requested_superblock_flags: Option<SuperBlockFlags>,
    ) -> VfsResult<Option<Self>> {
        Ok(fs
            .try_activate_mount(requested_superblock_flags)?
            .then(|| Self {
                mnt_root: fs.root_dir(),
                mnt_sb: fs.clone(),
                mnt_flags: AtomicU32::new(flags.bits()),
            }))
    }