fn bind_location(&mut self, location: FileLocation) {
        self.location = Some(location);
    }