fn install(list: &mut LockList, lock: OwnedLock, waiter: Option<&Waiter>) {
        if let Some(waiter) = waiter {
            lock.accept_waiters(waiter);
        }
        let record = lock.record();
        let key = (record.owner, record.start());
        let mut sorted = LockList::new();
        while list
            .iter()
            .next()
            .is_some_and(|entry| (entry.owner, entry.start()) < key)
        {
            if let Some(entry) = list.pop_front() {
                sorted.push_back(entry);
            }
        }
        sorted.push_back(lock);
        Self::append_remaining(list, &mut sorted);
        *list = sorted;
    }