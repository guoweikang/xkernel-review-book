fn may_modify_directory(&self, cred: &Cred) -> VfsResult<()> {
        self.permission(Permission::MAY_WRITE | Permission::MAY_EXEC, cred)
    }