const fn fs_type(&self) -> &'static FileSystemType {
        self.fs_type
    }