fn as_pathname(&self) -> Pathname<'_> {
        self.name.as_pathname()
    }