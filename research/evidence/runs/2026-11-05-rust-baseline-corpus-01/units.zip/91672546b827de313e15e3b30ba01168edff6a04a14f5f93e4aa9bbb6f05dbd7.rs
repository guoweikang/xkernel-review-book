fn reconfigure(&self, context: &mut FsContext<'_>) -> VfsResult<()> {
        self.reconfigure
            .map_or(Ok(()), |reconfigure| reconfigure(context))
    }