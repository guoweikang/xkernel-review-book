fn with_invalidate_read<R>(&self, f: impl FnOnce() -> KResult<R>) -> KResult<R> {
        let _invalidate_guard = self.invalidate_lock.read();
        f()
    }