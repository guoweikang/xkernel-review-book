fn set_sb_flags(&mut self, flags: SuperBlockFlags) {
        self.sb_flags = flags;
    }