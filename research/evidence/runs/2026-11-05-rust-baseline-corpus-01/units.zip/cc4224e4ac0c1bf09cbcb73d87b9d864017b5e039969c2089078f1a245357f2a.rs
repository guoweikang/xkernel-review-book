const fn purpose(&self) -> FsContextPurpose {
        self.purpose
    }