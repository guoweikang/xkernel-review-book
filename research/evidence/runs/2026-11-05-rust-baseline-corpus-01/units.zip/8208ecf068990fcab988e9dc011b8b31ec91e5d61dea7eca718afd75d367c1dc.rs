fn poll_handler(&self) -> Option<IoEvents> {
        self.operations().poll(self)
    }