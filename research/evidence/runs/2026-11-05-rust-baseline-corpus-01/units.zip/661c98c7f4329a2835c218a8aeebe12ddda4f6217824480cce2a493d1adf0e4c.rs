fn name(&self) -> String {
        self.dentry.name_snapshot()
    }