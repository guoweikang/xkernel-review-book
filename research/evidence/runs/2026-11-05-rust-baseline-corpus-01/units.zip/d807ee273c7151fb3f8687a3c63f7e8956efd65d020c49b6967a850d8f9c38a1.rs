fn super_block_flags(&self) -> SuperBlockFlags {
        self.super_block().flags()
    }