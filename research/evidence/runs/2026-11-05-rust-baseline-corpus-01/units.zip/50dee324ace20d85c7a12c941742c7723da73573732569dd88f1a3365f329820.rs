fn is_file(&self) -> bool {
        !self.is_dir()
    }