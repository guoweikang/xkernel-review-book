fn new() -> Self {
        Self {
            state: Mutex::new(FileLockLists {
                posix: LockList::new(),
                flock: LockList::new(),
            }),
        }
    }