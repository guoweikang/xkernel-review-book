fn write_from(&self, buf: &[u8], pos: &mut u64) -> VfsResult<usize> {
        let mut iter = iov_iter_kvec_source(buf);
        self.write_iter_from(&mut iter, pos)
    }