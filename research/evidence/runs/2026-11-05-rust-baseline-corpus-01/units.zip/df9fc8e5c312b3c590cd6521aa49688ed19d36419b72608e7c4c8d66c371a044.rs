fn reconfigure_mount(&self, target: &Path, flags: MountFlags) -> VfsResult<()> {
        let mounts = self.mounts.lock();
        let mount = Self::registered_mount_at(&mounts, target)?;
        mount.set_flags(flags);
        Ok(())
    }