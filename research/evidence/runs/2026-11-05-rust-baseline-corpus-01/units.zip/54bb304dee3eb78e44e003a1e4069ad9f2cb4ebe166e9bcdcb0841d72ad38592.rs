fn new(name: impl Into<PathBuf>) -> Self {
        Self { name: name.into() }
    }