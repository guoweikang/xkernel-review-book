fn flags(&self) -> MountFlags {
        self.mnt.flags()
    }