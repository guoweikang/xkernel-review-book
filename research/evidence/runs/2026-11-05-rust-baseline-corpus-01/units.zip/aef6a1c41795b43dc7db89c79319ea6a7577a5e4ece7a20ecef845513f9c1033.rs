fn remove_flags(&mut self, flags: FiemapFlags) {
        self.flags.remove(flags);
    }