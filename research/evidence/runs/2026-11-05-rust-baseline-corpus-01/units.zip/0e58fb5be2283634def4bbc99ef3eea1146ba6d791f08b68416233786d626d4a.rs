fn mmap(&self, file: &VfsFile, mapper: &mut dyn MmapMapper) -> VfsResult<()> {
        if file.inode().node_type() == NodeType::RegularFile {
            mapper.map_file_backed()
        } else {
            Err(VfsError::NoSuchDevice)
        }
    }