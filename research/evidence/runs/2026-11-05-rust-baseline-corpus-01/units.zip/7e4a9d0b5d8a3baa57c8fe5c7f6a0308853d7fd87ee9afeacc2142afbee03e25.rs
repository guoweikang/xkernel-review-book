fn note_pop(&self) {
        let previous = self.waiter_count.fetch_sub(1, Ordering::AcqRel);
        debug_assert!(previous > 0);
    }