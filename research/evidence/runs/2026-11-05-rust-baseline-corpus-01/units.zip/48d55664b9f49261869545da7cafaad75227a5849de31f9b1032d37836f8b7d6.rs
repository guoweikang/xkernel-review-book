const fn source(&self) -> Option<&'a str> {
        self.source
    }