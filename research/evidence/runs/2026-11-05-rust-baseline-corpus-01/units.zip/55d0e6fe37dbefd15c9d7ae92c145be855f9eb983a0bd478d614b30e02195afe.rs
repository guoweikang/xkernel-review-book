fn filesystem_stat(&self) -> VfsResult<StatFs> {
        self.super_block().stat()
    }