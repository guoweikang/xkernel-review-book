fn attach_with_requested_superblock_flags(
        &self,
        mountpoint: &Path,
        fs: &Arc<SuperBlock>,
        flags: MountFlags,
        devname: Option<&str>,
        requested_superblock_flags: Option<SuperBlockFlags>,
    ) -> VfsResult<Arc<Mount>> {
        let mut mounts = self.mounts.lock();
        Self::require_mount(&mounts, mountpoint.mount())?;
        let mount = mountpoint.mount_filesystem_with_requested_superblock_flags(
            fs,
            flags,
            devname,
            requested_superblock_flags,
        )?;
        mounts.insert(mount.mount_id(), mount.clone());
        Ok(mount)
    }