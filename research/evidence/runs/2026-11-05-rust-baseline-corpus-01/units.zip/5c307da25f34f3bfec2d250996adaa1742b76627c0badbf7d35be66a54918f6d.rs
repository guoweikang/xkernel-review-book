const fn nodev(name: &'static str, init_fs_context: InitFsContextFn) -> Self {
        Self {
            name,
            init_fs_context,
            fs_flags: FileSystemTypeFlags::empty(),
        }
    }