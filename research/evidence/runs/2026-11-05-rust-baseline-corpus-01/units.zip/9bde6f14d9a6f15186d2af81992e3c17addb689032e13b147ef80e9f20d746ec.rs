const fn with_reconfigure(get_tree: GetTreeFn, reconfigure: ReconfigureFn) -> Self {
        Self {
            get_tree,
            reconfigure: Some(reconfigure),
        }
    }