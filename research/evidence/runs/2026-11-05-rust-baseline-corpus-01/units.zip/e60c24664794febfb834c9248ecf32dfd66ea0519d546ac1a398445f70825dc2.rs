fn identity(&self) -> Metadata {
        let mut metadata = self.dentry.vfs_inode().metadata();
        metadata.device = self.mnt.synthetic_device_id();
        metadata
    }