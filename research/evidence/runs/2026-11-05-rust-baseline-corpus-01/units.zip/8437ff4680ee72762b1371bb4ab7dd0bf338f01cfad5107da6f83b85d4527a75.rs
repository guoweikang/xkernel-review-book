fn read_iter(&self, iter: &mut IovIterDest<'_>) -> VfsResult<usize> {
        if self.is_stream() {
            return self.read_iter_from(iter, &mut 0);
        }
        let mut pos = self.position_lock();
        self.read_iter_from(iter, &mut pos)
    }