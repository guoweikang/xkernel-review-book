fn object_id(&self) -> VmObjectId {
        self.object_id
    }