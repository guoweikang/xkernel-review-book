const fn is_data_only(self) -> bool {
        self.data_only
    }