const fn no_follow() -> Self {
        Self::empty()
    }