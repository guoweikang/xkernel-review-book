fn id(&self) -> NamespaceId {
        self.id
    }