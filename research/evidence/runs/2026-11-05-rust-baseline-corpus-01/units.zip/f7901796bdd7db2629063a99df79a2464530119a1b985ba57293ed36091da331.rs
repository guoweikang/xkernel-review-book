fn file(&self) -> &'a VfsFile {
        self.file
    }