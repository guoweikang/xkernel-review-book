const fn new(pos: u64, len: usize) -> Self {
        Self { pos, len }
    }