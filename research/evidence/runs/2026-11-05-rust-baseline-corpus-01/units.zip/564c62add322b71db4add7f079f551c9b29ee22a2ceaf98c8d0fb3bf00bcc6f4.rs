fn bounds(&self) -> (i64, i64) {
        self.bounds
    }