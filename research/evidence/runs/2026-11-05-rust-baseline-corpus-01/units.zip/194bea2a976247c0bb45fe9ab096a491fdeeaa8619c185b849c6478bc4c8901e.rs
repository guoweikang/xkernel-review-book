fn flags(&self) -> MountFlags {
        MountFlags::from_bits_truncate(self.mnt_flags.load(Ordering::Relaxed))
    }