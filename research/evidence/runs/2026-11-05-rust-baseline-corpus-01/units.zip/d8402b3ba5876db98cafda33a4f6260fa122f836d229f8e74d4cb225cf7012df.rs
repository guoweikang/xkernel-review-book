fn mount_edge_detach(parent: &Mount, dentry: &Dentry, mount: &Arc<Mount>) {
    match mount.covers.lock().take() {
        Some(covered) => {
            parent.install_child_mount(dentry, &covered);
        }
        None => parent.remove_child_mount(dentry),
    }
    mount.detach();
}