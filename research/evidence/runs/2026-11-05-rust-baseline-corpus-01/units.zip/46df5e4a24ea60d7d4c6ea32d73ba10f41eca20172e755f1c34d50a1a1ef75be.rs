fn has_no_waiters(&self) -> bool {
        let mut guard = BLOCKED_OWNERS.lock();
        self.0
            .iter()
            .all(|node| node.state(&mut guard).requests.is_empty())
    }