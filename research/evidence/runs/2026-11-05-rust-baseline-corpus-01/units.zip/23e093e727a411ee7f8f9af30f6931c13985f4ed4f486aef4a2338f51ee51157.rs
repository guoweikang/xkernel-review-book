fn is_stream(&self) -> bool {
        self.mode().contains(FMode::STREAM)
    }