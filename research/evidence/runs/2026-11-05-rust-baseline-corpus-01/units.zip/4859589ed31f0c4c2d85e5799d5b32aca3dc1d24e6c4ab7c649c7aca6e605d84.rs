fn read_from_page_cache(
        &self,
        iter: &mut IovIterDest<'_>,
        offset: u64,
    ) -> VfsResult<usize> {
        self.read_with_ra(
            iter,
            offset,
            &Mutex::new(FileRaState::new(block::BackingDevInfo::DEFAULT_RA_PAGES)),
        )
    }