fn get_tree(
        &self,
        context: &mut FsContext<'_>,
        lookup_root: &crate::Path,
        lookup_pwd: &crate::Path,
    ) -> VfsResult<Arc<SuperBlock>> {
        (self.get_tree)(context, lookup_root, lookup_pwd)
    }