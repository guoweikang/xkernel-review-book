fn dir_operations(&self) -> Option<&dyn FileDirOperations> {
        None
    }