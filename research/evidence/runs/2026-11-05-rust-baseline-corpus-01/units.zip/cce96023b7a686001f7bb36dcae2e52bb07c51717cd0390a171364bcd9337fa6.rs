const fn range_end(self) -> u64 {
        self.range_end
    }