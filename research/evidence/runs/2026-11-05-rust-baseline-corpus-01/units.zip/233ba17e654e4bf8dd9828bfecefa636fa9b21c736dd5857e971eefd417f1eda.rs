fn dirty_folio(&self, folio: &mut FolioGuard<'_>) -> VfsResult<bool> {
        self.ops.dirty_folio(self, folio)
    }