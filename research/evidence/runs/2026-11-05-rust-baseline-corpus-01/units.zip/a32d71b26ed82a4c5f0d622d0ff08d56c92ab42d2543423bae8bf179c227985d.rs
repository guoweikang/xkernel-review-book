fn try_apply(
        &self,
        request: &FileLock,
        is_blocking: bool,
        waiter: &mut Option<Waiter>,
        wake: &mut WakeQueue,
    ) -> KResult<bool> {
        let mut state = self.state.lock();
        let list = if request.owner.is_flock() {
            &mut state.flock
        } else {
            &mut state.posix
        };
        // flock conversion drops the old lock before checking conflicts;
        // record-lock conversion preserves it on failure.
        if request.owner.is_flock() {
            if let Some(lock) =
                list.find(|lock| lock.owner == request.owner && lock.kind == request.kind)
            {
                if let Some(waiter) = waiter {
                    waiter.move_blocked(&lock);
                }
                return Ok(false);
            }
            list.remove_owner(request.owner, wake);
        }
        if request.kind == FileLockType::Unlock && request.start() == 0 && request.end() == i64::MAX
        {
            list.remove_owner(request.owner, wake);
            return Ok(false);
        }
        if request.kind != FileLockType::Unlock
            && let Some(lock) = list.find(|lock| request.conflicts_with(lock))
        {
            if !is_blocking {
                return Err(KError::WouldBlock);
            }
            let waiter = waiter.get_or_insert_with(|| Waiter::new(*request));
            waiter.block_on(lock, wake)?;
            return Ok(true);
        }
        if let Some(lock) = list.find(|lock| {
            lock.owner == request.owner
                && lock.kind == request.kind
                && lock.start() <= request.start()
                && lock.end() >= request.end()
        }) {
            if let Some(waiter) = waiter {
                waiter.move_blocked(&lock);
            }
        } else {
            state.update(request, waiter.as_ref(), wake);
        }
        Ok(false)
    }