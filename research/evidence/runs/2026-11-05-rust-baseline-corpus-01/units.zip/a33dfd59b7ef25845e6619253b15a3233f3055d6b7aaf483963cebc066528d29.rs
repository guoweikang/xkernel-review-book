const fn rejects_magic_links(self) -> bool {
        self.contains(Self::NO_MAGIC_LINKS)
    }