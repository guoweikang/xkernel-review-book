fn operations(&self) -> &dyn FileOperations {
        self.operations.as_ref()
    }