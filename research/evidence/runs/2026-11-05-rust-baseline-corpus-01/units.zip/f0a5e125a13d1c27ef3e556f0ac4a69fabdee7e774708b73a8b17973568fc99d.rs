fn with_dentry(&self, dentry: Dentry) -> Self {
        Self::new(self.mnt.clone(), dentry)
    }