fn new() -> Self {
        Self(LinkedList::new(LockAdapter::new()))
    }