fn stream_open(&mut self) {
        self.mode &= !(FMode::LSEEK | FMode::PREAD | FMode::PWRITE | FMode::ATOMIC_POS);
        self.mode |= FMode::STREAM;
    }