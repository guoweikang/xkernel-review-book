fn flags(&self) -> OpenFlags {
        self.flags
    }