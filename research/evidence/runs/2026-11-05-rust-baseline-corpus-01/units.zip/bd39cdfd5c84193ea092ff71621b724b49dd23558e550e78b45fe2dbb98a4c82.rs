fn from_open_flags(flags: OpenFlags) -> Self {
        Self::from_bits_truncate(flags.bits().wrapping_add(1) & O_ACCMODE)
    }