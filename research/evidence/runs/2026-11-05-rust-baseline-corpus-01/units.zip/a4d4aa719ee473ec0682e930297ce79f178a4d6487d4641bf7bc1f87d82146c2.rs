fn note_push(&self) {
        self.waiter_count.fetch_add(1, Ordering::Release);
    }