fn new(
        flags: FiemapFlags,
        extents_max: u32,
        writer: &'a mut dyn FiemapExtentWriter,
    ) -> Self {
        Self {
            flags,
            extents_max,
            extents_mapped: 0,
            writer,
        }
    }