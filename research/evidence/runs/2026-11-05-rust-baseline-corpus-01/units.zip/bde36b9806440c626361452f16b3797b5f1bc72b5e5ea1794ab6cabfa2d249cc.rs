fn new_initial_nullfs_superblock() -> Arc<SuperBlock> {
    nullfs::new_superblock()
}