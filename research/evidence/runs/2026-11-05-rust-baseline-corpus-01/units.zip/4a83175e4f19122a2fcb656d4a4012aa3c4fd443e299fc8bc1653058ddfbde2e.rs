fn simple_fsync_noflush(file: &VfsFile, data_only: bool) -> VfsResult<()> {
    file.writeback_mapping(data_only)
}