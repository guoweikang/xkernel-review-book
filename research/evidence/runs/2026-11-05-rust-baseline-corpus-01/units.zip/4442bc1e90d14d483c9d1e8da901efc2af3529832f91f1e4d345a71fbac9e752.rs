const fn nr_to_write(self) -> usize {
        self.nr_to_write
    }