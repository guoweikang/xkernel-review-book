fn super_block(&self) -> VfsResult<&'a SuperBlock> {
        self.target_super_block.ok_or(VfsError::InvalidInput)
    }