fn new_root_with_flags_and_devname(
        fs: &Arc<SuperBlock>,
        flags: MountFlags,
        devname: Option<&str>,
    ) -> Arc<Self> {
        Arc::new(Self::new_detached(fs, flags, devname))
    }