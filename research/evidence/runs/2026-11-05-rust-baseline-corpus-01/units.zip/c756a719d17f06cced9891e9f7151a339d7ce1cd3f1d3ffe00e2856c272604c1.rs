fn detach(&self) {
        self.mnt_location.lock().take();
    }