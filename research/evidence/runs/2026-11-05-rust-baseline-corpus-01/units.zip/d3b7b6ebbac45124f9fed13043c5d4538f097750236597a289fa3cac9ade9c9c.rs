fn with_folio_or_create<R>(
        &self,
        index: PageIndex,
        f: impl FnOnce(&mut FolioGuard<'_>) -> KResult<R>,
    ) -> KResult<R> {
        self.i_pages
            .with_folio_or_create(index, |folio| self.ops.read_folio(self, folio), f)
    }