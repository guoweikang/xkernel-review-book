fn inode_key(&self) -> usize {
        Arc::as_ptr(&self.inode()) as usize
    }