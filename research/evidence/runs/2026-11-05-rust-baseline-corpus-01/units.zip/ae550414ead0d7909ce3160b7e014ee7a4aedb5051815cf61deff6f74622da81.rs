const fn copied(self) -> usize {
        self.copied
    }