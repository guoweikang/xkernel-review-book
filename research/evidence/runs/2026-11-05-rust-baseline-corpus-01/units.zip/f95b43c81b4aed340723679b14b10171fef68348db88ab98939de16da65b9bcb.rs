fn clone_from_path(source: &Path) -> Self {
        let super_block = source.super_block().clone();
        super_block.activate_mount();
        Self {
            mnt_root: source.dentry.clone(),
            mnt_sb: super_block,
            mnt_flags: AtomicU32::new(source.mount().flags().bits()),
        }
    }