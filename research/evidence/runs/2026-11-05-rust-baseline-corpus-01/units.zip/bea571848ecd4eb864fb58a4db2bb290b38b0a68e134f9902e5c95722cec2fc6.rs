fn private_data_get<T>(&self) -> Option<Arc<T>>
    where
        T: Any + Send + Sync + 'static,
    {
        self.private_data.lock().get::<T>()
    }