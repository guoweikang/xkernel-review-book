fn find(list: &LinkedList<LockAdapter>, matches: impl Fn(&Self) -> bool) -> Option<Arc<Self>> {
        let mut cursor = list.front();
        while let Some(lock) = cursor.get() {
            if matches(lock) {
                return cursor.clone_pointer();
            }
            cursor.move_next();
        }
        None
    }