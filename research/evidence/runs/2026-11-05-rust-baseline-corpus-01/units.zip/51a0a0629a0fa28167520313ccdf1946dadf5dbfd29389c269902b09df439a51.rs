fn truncate_final(&self) -> VfsResult<()> {
        let _invalidate_guard = self.invalidate_lock.write();
        self.i_pages.truncate_final()?;
        Ok(())
    }