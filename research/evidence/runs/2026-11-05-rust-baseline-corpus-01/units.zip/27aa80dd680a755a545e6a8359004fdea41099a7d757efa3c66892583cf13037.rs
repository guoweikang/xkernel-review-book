fn into_path(self) -> VfsResult<Path> {
        match self {
            Self::Path(location) => Ok(location),
            Self::MagicLink(_) => Err(crate::VfsError::FilesystemLoop),
        }
    }