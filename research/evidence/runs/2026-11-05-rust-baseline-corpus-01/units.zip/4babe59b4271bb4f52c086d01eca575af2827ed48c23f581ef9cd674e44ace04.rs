fn with_folio<R>(
        &self,
        index: PageIndex,
        f: impl FnOnce(Option<&mut FolioGuard<'_>>) -> R,
    ) -> VfsResult<R> {
        self.i_pages.with_folio(index, f)
    }