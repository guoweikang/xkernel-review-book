fn magic_link(link: Arc<dyn MagicLinkOps>) -> Self {
        Self::MagicLink(link)
    }