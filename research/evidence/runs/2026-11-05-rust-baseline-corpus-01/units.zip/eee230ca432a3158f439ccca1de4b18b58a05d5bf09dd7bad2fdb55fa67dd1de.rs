const fn range_start(self) -> u64 {
        self.range_start
    }