fn record_position(&mut self, pos: u64) {
        self.prev_pos_bytes = Some(pos);
    }