fn location(location: Path) -> Self {
        Self::Path(location)
    }