fn cloned_from(file: &VfsFile) -> Self {
        file.location.clone()
    }