fn magic_link(self: Arc<Self>) -> Option<Arc<dyn MagicLinkOps>> {
        None
    }