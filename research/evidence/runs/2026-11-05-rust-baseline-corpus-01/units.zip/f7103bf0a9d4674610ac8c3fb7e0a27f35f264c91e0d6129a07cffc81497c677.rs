fn has_blocked_owner(owner: FileLockOwner) -> bool {
    BLOCKED_OWNERS.lock().contains_key(&owner)
}