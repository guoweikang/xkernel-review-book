fn read_cache_folio(
        &self,
        offset: u64,
        count: usize,
        prepared_end: &mut u64,
        ra: &Mutex<FileRaState>,
    ) -> VfsResult<bool> {
        let _invalidate_guard = self.invalidate_lock.read();
        let file_len = self.visible_len()?;
        if offset >= file_len {
            return Ok(false);
        }
        if offset >= *prepared_end {
            let index = offset / PAGE_SIZE_4K as u64;
            let end = offset.saturating_add(count as u64).min(file_len);
            let request = end.div_ceil(PAGE_SIZE_4K as u64) - index;
            let (range, marker) = ra.lock().on_miss(index, request, |limit| {
                self.i_pages.preceding_cached_pages(index, limit)
            });
            *prepared_end = range.end.saturating_mul(PAGE_SIZE_4K as u64).min(file_len);
            self.prepare_readahead(range, marker, file_len);
        }
        let index = offset / PAGE_SIZE_4K as u64;
        if let Err(error) = self.with_folio_or_create(index, |_| Ok(())) {
            if error == VfsError::Io {
                ra.lock().shrink_after_io_error();
            }
            return Err(error);
        }
        Ok(true)
    }