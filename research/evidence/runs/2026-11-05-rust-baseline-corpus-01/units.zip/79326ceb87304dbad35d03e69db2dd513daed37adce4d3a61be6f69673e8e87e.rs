fn into_arc_at(mut self, location_in_parent: Option<Path>) -> Arc<Self> {
        self.mnt_location = Mutex::new(location_in_parent);
        Arc::new(self)
    }