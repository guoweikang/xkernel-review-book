fn fsync(&self, data_only: bool) -> VfsResult<()> {
        if self.is_path() {
            return Err(VfsError::BadFileDescriptor);
        }
        self.operations().fsync(self, data_only)
    }