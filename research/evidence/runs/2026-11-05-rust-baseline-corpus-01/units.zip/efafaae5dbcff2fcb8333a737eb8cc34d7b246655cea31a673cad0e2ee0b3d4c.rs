fn readahead_after_copy(
        &self,
        folio: &mut FolioGuard<'_>,
        offset: u64,
        count: usize,
        ra: &Mutex<FileRaState>,
    ) -> Option<(core::ops::Range<PageIndex>, Option<PageIndex>)> {
        if !folio.is_readahead() {
            return None;
        }
        // The caller holds the folio lock. Serialize eligibility, consumption
        // and window selection with EIO retreat; no policy holder waits for a
        // folio or performs I/O.
        let mut policy = ra.lock();
        if !policy.is_enabled() || !folio.take_readahead() {
            return None;
        }
        let index = folio.index();
        let request_pages = (offset
            .saturating_add(count as u64)
            .div_ceil(PAGE_SIZE_4K as u64)
            - index)
            .max(1);
        policy.on_marker(index, request_pages, |limit| {
            self.i_pages
                .next_miss_range(index + 1..index + 1 + limit)
                .map(|run| run.start)
        })
    }