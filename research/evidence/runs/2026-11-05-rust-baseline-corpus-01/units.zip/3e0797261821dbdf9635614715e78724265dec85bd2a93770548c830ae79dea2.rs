fn supports_write(&self) -> bool {
        false
    }