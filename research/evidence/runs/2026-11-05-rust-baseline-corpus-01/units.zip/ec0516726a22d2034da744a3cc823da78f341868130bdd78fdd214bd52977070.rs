fn build_initial_mount_tree(root_fs: &Arc<SuperBlock>) -> VfsResult<Arc<Self>> {
        let namespace_root = new_initial_nullfs_superblock();
        let namespace = Self::new_root(&namespace_root, initial_user_namespace());
        namespace.attach_with_flags_and_devname(
            &namespace.root_path(),
            root_fs,
            MountFlags::RELATIME,
            None,
        )?;
        Ok(namespace)
    }