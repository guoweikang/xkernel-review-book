fn max_file_size(&self) -> u64 {
        self.super_block().max_file_size()
    }