fn private<T>(&self) -> VfsResult<&T>
    where
        T: Any + Send + Sync,
    {
        self.fs_private
            .as_deref()
            .and_then(|private| private.downcast_ref::<T>())
            .ok_or(crate::VfsError::InvalidInput)
    }