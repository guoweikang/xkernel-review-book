fn count(&self) -> usize {
        self.folios.len()
    }