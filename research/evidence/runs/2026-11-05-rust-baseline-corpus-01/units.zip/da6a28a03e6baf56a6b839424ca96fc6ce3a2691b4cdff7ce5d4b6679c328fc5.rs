fn is_posix(self) -> bool {
        matches!(self, Self::Posix(_))
    }