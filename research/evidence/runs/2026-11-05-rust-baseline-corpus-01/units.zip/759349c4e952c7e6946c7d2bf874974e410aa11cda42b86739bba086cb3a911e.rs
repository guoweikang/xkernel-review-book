fn poll(&self) -> IoEvents {
        self.poll_handler().unwrap_or(IoEvents::IN | IoEvents::OUT)
    }