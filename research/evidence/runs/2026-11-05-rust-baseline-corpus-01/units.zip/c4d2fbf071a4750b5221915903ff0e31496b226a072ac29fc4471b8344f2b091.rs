fn new(ra_pages: usize) -> Self {
        Self {
            start: 0,
            size_pages: 0,
            async_size_pages: 0,
            prev_pos_bytes: None,
            ra_pages: ra_pages as u64,
        }
    }