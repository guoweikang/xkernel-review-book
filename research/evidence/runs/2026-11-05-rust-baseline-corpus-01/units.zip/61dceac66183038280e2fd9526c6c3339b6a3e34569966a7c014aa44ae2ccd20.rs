fn children(self: &Arc<Self>) -> Vec<Arc<Self>> {
        self.mnt_mounts
            .lock()
            .values()
            .filter_map(Weak::upgrade)
            .collect()
    }