fn path(&self) -> &Path {
        &self.path
    }