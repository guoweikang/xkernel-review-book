fn synthetic_device_id(self: &Arc<Self>) -> u64 {
        self.mnt_id
    }