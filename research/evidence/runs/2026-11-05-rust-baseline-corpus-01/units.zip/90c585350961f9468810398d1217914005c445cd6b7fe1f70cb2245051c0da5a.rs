fn new_root(fs: &Arc<SuperBlock>) -> Arc<Self> {
        Self::new_root_with_flags_and_devname(fs, MountFlags::empty(), None)
    }