fn truncate_setsize(&self, len: u64) -> VfsResult<()> {
        if !ktask::is_sleepable_context() {
            return Err(VfsError::InvalidInput);
        }
        let inode = self.inode().ok_or(VfsError::InvalidInput)?;
        let old_len = inode.size();
        inode.set_size(len);
        self.truncate_pagecache(old_len, len)?;
        Ok(())
    }