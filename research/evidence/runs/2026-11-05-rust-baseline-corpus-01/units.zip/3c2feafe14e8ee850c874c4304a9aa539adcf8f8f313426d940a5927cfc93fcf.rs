fn range(owner: FileLockOwner, pid: i32, kind: FileLockType, start: i64, end: i64) -> Self {
        Self {
            owner,
            kind,
            bounds: (start, end),
            pid,
        }
    }