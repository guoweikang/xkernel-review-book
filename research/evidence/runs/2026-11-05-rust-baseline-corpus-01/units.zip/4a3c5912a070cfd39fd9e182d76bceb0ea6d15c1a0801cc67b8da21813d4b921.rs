fn attach_with_flags_and_devname(
        &self,
        mountpoint: &Path,
        fs: &Arc<SuperBlock>,
        flags: MountFlags,
        devname: Option<&str>,
    ) -> VfsResult<Arc<Mount>> {
        self.attach_with_requested_superblock_flags(mountpoint, fs, flags, devname, None)
    }