fn install_operations(&mut self, operations: Arc<dyn FileOperations>) {
        self.operations = Some(operations);
    }