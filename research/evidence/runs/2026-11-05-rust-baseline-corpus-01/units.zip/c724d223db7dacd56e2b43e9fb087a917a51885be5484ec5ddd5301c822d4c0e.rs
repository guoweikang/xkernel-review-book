fn set_pipe_generation(&mut self, generation: u64) {
        self.pipe_generation = generation;
    }