fn set_private<T>(&mut self, private: T) -> VfsResult<()>
    where
        T: Any + Send + Sync,
    {
        self.fs_private = Some(KBox::new(private)?);
        Ok(())
    }