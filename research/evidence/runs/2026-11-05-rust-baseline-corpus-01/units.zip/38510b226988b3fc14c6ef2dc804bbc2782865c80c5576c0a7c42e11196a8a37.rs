fn read(&self, buf: &mut [u8]) -> VfsResult<usize> {
        let mut iter = iov_iter_kvec_dest(buf);
        self.read_iter(&mut iter)
    }