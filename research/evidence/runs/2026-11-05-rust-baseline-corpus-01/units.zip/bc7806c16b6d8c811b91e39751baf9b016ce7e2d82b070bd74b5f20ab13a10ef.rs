fn read_with_ra(
        &self,
        iter: &mut IovIterDest<'_>,
        mut offset: u64,
        ra: &Mutex<FileRaState>,
    ) -> VfsResult<usize> {
        let inode = self.inode().ok_or(VfsError::InvalidInput)?;
        let mut total = 0usize;
        let mut prepared_end = offset;
        'read: while iter.count() != 0 {
            // Batch resident references independently of the per-open window.
            // A one-page read avoids collecting a batch at all.
            let page_remaining = PAGE_SIZE_4K - (offset % PAGE_SIZE_4K as u64) as usize;
            let batch = if iter.count() > page_remaining {
                let file_len = inode.size();
                if offset >= file_len {
                    break;
                }
                let end = offset.saturating_add(iter.count() as u64).min(file_len);
                let start = offset / PAGE_SIZE_4K as u64;
                let count = end.div_ceil(PAGE_SIZE_4K as u64) - start;
                Some(self.i_pages.get_folios_contig(start, count as usize))
            } else {
                None
            };
            for slot in 0..batch.as_ref().map_or(1, |batch| batch.len().max(1)) {
                let requested = iter.count();
                let page_remaining = PAGE_SIZE_4K - (offset % PAGE_SIZE_4K as u64) as usize;
                // Sample EOF after locking the folio, so a completed shrink cannot
                // expose stale bytes through an earlier file-size snapshot.
                let mut copy = |folio: &mut FolioGuard<'_>| {
                    let page_off = (offset % PAGE_SIZE_4K as u64) as usize;
                    let step = inode
                        .size()
                        .saturating_sub(offset)
                        .min((PAGE_SIZE_4K - page_off) as u64)
                        as usize;
                    if step == 0 {
                        return Ok((0, None));
                    }
                    let copied = iter.copy_to_iter(&folio.data()[page_off..page_off + step])?;
                    let window = if copied != 0 {
                        self.readahead_after_copy(folio, offset, requested, ra)
                    } else {
                        None
                    };
                    Ok((copied, window))
                };
                let cached = match batch.as_ref() {
                    Some(batch) => batch.with_read_folio(slot, &mut copy),
                    None => self.with_folio(offset / PAGE_SIZE_4K as u64, |folio| folio.map(copy)),
                };
                let result = match cached {
                    Ok(Some(result)) => result,
                    Err(error) => Err(error),
                    Ok(None) => {
                        match self.read_cache_folio(offset, iter.count(), &mut prepared_end, ra) {
                            Ok(true) => continue 'read,
                            Ok(false) => break 'read,
                            Err(error) => Err(error),
                        }
                    }
                };
                let (copied, window) = match result {
                    Ok(result) => result,
                    Err(error) if total == 0 => return Err(error),
                    Err(_) => break 'read,
                };
                if let Some((range, marker)) = window {
                    // Both folio and policy guards are gone before invalidation or I/O.
                    self.advance_readahead(range, marker);
                }
                offset += copied as u64;
                total += copied;
                if copied < page_remaining || iter.count() == 0 {
                    break 'read;
                }
            }
        }
        if total != 0 {
            ra.lock().record_position(offset);
        }
        Ok(total)
    }