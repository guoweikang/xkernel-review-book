fn set_super_private<T>(&mut self, private: T) -> VfsResult<()>
    where
        T: Any + Send + Sync,
    {
        self.proposed_super_private = Some(KBox::new(private)?);
        Ok(())
    }