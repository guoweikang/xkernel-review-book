fn set_nonblocking(&mut self, flag: bool) {
        if flag {
            self.flags.insert(OpenFlags::NONBLOCK);
        } else {
            self.flags.remove(OpenFlags::NONBLOCK);
        }
    }