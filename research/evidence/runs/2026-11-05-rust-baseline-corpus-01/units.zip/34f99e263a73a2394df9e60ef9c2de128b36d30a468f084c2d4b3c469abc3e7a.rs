fn pid(&self) -> i32 {
        if matches!(self.owner, FileLockOwner::Ofd(_)) {
            -1
        } else {
            self.pid
        }
    }