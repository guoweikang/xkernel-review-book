fn node_type(&self) -> NodeType {
        self.inode().node_type()
    }