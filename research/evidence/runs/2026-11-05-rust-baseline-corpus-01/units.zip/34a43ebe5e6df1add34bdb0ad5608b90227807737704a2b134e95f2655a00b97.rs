const fn mapped_extents(&self) -> u32 {
        self.extents_mapped
    }