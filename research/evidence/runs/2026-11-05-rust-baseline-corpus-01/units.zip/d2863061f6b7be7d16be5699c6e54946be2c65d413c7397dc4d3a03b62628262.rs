fn do_dentry_open(mut self) -> VfsResult<Arc<VfsFile>> {
        let location = self.location()?.clone();

        if self.flags.contains(OpenFlags::PATH) {
            self.mode = FMode::PATH;
            self.install_operations(Arc::new(EmptyFileOperations));
            self.mark_opened()?;
            return self.finish();
        }

        if matches!(
            location.inode().node_type(),
            NodeType::RegularFile | NodeType::Directory
        ) {
            self.mode.insert(FMode::ATOMIC_POS);
        }
        self.mode
            .insert(FMode::LSEEK | FMode::PREAD | FMode::PWRITE);

        let operations = location.inode().open_file_operations().clone();
        self.install_operations(operations.clone());
        if default_direct(location.path(), self.flags) {
            self.mode.insert(FMode::CAN_ODIRECT);
        }
        let holds_write_access = self.mode.contains(FMode::WRITE)
            && !matches!(
                location.inode().node_type(),
                NodeType::CharacterDevice
                    | NodeType::BlockDevice
                    | NodeType::Fifo
                    | NodeType::Socket
            );
        if holds_write_access {
            location.inode().acquire_write_access();
            self.mode.insert(FMode::WRITER);
        }
        if let Err(error) = operations.open(location.inode().as_ref(), &mut self) {
            if holds_write_access {
                location.inode().release_write_access();
            }
            return Err(error);
        }
        self.flags.remove(
            OpenFlags::CREATE
                | OpenFlags::EXCLUSIVE
                | OpenFlags::NO_CONTROLLING_TTY
                | OpenFlags::TRUNCATE,
        );
        if let Err(error) = self.mark_opened() {
            if holds_write_access {
                location.inode().release_write_access();
            }
            return Err(error);
        }
        self.finish()
    }