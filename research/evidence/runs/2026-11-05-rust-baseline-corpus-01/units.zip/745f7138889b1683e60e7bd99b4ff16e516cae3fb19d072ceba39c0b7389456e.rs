unsafe fn record(&self) -> FileLock {
        // SAFETY: the caller establishes exclusive range ownership or immutable
        // waiter provenance. No shared reference to the cell escapes this copy.
        let bounds = unsafe { *self.bounds.get() };
        FileLock {
            owner: self.owner,
            kind: self.kind,
            pid: self.pid,
            bounds,
        }
    }