fn fallocate(
        &self,
        _file: &VfsFile,
        _flags: FallocateFlags,
        _offset: u64,
        _len: u64,
    ) -> VfsResult<()> {
        // Linux answers EOPNOTSUPP when a file's operation table has no
        // fallocate handler (fs/open.c:323); the same errno replaces the
        // generic `Unsupported` (ENOSYS) here.
        Err(VfsError::from(LinuxError::EOPNOTSUPP))
    }