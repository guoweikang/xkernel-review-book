fn is_path(&self) -> bool {
        self.mode().contains(FMode::PATH)
    }