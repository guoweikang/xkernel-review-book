fn registered_filesystems() -> Vec<&'static FileSystemType> {
    FILE_SYSTEMS.lock().clone()
}