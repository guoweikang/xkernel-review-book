fn read_folio(&self, _mapping: &AddressSpace, mut folio: FolioRead) -> VfsResult<()> {
        let page = folio.data();
        page.fill(0);
        folio.complete(Ok(()))
    }