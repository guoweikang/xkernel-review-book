fn id(&self) -> MappingViewId {
        self.inner.id
    }