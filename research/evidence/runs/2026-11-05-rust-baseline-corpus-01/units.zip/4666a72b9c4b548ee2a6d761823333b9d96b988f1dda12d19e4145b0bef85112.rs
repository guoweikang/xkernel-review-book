fn unlink_with_pathname(
        &self,
        name: &str,
        has_trailing_slash: bool,
        cred: &Cred,
    ) -> VfsResult<()> {
        self.unlink_with_pathname_tracked(name, has_trailing_slash, cred)
            .map(|_| ())
    }