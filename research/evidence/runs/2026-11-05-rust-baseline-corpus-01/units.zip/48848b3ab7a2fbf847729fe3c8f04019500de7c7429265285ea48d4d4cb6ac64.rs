fn release_folio(&self, _mapping: &AddressSpace, _folio: &FolioGuard<'_>) -> VfsResult<bool> {
        Ok(true)
    }