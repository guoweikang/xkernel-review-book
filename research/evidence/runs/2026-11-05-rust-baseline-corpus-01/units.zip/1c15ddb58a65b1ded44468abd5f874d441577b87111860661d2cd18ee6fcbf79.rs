fn pop_front(&mut self) -> Option<OwnedLock> {
        self.0.pop_front().map(OwnedLock)
    }