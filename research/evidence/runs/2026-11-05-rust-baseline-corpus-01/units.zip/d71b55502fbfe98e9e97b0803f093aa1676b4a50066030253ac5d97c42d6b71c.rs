fn rmdir(&self, name: &str, cred: &Cred) -> VfsResult<()> {
        self.rmdir_tracked(name, cred).map(|_| ())
    }