fn verify_read_area(&self, pos: u64, count: usize) -> VfsResult<()> {
        self.verify_mode(FMode::READ)?;
        if !self.mode().contains(FMode::CAN_READ) {
            return Err(VfsError::InvalidInput);
        }
        self.verify_io_area(pos, count)
    }