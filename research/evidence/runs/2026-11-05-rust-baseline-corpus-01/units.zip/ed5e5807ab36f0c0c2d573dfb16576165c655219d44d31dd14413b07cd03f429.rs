fn alloc_file_pseudo(
        self: &Arc<Self>,
        inode: Arc<VfsInode>,
        name: &str,
        flags: FMode,
        open_flags: OpenFlags,
        f_op: Arc<dyn FileOperations>,
        cred: Arc<Cred>,
    ) -> VfsResult<Arc<VfsFile>> {
        let dentry = Dentry::new_file_from_inode(inode, None, name.to_string());
        dentry.bind_super_block(self.super_block());
        let path = Path::new(self.clone(), dentry);
        let mut file = VfsFileBuilder::from_path_state(path, flags, open_flags, f_op, cred);
        file.mark_opened()?;
        file.finish()
    }