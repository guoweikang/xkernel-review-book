fn append_remaining(source: &mut LockList, target: &mut LockList) {
        while let Some(lock) = source.pop_front() {
            target.push_back(lock);
        }
    }