fn evict(&self) -> VfsResult<()> {
        self.truncate_final()
    }