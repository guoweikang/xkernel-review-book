fn mapping_operations(&self) -> Option<&dyn FileMappingOperations> {
        None
    }