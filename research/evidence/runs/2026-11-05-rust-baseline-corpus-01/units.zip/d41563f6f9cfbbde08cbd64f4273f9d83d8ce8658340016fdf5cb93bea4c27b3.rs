fn clone_with_root_and_pwd(&self, root: &Path, pwd: &Path) -> VfsResult<NamespaceClone> {
        let _mounts_guard = self.mounts.lock();
        let mut mount_map = HashMap::new();
        let cloned_root = clone_mount_tree(&self.root, None, &mut mount_map);
        let namespace = Arc::new(Self {
            id: NamespaceId::new(),
            user_ns: self.user_ns.clone(),
            root: cloned_root,
            mounts: Mutex::default(),
        });
        {
            let mut mounts = namespace.mounts.lock();
            for mount in mount_map.values() {
                mounts.insert(mount.mount_id(), mount.clone());
            }
        }

        Ok(NamespaceClone {
            namespace,
            root: retarget_path(root, &mount_map)?,
            pwd: retarget_path(pwd, &mount_map)?,
        })
    }