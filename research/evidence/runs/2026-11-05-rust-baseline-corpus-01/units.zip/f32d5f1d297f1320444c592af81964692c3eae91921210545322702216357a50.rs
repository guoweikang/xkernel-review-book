fn is_nonblocking(&self) -> bool {
        self.flags().contains(OpenFlags::NONBLOCK)
    }