fn make_mount_slave(&self, target: &Path) -> VfsResult<()> {
        let mounts = self.mounts.lock();
        Self::registered_mount_at(&mounts, target)?;
        Ok(())
    }