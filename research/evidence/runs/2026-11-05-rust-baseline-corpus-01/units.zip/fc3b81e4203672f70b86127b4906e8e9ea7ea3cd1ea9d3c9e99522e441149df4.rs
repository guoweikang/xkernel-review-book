fn unsupported_get_tree(
    _context: &mut FsContext<'_>,
    _lookup_root: &crate::Path,
    _lookup_pwd: &crate::Path,
) -> VfsResult<Arc<SuperBlock>> {
    Err(VfsError::NoSuchDevice)
}