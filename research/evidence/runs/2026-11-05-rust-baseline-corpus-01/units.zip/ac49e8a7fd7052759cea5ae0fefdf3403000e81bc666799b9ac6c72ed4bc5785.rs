fn has_mount_under(&self, path: &Path) -> bool {
        let source = path.mount();
        let mounts = self.mounts.lock();
        mounts.values().any(|mount| {
            !Arc::ptr_eq(mount, source)
                && mount
                    .location()
                    .is_some_and(|loc| Self::is_reachable_from(&loc, path))
        })
    }