fn init_internal_context(context: &mut FsContext<'_>) -> VfsResult<()> {
    context.set_operations(&INTERNAL_CONTEXT_OPERATIONS);
    Ok(())
}