fn initial_size(request_pages: u64, max: u64) -> u64 {
        let size_pages = request_pages.min(max).next_power_of_two();
        if size_pages <= max / 32 {
            size_pages * 4
        } else if size_pages <= max / 4 {
            size_pages * 2
        } else {
            max
        }
    }