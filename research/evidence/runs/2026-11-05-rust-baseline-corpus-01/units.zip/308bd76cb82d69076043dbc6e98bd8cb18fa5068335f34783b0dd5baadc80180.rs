fn invalidate_folio(
        &self,
        _mapping: &AddressSpace,
        _folio: &mut FolioGuard<'_>,
        _offset: usize,
        _len: usize,
    ) -> VfsResult<()> {
        Ok(())
    }