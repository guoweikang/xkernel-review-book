fn copy_chunk_from(
        &self,
        input: &VfsFile,
        input_pos: u64,
        output_pos: u64,
        len: usize,
    ) -> Option<KResult<usize>> {
        self.operations()
            .copy_chunk_from(input, input_pos, self, output_pos, len)
    }