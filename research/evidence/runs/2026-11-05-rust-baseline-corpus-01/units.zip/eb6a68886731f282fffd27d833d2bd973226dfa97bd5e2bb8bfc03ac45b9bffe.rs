fn remove_child_mount(&self, mountpoint: &Dentry) {
        self.mnt_mounts.lock().remove(&mountpoint.key());
    }