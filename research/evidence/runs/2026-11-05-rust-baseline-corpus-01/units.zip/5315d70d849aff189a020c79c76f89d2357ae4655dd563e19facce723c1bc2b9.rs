fn is_flock(self) -> bool {
        matches!(self, Self::Flock(_))
    }