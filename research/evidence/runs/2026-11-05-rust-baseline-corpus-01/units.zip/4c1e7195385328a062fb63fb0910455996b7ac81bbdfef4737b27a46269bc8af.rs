fn user_ns(&self) -> &Arc<UserNamespace> {
        &self.user_ns
    }