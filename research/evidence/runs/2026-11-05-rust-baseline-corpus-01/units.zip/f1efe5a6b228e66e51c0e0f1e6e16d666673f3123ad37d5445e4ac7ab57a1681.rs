fn operations(&self) -> VfsResult<&'static FsContextOperations> {
        self.operations.ok_or(VfsError::InvalidInput)
    }