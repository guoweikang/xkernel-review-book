fn new(inode: WeakVfsInode, ops: &'static dyn AddressSpaceOperations) -> Arc<Self> {
        Self::with_residency(inode, ops, None)
    }