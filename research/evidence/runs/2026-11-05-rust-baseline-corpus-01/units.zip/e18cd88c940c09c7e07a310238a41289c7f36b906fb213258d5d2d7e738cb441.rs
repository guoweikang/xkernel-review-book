fn remove_posix_locks(&self, owner: crate::FileLockOwner) {
        // Close has no lock-error channel and must release even after a failed
        // filesystem flush. Dispatch through the same operation as acquisition.
        let _ = self
            .operations()
            .lock(self, &crate::FileLock::unlock(owner), false);
    }