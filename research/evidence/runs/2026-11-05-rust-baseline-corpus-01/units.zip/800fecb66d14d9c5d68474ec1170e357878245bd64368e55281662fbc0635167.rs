const fn internal(name: &'static str) -> Self {
        Self {
            name,
            init_fs_context: init_internal_context,
            fs_flags: FileSystemTypeFlags::empty(),
        }
    }