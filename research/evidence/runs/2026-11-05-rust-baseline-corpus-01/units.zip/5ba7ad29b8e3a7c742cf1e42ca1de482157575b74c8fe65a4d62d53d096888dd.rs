fn allocate(open_flags: OpenFlags, cred: Arc<Cred>) -> VfsResult<Self> {
        Ok(Self::empty(
            FMode::from_open_flags(open_flags),
            open_flags,
            cred,
        ))
    }