fn default_direct(path: &Path, open_flags: OpenFlags) -> bool {
    let inode = path.inode();
    let direct = !path.is_dir()
        && (open_flags.intersects(OpenFlags::DIRECT | OpenFlags::PATH)
            || matches!(
                inode.node_type(),
                NodeType::CharacterDevice | NodeType::Fifo | NodeType::Socket
            )
            || inode.flags().contains(NodeFlags::NON_CACHEABLE));
    direct && !inode.flags().contains(NodeFlags::ALWAYS_CACHE)
}