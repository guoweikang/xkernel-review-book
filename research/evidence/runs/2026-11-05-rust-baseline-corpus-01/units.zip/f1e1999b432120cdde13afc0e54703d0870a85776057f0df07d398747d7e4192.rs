fn simple_rename(
    _idmap: &MountIdmap,
    old_dir: &VfsInode,
    old_dentry: &LockedDentry<'_>,
    new_dir: &VfsInode,
    new_dentry: &LockedDentry<'_>,
    flags: RenameFlags,
) -> VfsResult<()> {
    let old_dentry = old_dentry.as_dentry();
    let new_dentry = new_dentry.as_dentry();
    let they_are_dirs = old_dentry.is_dir();

    let supported_flags = RenameFlags::NOREPLACE | RenameFlags::EXCHANGE;
    if !supported_flags.contains(flags) || flags.has_conflicting_modes() {
        return Err(VfsError::InvalidInput);
    }
    if flags.contains(RenameFlags::EXCHANGE) {
        return simple_rename_exchange(old_dir, old_dentry, new_dir, new_dentry);
    }
    if flags.contains(RenameFlags::NOREPLACE) && d_really_is_positive(new_dentry) {
        return Err(VfsError::AlreadyExists);
    }

    if !simple_empty(new_dentry)? {
        return Err(VfsError::DirectoryNotEmpty);
    }

    if d_really_is_positive(new_dentry) {
        simple_unlink(new_dir, new_dentry)?;
        if they_are_dirs {
            new_dentry.decrement_link_count();
            old_dir.decrement_link_count();
        }
    } else if they_are_dirs {
        old_dir.decrement_link_count();
        new_dir.increment_link_count();
    }

    simple_rename_timestamp(old_dir, old_dentry, new_dir, new_dentry);
    Ok(())
}