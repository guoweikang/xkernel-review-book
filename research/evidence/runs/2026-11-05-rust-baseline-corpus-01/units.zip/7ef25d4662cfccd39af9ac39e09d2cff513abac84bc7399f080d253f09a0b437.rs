fn location(&self) -> VfsResult<&FileLocation> {
        self.location.as_ref().ok_or(VfsError::InvalidInput)
    }