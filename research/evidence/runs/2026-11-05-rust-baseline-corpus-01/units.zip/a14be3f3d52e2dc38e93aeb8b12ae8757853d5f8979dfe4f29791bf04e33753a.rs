fn supported_fallocate_modes(&self) -> FallocateFlags {
        FallocateFlags::empty()
    }