fn mark_created(&mut self) {
        self.mode.insert(FMode::CREATED);
    }