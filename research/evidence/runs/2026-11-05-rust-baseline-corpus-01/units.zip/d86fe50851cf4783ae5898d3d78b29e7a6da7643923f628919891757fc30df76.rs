fn write_iter(&self, iter: &mut IovIterSource<'_>) -> VfsResult<usize> {
        if self.is_stream() {
            return self.write_iter_from(iter, &mut 0);
        }
        let mut pos = self.position_lock();
        self.write_iter_from(iter, &mut pos)
    }