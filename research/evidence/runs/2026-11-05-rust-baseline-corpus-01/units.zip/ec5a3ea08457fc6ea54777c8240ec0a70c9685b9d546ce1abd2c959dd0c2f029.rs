fn require_mount(mounts: &HashMap<u64, Arc<Mount>>, mount: &Arc<Mount>) -> VfsResult<()> {
        mounts
            .get(&mount.mount_id())
            .is_some_and(|registered| Arc::ptr_eq(registered, mount))
            .then_some(())
            .ok_or(VfsError::InvalidInput)
    }