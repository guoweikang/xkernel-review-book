const fn name(&self) -> &'static str {
        self.name
    }