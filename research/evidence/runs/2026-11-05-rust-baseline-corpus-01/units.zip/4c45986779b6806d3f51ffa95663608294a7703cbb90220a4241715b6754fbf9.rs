fn is_dir(&self) -> bool {
        self.node_type() == NodeType::Directory
    }