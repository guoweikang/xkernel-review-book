fn nrpages(&self) -> u64 {
        self.i_pages.nrpages()
    }