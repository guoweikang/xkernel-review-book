fn find(&self, matches: impl Fn(&FileLock) -> bool) -> Option<Blocker> {
        LockNode::find(&self.0, |node| {
            // SAFETY: same owning-list borrow as iter(); no range reference escapes.
            matches(&unsafe { node.record() })
        })
        .map(Blocker)
    }