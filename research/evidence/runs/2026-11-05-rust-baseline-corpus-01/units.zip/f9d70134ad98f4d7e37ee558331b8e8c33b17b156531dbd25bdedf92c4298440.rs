fn clear_created(&mut self) {
        self.mode.remove(FMode::CREATED);
    }