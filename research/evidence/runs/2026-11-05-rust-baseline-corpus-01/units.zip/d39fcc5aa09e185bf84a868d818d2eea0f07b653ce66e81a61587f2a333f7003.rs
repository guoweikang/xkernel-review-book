fn drop(&mut self) {
        self.mnt_sb.deactivate_mount();
    }