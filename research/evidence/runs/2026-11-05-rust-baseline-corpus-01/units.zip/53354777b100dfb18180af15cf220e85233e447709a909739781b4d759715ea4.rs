fn downcast_node<T: core::any::Any + Send + Sync>(&self) -> VfsResult<Arc<T>> {
        self.inode().downcast()
    }