fn set_lock(&self, request: &crate::FileLock, is_blocking: bool) -> VfsResult<()> {
        if matches!(request.owner(), crate::FileLockOwner::Flock(_)) {
            self.operations().flock(self, request, is_blocking)
        } else {
            self.operations().lock(self, request, is_blocking)
        }
    }