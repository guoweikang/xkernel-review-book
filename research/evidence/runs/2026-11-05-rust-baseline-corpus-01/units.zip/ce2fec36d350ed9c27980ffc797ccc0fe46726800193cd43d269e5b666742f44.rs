fn on_marker(
        &mut self,
        index: PageIndex,
        request_pages: u64,
        next_miss: impl FnOnce(u64) -> Option<PageIndex>,
    ) -> Option<(Range<PageIndex>, Option<PageIndex>)> {
        let max = self.ra_pages;
        if max == 0 {
            return None;
        }
        if self.size_pages != 0 && index == self.start + self.size_pages - self.async_size_pages {
            self.start += self.size_pages;
            self.size_pages = Self::next_size(self.size_pages, max);
        } else {
            // A different open or interleaved stream may consume the shared marker.
            let start = next_miss(max)?;
            self.start = start;
            self.size_pages = Self::next_size((start - index).saturating_add(request_pages), max);
        }
        self.async_size_pages = self.size_pages;
        Some(self.window())
    }