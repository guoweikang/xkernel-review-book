fn disable_pwrite(&mut self) {
        self.mode &= !FMode::PWRITE;
    }