fn init_context(&self, context: &mut FsContext<'_>) -> VfsResult<()> {
        (self.init_fs_context)(context)
    }