const fn pos(self) -> u64 {
        self.pos
    }