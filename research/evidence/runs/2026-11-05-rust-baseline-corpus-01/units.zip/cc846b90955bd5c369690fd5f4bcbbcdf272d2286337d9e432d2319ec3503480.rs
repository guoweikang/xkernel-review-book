fn as_path(&self) -> Option<&Path> {
        match self {
            Self::Path(location) => Some(location),
            Self::MagicLink(_) => None,
        }
    }