fn super_private<T>(&self) -> VfsResult<&T>
    where
        T: Any + Send + Sync,
    {
        self.proposed_super_private
            .as_deref()
            .and_then(|private| private.downcast_ref::<T>())
            .ok_or(VfsError::InvalidInput)
    }