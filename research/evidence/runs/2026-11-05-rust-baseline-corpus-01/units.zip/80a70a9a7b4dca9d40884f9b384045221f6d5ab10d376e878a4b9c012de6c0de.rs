fn root_mount(&self) -> &Arc<Mount> {
        &self.root
    }