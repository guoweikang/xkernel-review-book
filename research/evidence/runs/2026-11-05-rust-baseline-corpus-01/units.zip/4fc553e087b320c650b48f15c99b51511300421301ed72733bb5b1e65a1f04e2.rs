fn flags(&self) -> KiocbFlags {
        self.flags
    }