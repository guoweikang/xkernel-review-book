fn flush(&self, _file: &VfsFile) -> VfsResult<()> {
        Ok(())
    }