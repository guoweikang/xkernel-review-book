fn __simple_unlink(_dir: &VfsInode, dentry: &Dentry) {
    dentry.decrement_link_count();
}