fn next_size(size_pages: u64, max: u64) -> u64 {
        if size_pages < max / 16 {
            size_pages * 4
        } else if size_pages <= max / 2 {
            size_pages * 2
        } else {
            max
        }
    }