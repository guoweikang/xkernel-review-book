fn initialize(mut context: Self) -> VfsResult<Self> {
        context.fs_type.init_context(&mut context)?;
        if context.operations.is_none() {
            return Err(VfsError::InvalidInput);
        }
        Ok(context)
    }