fn register_poll(
        &self,
        context: &mut PollContext<'_>,
        events: IoEvents,
    ) -> Result<(), PollRegisterError> {
        self.operations().register_poll(self, context, events)
    }