fn writepages(&self, data_only: bool) -> VfsResult<()> {
        let mut control = WritebackControl::all(data_only);
        self.writepages_control(&mut control)
    }