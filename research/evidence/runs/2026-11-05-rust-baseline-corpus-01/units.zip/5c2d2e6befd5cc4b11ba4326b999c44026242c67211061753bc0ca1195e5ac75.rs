fn set_sb_flags_mask(&mut self, mask: SuperBlockFlags) {
        self.sb_flags_mask = mask;
    }