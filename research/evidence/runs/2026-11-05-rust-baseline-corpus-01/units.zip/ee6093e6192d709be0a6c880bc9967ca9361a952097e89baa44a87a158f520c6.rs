fn verify_mode(&self, flags: FMode) -> VfsResult<()> {
        if self.mode().contains(flags) && !self.is_path() {
            Ok(())
        } else {
            Err(VfsError::BadFileDescriptor)
        }
    }