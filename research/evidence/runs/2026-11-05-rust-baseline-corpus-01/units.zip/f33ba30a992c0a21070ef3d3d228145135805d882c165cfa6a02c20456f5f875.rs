fn unregister_view(&self, id: MappingViewId) {
        self.views.lock().remove(&id);
    }