fn unlock(owner: FileLockOwner) -> Self {
        Self::range(owner, 0, FileLockType::Unlock, 0, i64::MAX)
    }