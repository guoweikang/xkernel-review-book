fn read_only_block_device_cannot_be_reconfigured_read_write() {
    FILL_COUNT.store(0, Ordering::Relaxed);
    let (disk, block_device) = add_test_disk("kvfs-read-only-remount", 249);
    block_device
        .set_disk_read_only(true)
        .expect("make backing device read-only");
    let super_block = super_block_registry()
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device,
            SuperBlockFlags::RDONLY,
            fill_test_bdev,
        )
        .expect("mount read-only device read-only");
    super_block.activate_mount();
    let cred = kcred::initial_cred();
    let mut context = FsContext::new_reconfigure(
        super_block.as_ref(),
        None,
        None,
        SuperBlockFlags::empty(),
        SuperBlockFlags::RDONLY,
        &cred,
    )
    .expect("construct writable reconfigure context");

    assert_eq!(
        super_block.reconfigure(&mut context),
        Err(VfsError::PermissionDenied)
    );
    assert!(super_block.flags().contains(SuperBlockFlags::RDONLY));

    super_block.deactivate_mount();
    block::del_gendisk(disk.device_number()).expect("remove read-only remount disk");
}