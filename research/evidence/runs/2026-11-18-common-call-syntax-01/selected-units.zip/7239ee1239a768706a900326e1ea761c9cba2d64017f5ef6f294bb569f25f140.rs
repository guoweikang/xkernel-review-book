fn try_new_detached(
        fs: &Arc<SuperBlock>,
        flags: MountFlags,
        devname: Option<&str>,
        requested_superblock_flags: Option<SuperBlockFlags>,
    ) -> VfsResult<Option<Self>> {
        let Some(mnt) = VfsMount::try_new(fs, flags, requested_superblock_flags)? else {
            return Ok(None);
        };
        Ok(Some(Self {
            mnt,
            mnt_location: Mutex::default(),
            mnt_mounts: Mutex::default(),
            mnt_id: MOUNT_ID_COUNTER.fetch_add(1, Ordering::Relaxed),
            covers: Mutex::default(),
            mnt_devname: devname.map(|s| s.to_string()),
        }))
    }