fn finish_eviction(&self, inode: &VfsInode, key: &InodeCacheKey) {
        let mut inodes = self.inodes.lock();
        let is_evicting_inode = matches!(
            inodes.get(key),
            Some(entry)
                if matches!(
                    &entry.state,
                    CachedInodeState::Freeing(cached)
                        if core::ptr::eq(cached.as_ptr(), inode)
                )
        );
        let waiters = is_evicting_inode
            .then(|| inodes.remove(key))
            .flatten()
            .map(|entry| entry.waiters);
        drop(inodes);
        if let Some(waiters) = waiters {
            waiters.notify_all(false);
        }
    }