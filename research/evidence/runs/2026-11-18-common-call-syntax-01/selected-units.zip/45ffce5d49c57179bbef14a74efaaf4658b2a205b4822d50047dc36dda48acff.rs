fn cap_dac_read_search_grants_read_and_directory_search_but_not_write() {
    let cred = capped(&[CAP_DAC_READ_SEARCH]);
    let file = meta(2000, 2000, 0o000);

    assert!(check_dac_permission(&file, Permission::MAY_READ, &cred).is_ok());
    assert!(check_dac_permission(&file, Permission::MAY_WRITE, &cred).is_err());

    assert!(
        check_dac_permission(&file, Permission::MAY_EXEC, &cred).is_err(),
        "CAP_DAC_READ_SEARCH does not grant execute on regular files"
    );

    let mut directory = meta(2000, 2000, 0o000);
    directory.mode = directory.mode.with_node_type(NodeType::Directory);
    assert!(check_dac_permission(&directory, Permission::MAY_READ, &cred).is_ok());
    assert!(check_dac_permission(&directory, Permission::MAY_EXEC, &cred).is_ok());
    assert!(check_dac_permission(&directory, Permission::MAY_WRITE, &cred).is_err());
}