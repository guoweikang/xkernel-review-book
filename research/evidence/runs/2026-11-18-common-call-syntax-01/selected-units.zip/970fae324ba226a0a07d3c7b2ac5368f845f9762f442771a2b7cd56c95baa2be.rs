fn poll(&self) -> IoEvents {
        let state = self.state.lock();
        let mut events = IoEvents::empty();
        events.set(IoEvents::IN, !state.buffer.is_empty());
        events.set(IoEvents::OUT, state.buffer.len() < state.capacity);
        events.set(IoEvents::HUP, state.writers == 0);
        events.set(IoEvents::ERR, state.readers == 0);
        events
    }