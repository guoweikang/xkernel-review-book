fn trailing_slash_survives_final_symlink_expansion() {
    let tree = test_tree();

    // `link` points at the regular file `target`: the trailing slash still
    // demands a directory, and the demand must not be lost when the final
    // symlink is expanded (Linux keeps it in `nd->flags`).
    let err = Filename::new("/link/")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            linux_raw_sys::general::O_RDONLY,
            NodePermission::default(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .map(|_| ())
        .unwrap_err();
    assert_eq!(err, VfsError::NotADirectory);

    // A symlink to a directory keeps accepting the trailing slash.
    Filename::new("/dirlink/")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            linux_raw_sys::general::O_RDONLY,
            NodePermission::default(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .map(|_| ())
        .unwrap();
}