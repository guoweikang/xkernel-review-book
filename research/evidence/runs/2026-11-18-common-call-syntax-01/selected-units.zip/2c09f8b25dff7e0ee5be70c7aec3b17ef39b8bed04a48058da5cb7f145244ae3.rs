fn test_invalidate_cached_child_handles_negative_dentry() {
    let fs = Arc::new(MockFilesystem);
    let root = make_dir_entry(fs, 20, "");
    let negative = Dentry::new_negative(Some(root.clone()), String::from("missing"));

    root.insert_cache(negative.name_snapshot(), negative.clone());
    assert!(root.lookup_cache("missing").unwrap().ptr_eq(&negative));

    root.invalidate_cached_child("missing").unwrap();
    assert!(root.lookup_cache("missing").is_none());
}