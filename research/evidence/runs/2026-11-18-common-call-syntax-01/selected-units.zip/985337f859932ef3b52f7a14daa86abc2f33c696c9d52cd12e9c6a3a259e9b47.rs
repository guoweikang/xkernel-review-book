fn cdev_inode_cache_distinguishes_registrations_of_the_same_backend() {
    let first = DeviceId::new(242, 10);
    let ops: Arc<dyn DeviceFileOps> = Arc::new(TestDeviceOps);
    let _registration = TestRegistration::new(first, 3, ops.clone());
    let inode = test_character_inode(DeviceId::new(242, 11));
    assert!(Arc::ptr_eq(&character_operations(&inode).unwrap(), &ops));
    let old_entry = inode.character_device().unwrap();
    drop(cdev_del(first, 3).unwrap());
    assert!(old_entry.live_operations().is_none());
    assert!(character_operations(&inode).is_none());

    // Even reusing the same backend Arc must create a distinct registration.
    cdev_add(first, 3, ops.clone()).unwrap();
    assert!(Arc::ptr_eq(&character_operations(&inode).unwrap(), &ops));
    let new_entry = inode.character_device().unwrap();
    assert!(!Arc::ptr_eq(&old_entry, &new_entry));
    assert!(old_entry.live_operations().is_none());
    drop(old_entry);
    assert!(Arc::ptr_eq(&character_operations(&inode).unwrap(), &ops));
}