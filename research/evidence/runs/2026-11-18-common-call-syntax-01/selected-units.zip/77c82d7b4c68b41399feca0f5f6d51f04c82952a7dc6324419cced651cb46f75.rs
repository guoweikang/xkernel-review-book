fn character_adapter_forwards_readiness_event_mask_and_registration_error() {
    let backend = CharacterBackend::new(true, true, false);
    let file = open_test_character(backend.clone()).unwrap();
    assert!(file.poll().is_empty());
    let wake = Arc::new(CharacterWake(AtomicBool::new(false)));
    let waker = Waker::from(wake.clone());
    let cx = Context::from_waker(&waker);
    let mut registrations = PollRegistrations::new();
    file.register_poll(&mut registrations.context(&cx), IoEvents::OUT)
        .unwrap();
    backend.waiters.wake();
    assert!(!wake.0.load(Ordering::Acquire));
    file.register_poll(&mut registrations.context(&cx), IoEvents::IN)
        .unwrap();
    backend.is_ready.store(true, Ordering::Release);
    backend.waiters.wake();
    assert!(wake.0.load(Ordering::Acquire));
    assert_eq!(file.poll().bits(), IoEvents::IN.bits());
    backend.is_ready.store(false, Ordering::Release);
    assert!(file.poll().is_empty());
    backend.reject_registration.store(true, Ordering::Relaxed);
    assert_eq!(
        file.register_poll(&mut registrations.context(&cx), IoEvents::IN),
        Err(PollRegisterError::InvalidState)
    );
}