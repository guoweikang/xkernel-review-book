fn test_hashed_child_without_external_reference_keeps_directory_nonempty() {
    let fs = Arc::new(MockFilesystem);
    let root = make_dir_entry(fs.clone(), 17, "");
    let _super_block = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        root.clone()
    });
    let directory = make_dir_entry_with_parent(fs.clone(), 18, Some(root.clone()), "directory");
    root.insert_cache(String::from("directory"), directory.clone());
    let (child, _) = make_file_entry(fs, 19, Some(directory.clone()), "child");
    directory.insert_cache(String::from("child"), child.clone());

    drop(child);

    assert!(directory.has_positive_children());
}