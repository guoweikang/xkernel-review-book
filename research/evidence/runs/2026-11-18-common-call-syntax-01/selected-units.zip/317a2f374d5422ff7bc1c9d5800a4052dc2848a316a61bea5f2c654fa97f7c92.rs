fn capped(caps: &[u32]) -> Cred {
    let bits = caps
        .iter()
        .fold(0, |bits, &capability| bits | (1u64 << capability));
    let setup = CapSet::from_bits(bits | (1u64 << CAP_SETUID));
    let effective = CapSet::from_bits(bits);

    let mut cred = Cred::root();
    cred.keep_caps_enable().unwrap();
    cred.set_capabilities(CapSets::new(setup, setup, CapSet::EMPTY))
        .unwrap();
    cred.set_uid(1000).unwrap();
    cred.set_capabilities(CapSets::new(effective, effective, CapSet::EMPTY))
        .unwrap();
    assert_eq!(cred.fsuid(), 1000);
    cred
}