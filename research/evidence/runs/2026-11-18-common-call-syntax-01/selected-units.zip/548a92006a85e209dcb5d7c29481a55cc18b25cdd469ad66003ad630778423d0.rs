fn register_device_access_policy(
    policy: Option<Arc<dyn DeviceAccessPolicy>>,
) -> Result<(), Arc<dyn DeviceAccessPolicy>> {
    let mut slot = DEVICE_ACCESS_POLICY.write();
    match (&*slot, &policy) {
        (Some(existing), Some(_)) => Err(existing.clone()),
        _ => {
            *slot = policy;
            Ok(())
        }
    }
}