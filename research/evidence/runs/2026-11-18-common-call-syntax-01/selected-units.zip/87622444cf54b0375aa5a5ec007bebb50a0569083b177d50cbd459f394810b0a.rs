fn mod_test(_attr: TokenStream, item: TokenStream) -> TokenStream {
    let mut module = parse_macro_input!(item as ItemMod);

    // An inline module takes the allowances as inner attributes, a file module
    // (`mod foo;`) as outer ones. rustc currently rejects attribute macros on
    // file modules (E0658), so the outer form is not reachable on stable.
    let mut allows: [Attribute; 3] = [
        parse_quote! {
            #[allow(
                clippy::unwrap_used,
                clippy::expect_used,
                clippy::panic,
                reason = "CG-021-no-panic-on-reachable-failure: unittest module: test helpers may panic on failure"
            )]
        },
        parse_quote! {
            #[allow(missing_docs, reason = "CG-024-lint-exceptions: missing_docs: unittest module: test code is outside rustdoc scope")]
        },
        parse_quote! {
            #[allow(
                clippy::too_many_lines,
                reason = "CG-028-focused-functions: unittest module: a test scenario reads as one linear script"
            )]
        },
    ];
    if module.content.is_some() {
        for attr in &mut allows {
            attr.style = AttrStyle::Inner(Token![!](Span::call_site()));
        }
    }
    module.attrs.extend(allows);

    quote! {
        #[cfg(unittest)]
        #module
    }
    .into()
}