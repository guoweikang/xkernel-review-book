fn fill_next_extent_rejects_invalid_ranges() {
    let mut writer = CollectingWriter::default();
    let mut info = FiemapExtentInfo::new(FiemapFlags::empty(), 1, &mut writer);

    assert!(
        info.fill_next_extent(0, 0, 0, FiemapExtentFlags::empty())
            .is_err()
    );
    assert!(
        info.fill_next_extent(u64::MAX, 0, 1, FiemapExtentFlags::empty())
            .is_err()
    );
    assert!(
        info.fill_next_extent(0, u64::MAX, 1, FiemapExtentFlags::empty())
            .is_err()
    );
}