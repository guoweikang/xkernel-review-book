fn ioctl(&self, file: &VfsFile, cred: &kcred::Cred, cmd: u32, arg: usize) -> VfsResult<usize> {
        let claim = file
            .private_data_get::<block::BlockDeviceClaim>()
            .ok_or_else(|| VfsError::from(LinuxError::ENXIO))?;
        let mut mode = claim.mode();
        mode.set(BlockOpenMode::NONBLOCK, file.is_nonblocking());
        BlockDevice::ioctl(
            self,
            mode,
            cmd,
            arg,
            cred.has_sys_admin(),
            || Ok(i32::from_ne_bytes((arg as *const [u8; 4]).read_vm()?)),
            |bytes| Ok(osvm::write_vm_bytes(arg as *mut u8, bytes)?),
        )
    }