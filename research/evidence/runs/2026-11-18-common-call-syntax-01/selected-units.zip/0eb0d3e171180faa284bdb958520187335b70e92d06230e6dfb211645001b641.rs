fn path_openat(
        root: &Path,
        base: &Path,
        filename: &Filename,
        flags: &OpenParams,
        umask: NodePermission,
        cred: Arc<Cred>,
    ) -> VfsResult<Arc<VfsFile>> {
        let file = VfsFileBuilder::allocate(flags.file_flags(), cred.clone())?;
        if flags.is_path() {
            Self::do_o_path(root, base, filename, file, flags, &cred)
        } else {
            Self::open_path(root, base, filename, file, flags, umask, &cred)
        }
    }