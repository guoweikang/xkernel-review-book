fn default_readahead_initializes_reservations_after_a_read_error() {
    let inode = read_inode(&FAILING_FALLBACK_OPS, 3 * PAGE_SIZE_4K);
    let mapping = inode.address_space();
    let _invalidate = mapping.invalidate_lock.read();
    assert_eq!(
        mapping.sync_readahead(0, 3 * PAGE_SIZE_4K, 3 * PAGE_SIZE_4K as u64),
        3 * PAGE_SIZE_4K as u64
    );
    assert_eq!(mapping.nrpages(), 3);
    for index in [0, 2] {
        mapping
            .with_folio(index, |folio| {
                assert!(
                    folio
                        .unwrap()
                        .data()
                        .iter()
                        .all(|&byte| byte == index as u8)
                );
            })
            .unwrap();
    }
    mapping
        .with_folio(1, |folio| assert!(folio.is_none()))
        .unwrap();
    mapping
        .i_pages
        .with_folio_or_create(
            1,
            |mut folio| {
                folio.data().fill(0x55);
                folio.complete(Ok(()))
            },
            |folio| {
                assert!(folio.is_uptodate());
                Ok(())
            },
        )
        .unwrap();
    assert_eq!(mapping.nrpages(), 3);
}