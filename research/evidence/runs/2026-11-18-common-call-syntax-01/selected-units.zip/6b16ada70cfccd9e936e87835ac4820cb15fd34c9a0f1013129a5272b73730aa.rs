fn chmod(&self, mut mode: NodePermission, cred: &Cred) -> VfsResult<()> {
        self.check_writable_mount()?;
        let metadata = self.metadata();
        if cred.fsuid() != metadata.uid && !cred.has_cap_fowner() {
            return Err(VfsError::OperationNotPermitted);
        }
        if mode.contains(NodePermission::SET_GID)
            && !cred.in_group(metadata.gid)
            && !cred.has_cap(kcred::CAP_FSETID)
        {
            mode.remove(NodePermission::SET_GID);
        }
        self.dentry.update_metadata(MetadataUpdate {
            mode: Some(mode),
            ..Default::default()
        })
    }