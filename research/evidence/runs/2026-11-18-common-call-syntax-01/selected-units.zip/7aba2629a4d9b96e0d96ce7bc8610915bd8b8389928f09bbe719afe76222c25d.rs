fn mkdir(
        &self,
        _idmap: &crate::MountIdmap,
        dir: &VfsInode,
        dentry: &LockedDentry<'_>,
        mode: crate::Umode,
        cred: &Cred,
    ) -> VfsResult<()> {
        let (mode, uid, gid) = crate::inode_init_owner(dir, mode, cred);
        let inode = self.inode + 1;
        let init = VfsInodeInit::new(inode, 0, mode)
            .with_owner_links_and_rdev(uid, gid, 1, Default::default())
            .with_stat_data(
                512,
                1,
                SystemTime::UNIX_EPOCH,
                SystemTime::UNIX_EPOCH,
                SystemTime::UNIX_EPOCH,
            );
        let inode =
            VfsInode::new_openable_dir(Arc::new(MockDirOps::new(self.mount_flags, inode)), init);
        dentry.instantiate(inode)
    }