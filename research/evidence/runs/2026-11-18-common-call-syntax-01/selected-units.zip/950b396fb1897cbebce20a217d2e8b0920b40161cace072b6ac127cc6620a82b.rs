fn has_deadlock(
    blocked: &mut MutexGuard<'_, BlockedOwners>,
    request: &FileLock,
    mut owner: FileLockOwner,
) -> bool {
    if !request.owner.is_posix() {
        return false;
    }
    // Match Linux's bounded owner-chain search, including its OFD exclusion.
    for _ in 0..=10 {
        let Some(mut waiter) = blocked
            .get(&owner)
            .and_then(|requests| requests.values().next())
            .cloned()
        else {
            return false;
        };
        // A waiter can depend on other waiters. Only the root's owner holds
        // the resource whose release will let this chain make progress.
        loop {
            let next = waiter
                .state(blocked)
                .blocker
                .as_ref()
                .and_then(Weak::upgrade);
            match next {
                Some(next) => waiter = next,
                None => break,
            }
        }
        if waiter.owner == request.owner {
            return true;
        }
        owner = waiter.owner;
    }
    false
}