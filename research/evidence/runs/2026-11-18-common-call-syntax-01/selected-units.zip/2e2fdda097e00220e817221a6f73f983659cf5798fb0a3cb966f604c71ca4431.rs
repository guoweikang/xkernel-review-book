fn invalidate(&self, _work: &ObjectInvalidateWork, _hit: &ObjectViewHit) {
        let size = self
            .address_space
            .upgrade()
            .and_then(|mapping| mapping.inode())
            .map(|inode| inode.size())
            .expect("registered address space remains attached to its inode");
        self.observed_sizes.lock().push(size);
    }