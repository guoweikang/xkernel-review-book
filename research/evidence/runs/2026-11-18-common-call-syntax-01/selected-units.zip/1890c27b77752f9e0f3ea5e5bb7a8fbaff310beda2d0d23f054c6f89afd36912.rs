fn write(&self) -> SpinRwLockWriteGuard<'_, G, T> {
        let guard_state = G::acquire();
        #[cfg(feature = "stats")]
        let mut did_wait = false;

        while self
            .state
            .compare_exchange(0, WRITE_LOCKED, Ordering::Acquire, Ordering::Relaxed)
            .is_err()
        {
            #[cfg(feature = "stats")]
            {
                did_wait = true;
            }
            core::hint::spin_loop();
        }

        #[cfg(feature = "stats")]
        self.record_write_acquisition(did_wait);
        SpinRwLockWriteGuard {
            lock: self,
            guard_state,
        }
    }