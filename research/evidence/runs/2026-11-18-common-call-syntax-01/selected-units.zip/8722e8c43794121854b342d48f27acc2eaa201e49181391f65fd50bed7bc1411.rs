fn read_folio(&self, mapping: &AddressSpace, mut folio: FolioRead) -> VfsResult<()> {
        let index = folio.index();
        folio.data().fill((index % 251) as u8);
        let len = mapping
            .visible_len()?
            .saturating_sub(folio.index() * PAGE_SIZE_4K as u64)
            .min(PAGE_SIZE_4K as u64) as usize;
        folio.data()[len..].fill(0);
        folio.complete(Ok(()))
    }