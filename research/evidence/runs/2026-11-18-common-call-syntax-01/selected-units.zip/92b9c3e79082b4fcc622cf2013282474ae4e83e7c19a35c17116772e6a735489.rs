fn writepages(&self, mapping: &AddressSpace, control: &mut WritebackControl) -> VfsResult<()> {
        let inode = mapping.inode().ok_or(VfsError::InvalidInput)?;
        let backing = inode.private::<MockFileOps>()?;
        mapping.writeback_cached_folios(control, |index, buf, valid_len| {
            let start = index
                .checked_mul(PAGE_SIZE_4K as u64)
                .and_then(|offset| usize::try_from(offset).ok())
                .ok_or(VfsError::InvalidInput)?;
            let end = start.checked_add(valid_len).ok_or(VfsError::InvalidInput)?;
            let mut data = backing.data.lock();
            if end > data.len() {
                data.resize(end, 0);
            }
            data[start..end].copy_from_slice(&buf[..valid_len]);
            Ok(())
        })
    }