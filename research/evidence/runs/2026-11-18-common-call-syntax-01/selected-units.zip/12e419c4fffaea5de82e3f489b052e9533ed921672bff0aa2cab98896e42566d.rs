fn try_activate_mount(
        &self,
        requested_flags: Option<SuperBlockFlags>,
    ) -> VfsResult<bool> {
        let _umount_guard = self.umount_lock.lock();
        let mut lifecycle = self.lifecycle.lock();
        if !lifecycle.is_available() {
            return Ok(false);
        }
        // The RO comparison is a block-device rule: Linux `get_tree_bdev()`
        // refuses a bdev superblock whose RO state differs from the request,
        // while nodev/keyed reuse never compares it (the mount's own flag and
        // the superblock flag govern writes independently, so a writable
        // superblock — Linux's shared sysfs instance, say — can back a
        // read-only mount via the per-mount `MNT_READONLY` flag, and writes
        // onto a read-only superblock reused by a writable request are
        // stopped by the path-level EROFS check).
        if self.block_device().is_some()
            && requested_flags
                .is_some_and(|requested| bdev_readonly_mismatch(self.flags(), requested))
        {
            return Err(VfsError::ResourceBusy);
        }
        Ok(lifecycle.try_acquire_mount())
    }