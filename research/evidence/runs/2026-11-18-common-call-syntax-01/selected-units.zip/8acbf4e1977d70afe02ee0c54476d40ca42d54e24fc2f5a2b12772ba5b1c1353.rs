fn context_private_state_replacement_drops_erased_values() {
    use core::sync::atomic::{AtomicUsize, Ordering};

    static DROPS: AtomicUsize = AtomicUsize::new(0);
    struct PrivateState(u64);
    impl Drop for PrivateState {
        fn drop(&mut self) {
            DROPS.fetch_add(1, Ordering::Relaxed);
        }
    }
    let cred = kcred::initial_cred();
    let mut context = FsContext::new(
        &MOCK_FILE_SYSTEM_TYPE,
        None,
        None,
        SuperBlockFlags::empty(),
        &cred,
    )
    .unwrap();
    let before = DROPS.load(Ordering::Relaxed);
    context.set_private(PrivateState(1)).unwrap();
    context.set_super_private(PrivateState(2)).unwrap();
    assert_eq!(context.private::<PrivateState>().unwrap().0, 1);
    assert_eq!(context.super_private::<PrivateState>().unwrap().0, 2);
    context.set_private(PrivateState(3)).unwrap();
    context.set_super_private(PrivateState(4)).unwrap();
    assert_eq!(DROPS.load(Ordering::Relaxed), before + 2);
    assert_eq!(context.private::<PrivateState>().unwrap().0, 3);
    assert_eq!(context.super_private::<PrivateState>().unwrap().0, 4);
    drop(context);
    assert_eq!(DROPS.load(Ordering::Relaxed), before + 4);
}