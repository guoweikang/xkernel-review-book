fn resident_access_preserves_initialization_errors_without_populating_holes() {
    let inode = read_inode(&FAILING_SPARSE_READ_OPS, 2 * PAGE_SIZE_4K);
    let mapping = inode.address_space();
    {
        let _invalidate = mapping.invalidate_lock.read();
        assert_eq!(mapping.with_folio_or_create(1, |_| Ok(())), Err(KError::Io));
    }
    assert_eq!(mapping.nrpages(), 1);
    let mut visited = Vec::new();
    assert_eq!(
        mapping.visit_resident_folios(0, 2, |index, folio| {
            assert!(mapping.invalidate_lock.try_write().is_none());
            assert!(folio.is_none());
            visited.push(index);
            Ok(ControlFlow::Continue(()))
        }),
        Err(KError::Io)
    );
    assert_eq!(visited, vec![0]);
    assert_eq!(
        mapping.visit_resident_folios(1, 1, |_, _| panic!(
            "failed initialization must not appear as a hole"
        )),
        Err(KError::Io)
    );
    assert_eq!(mapping.nrpages(), 1);
}