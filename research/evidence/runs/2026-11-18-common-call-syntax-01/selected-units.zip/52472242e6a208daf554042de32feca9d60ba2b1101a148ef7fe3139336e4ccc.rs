fn read_only_superblock_rejects_a_writable_request() {
    let (disk, block_device) = add_test_disk("kvfs-ro-sb-rw-request", 252);
    let registry = super_block_registry();
    let read_only = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device.clone(),
            SuperBlockFlags::RDONLY,
            fill_test_bdev,
        )
        .expect("read-only request initializes the superblock");
    assert!(read_only.flags().contains(SuperBlockFlags::RDONLY));
    read_only.activate_mount();

    assert_eq!(
        registry
            .get_or_try_init_bdev(
                &BDEV_TEST_FILE_SYSTEM_TYPE,
                block_device,
                SuperBlockFlags::empty(),
                fill_test_bdev,
            )
            .err(),
        Some(VfsError::ResourceBusy)
    );

    read_only.deactivate_mount();
    block::del_gendisk(disk.device_number()).expect("remove ro-sb test disk");
}