fn test_path_normalization_complex() {
    let path = Pathname::new("/foo/bar/../baz/./qux/../file.txt");
    let normalized = path.normalize().unwrap();
    assert_eq!(normalized.as_str(), "/foo/baz/file.txt");

    let path = Pathname::new("/../../../test");
    assert!(path.normalize().is_none());

    let path = Pathname::new("././././test");
    let normalized = path.normalize().unwrap();
    assert_eq!(normalized.as_str(), "/test");
}