fn wake(&mut self) {
        while !self.0.is_empty() {
            let (waiter, waker) = {
                let mut blocked = BLOCKED_OWNERS.lock();
                let Some(waiter) = self.0.pop_front() else {
                    break;
                };
                let waker = waiter.state(&mut blocked).wait.take();
                (waiter, waker)
            };
            // Neither wake nor arbitrary Waker destruction holds either mutex.
            if let Some(waker) = waker {
                waker.wake();
            }
            drop(waiter);
        }
    }