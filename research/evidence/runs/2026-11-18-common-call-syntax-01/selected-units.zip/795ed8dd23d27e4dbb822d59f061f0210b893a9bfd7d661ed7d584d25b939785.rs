fn test_statfs_flags_values() {
    assert_eq!(StatFsFlags::RDONLY.bits(), 0x0001);
    assert_eq!(StatFsFlags::NOSUID.bits(), 0x0002);
    assert_eq!(StatFsFlags::NODEV.bits(), 0x0004);
    assert_eq!(StatFsFlags::NOEXEC.bits(), 0x0008);
    assert_eq!(StatFsFlags::NOATIME.bits(), 0x0400);
    assert_eq!(StatFsFlags::NODIRATIME.bits(), 0x0800);
    assert_eq!(StatFsFlags::RELATIME.bits(), 0x1000);
    assert_eq!(StatFsFlags::NOSYMFOLLOW.bits(), 0x2000);
}