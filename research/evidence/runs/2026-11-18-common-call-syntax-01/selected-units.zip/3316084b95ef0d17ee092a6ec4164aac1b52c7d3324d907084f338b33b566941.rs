fn emit_cached_dirents(
        &self,
        offset: u64,
        sink: &mut dyn DirEntrySink,
    ) -> VfsResult<usize> {
        self.as_dir()?;
        let parent = self.parent();
        let mut children: Vec<_> = self
            .0
            .children
            .lock()
            .iter()
            .filter_map(|(name, entry)| entry.upgrade().map(|entry| (name.clone(), Dentry(entry))))
            .filter(|(_, entry)| entry.is_really_positive())
            .collect();
        children.sort_by(|left, right| left.0.cmp(&right.0));

        let mut count = 0;
        let mut index = 0_u64;
        let mut emit = |name: &str, entry: &Dentry, index: &mut u64| -> VfsResult<bool> {
            let current = *index;
            *index += 1;
            if current < offset {
                return Ok(true);
            }
            let metadata = entry.vfs_inode().metadata();
            Ok(sink.accept(name, metadata.inode, metadata.mode.node_type(), current + 1))
        };

        if emit(DOT, self, &mut index)? {
            count += (index > offset) as usize;
        } else {
            return Ok(count);
        }

        let parent_entry = parent.as_ref().unwrap_or(self);
        if emit(DOTDOT, parent_entry, &mut index)? {
            count += (index > offset) as usize;
        } else {
            return Ok(count);
        }

        for (name, entry) in children {
            if !emit(&name, &entry, &mut index)? {
                break;
            }
            count += 1;
        }
        Ok(count)
    }