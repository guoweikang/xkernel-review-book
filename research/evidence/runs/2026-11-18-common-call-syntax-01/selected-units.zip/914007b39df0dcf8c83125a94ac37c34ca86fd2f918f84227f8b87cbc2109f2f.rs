fn try_lock_works() {
    let mutex = TestMutex::new(42);

    let a = mutex.try_lock();
    assert_eq!(a.as_ref().map(|r| **r), Some(42));

    let b = mutex.try_lock();
    assert!(b.is_none());

    drop(a);
    let c = mutex.try_lock();
    assert_eq!(c.as_ref().map(|r| **r), Some(42));
}