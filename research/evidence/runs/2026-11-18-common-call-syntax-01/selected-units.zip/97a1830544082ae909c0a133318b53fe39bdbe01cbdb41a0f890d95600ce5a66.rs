fn new_symlink_inode(fs: Arc<SimpleFs>, target: impl Into<String>) -> Arc<VfsInode> {
        let target = target.into();
        let node = Self::new(
            fs,
            NodeType::Symlink,
            NodePermission::from_bits_truncate(0o777),
        );
        node.metadata.lock().size = target.len() as u64;
        let init = node.inode_init();
        VfsInode::new_cached_symlink(Arc::new(node), NodeFlags::empty(), init, target)
    }