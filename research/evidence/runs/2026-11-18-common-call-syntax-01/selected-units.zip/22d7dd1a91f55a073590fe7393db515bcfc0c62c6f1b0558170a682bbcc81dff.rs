fn resize(&self, new_size: usize) -> KResult<()> {
        let pages = new_size
            .checked_add(PAGE_SIZE_4K - 1)
            .ok_or(KError::InvalidInput)?
            / PAGE_SIZE_4K;
        let pages = pages
            .max(1)
            .checked_next_power_of_two()
            .ok_or(KError::InvalidInput)?;
        let new_size = pages
            .checked_mul(PAGE_SIZE_4K)
            .ok_or(KError::InvalidInput)?;
        if new_size > PIPE_MAX_SIZE {
            return Err(KError::OperationNotPermitted);
        }

        let should_wake_writers = {
            let mut state = self.state.lock();
            let old_size = state.capacity;
            if new_size == old_size {
                return Ok(());
            }
            if new_size < state.buffer.len() {
                return Err(KError::ResourceBusy);
            }

            let mut new_buffer = VecDeque::with_capacity(new_size);
            new_buffer.extend(state.buffer.iter().copied());
            state.buffer = new_buffer;
            state.capacity = new_size;
            new_size > old_size
        };

        if should_wake_writers {
            self.wr_wait.wake();
        }
        Ok(())
    }