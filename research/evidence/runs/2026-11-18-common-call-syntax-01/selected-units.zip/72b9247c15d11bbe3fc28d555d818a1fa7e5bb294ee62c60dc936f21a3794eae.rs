fn pivot_root(
        &self,
        new_root: &Path,
        put_old: &Path,
        current_root: &Path,
    ) -> VfsResult<()> {
        let mounts = self.mounts.lock();
        let new_mnt = Self::registered_mount_at(&mounts, new_root)?.clone();
        // Linux resolves `pivot_root(2)` against the caller's root, which may
        // differ from the namespace root after `chroot(2)`.
        let old_mnt = current_root.clone().resolve_final_mount().mnt.clone();
        let root_mount = self.root.clone();

        // The caller's root must overmount the structural root: a bare root
        // mount has nothing to pivot away from.
        if Arc::ptr_eq(&old_mnt, &root_mount) {
            return Err(VfsError::InvalidInput);
        }
        // The surgery below rearranges the namespace root stack, so it requires
        // the caller's visible root to be the namespace's visible root. A
        // caller root moved by `chroot(2)` is not supported yet; reject it
        // instead of rearranging an unrelated mount.
        if !Arc::ptr_eq(&old_mnt, &self.root_path().resolve_final_mount().mnt) {
            return Err(VfsError::InvalidInput);
        }
        // Linux: `new_mnt == root_mnt || old_mnt == root_mnt` -> EBUSY ("loop,
        // on the same file system").
        if Arc::ptr_eq(&new_mnt, &old_mnt) || Arc::ptr_eq(put_old.mount(), &old_mnt) {
            return Err(VfsError::ResourceBusy);
        }
        if !put_old.is_dir() {
            return Err(VfsError::NotADirectory);
        }
        // Linux: `is_path_reachable(old_mnt, old.dentry, &new)`. `put_old`
        // must lie inside `new_root`'s subtree; equality is allowed.
        if !Self::is_reachable_from(put_old, new_root) {
            return Err(VfsError::InvalidInput);
        }

        // Serialize against concurrent mount-tree mutation on every inode the
        // surgery touches. Take the locks in the same total order as the rename
        // path (an ancestor before its descendant, then a stable pointer
        // tiebreak), so a concurrent multi-inode acquisition cannot ABBA against
        // this surgery. Inodes are never taken twice because
        // `lock_namespace_exclusive` is a non-reentrant write lock.
        let new_parent_path = new_mnt.location().ok_or(VfsError::InvalidInput)?;
        // Linux `root_parent`/`root_mp`: the old root's own parent mount and
        // mountpoint, where `new_mnt` takes over. The visible root may sit
        // anywhere in the stack over the structural root, not only at the
        // direct child position.
        let old_parent_path = old_mnt.location().ok_or(VfsError::InvalidInput)?;
        let mut targets: Vec<(Arc<VfsInode>, Vec<usize>)> = Vec::new();
        let mut push_target = |path: &Path| {
            let inode = path.inode();
            if !targets.iter().any(|(held, _)| Arc::ptr_eq(held, &inode)) {
                targets.push((inode, path.dentry.namespace_lock_key()));
            }
        };
        push_target(&old_parent_path);
        push_target(&new_parent_path);
        push_target(put_old);
        targets.sort_by(|left, right| left.1.cmp(&right.1));
        let _guards: Vec<_> = targets
            .iter()
            .map(|(inode, _)| inode.lock_namespace_exclusive())
            .collect();

        // Re-validate under the locks: the mount stacks read while resolving the
        // paths may have changed before these inode locks were acquired. The
        // surgery below assumes the old visible root is attached exactly at its
        // own parent mountpoint, so verify it and fail instead of asserting
        // inside the critical section.
        let (old_parent_mount, old_parent_dentry) =
            (old_parent_path.mnt.clone(), old_parent_path.dentry.clone());
        if !old_parent_mount
            .child_mount_at(&old_parent_dentry)
            .is_some_and(|mounted| Arc::ptr_eq(&mounted, &old_mnt))
        {
            return Err(VfsError::InvalidInput);
        }

        // 1. Detach `new_mnt` from its old parent, restoring whatever mount it
        //    covered at its original location.
        let (new_parent_mount, new_parent_dentry) =
            (new_parent_path.mnt.clone(), new_parent_path.dentry.clone());
        mount_edge_detach(&new_parent_mount, &new_parent_dentry, &new_mnt);

        // 2. Stack `new_mnt` over the old visible root at the old root's own
        //    mountpoint (`attach_mnt(new_mnt, root_parent, root_mp)`),
        //    temporarily holding the old root in its `covers` slot. The
        //    re-validation above guarantees this returns the old visible root.
        *new_mnt.covers.lock() = old_parent_mount.install_child_mount(&old_parent_dentry, &new_mnt);
        *new_mnt.mnt_location.lock() = Some(old_parent_path);

        // 3. Take the old visible root out of the stack. The chain it covered
        //    at the root (usually empty) stays covered under `new_mnt`,
        //    matching Linux's stack-preserving move.
        let chain_below = old_mnt.covers.lock().take();
        old_mnt.detach();
        if let Some(chain) = chain_below {
            *new_mnt.covers.lock() = Some(chain);
        }

        // 4. Attach the old root at `put_old`, preserving any mount stacked
        //    there (it becomes `old_mnt`'s covered layer).
        if let Some(covered) = put_old.mnt.install_child_mount(&put_old.dentry, &old_mnt) {
            *old_mnt.covers.lock() = Some(covered);
        }
        *old_mnt.mnt_location.lock() = Some(put_old.clone());

        drop(mounts);
        Ok(())
    }