fn open(&self, _disk: &block::Gendisk, mode: BlockOpenMode) -> VfsResult<()> {
        self.modes.lock().push(mode);
        if self.fail_open.load(core::sync::atomic::Ordering::Relaxed) {
            Err(VfsError::Io)
        } else {
            Ok(())
        }
    }