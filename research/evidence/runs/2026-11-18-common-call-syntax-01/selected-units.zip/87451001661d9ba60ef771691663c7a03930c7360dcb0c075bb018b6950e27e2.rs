fn child_names<'a>(&'a self) -> VfsResult<KBox<dyn Iterator<Item = Cow<'a, str>> + 'a>> {
        let names: Vec<Cow<'a, str>> = self
            .entries
            .lock()
            .keys()
            .map(|name| Cow::Owned(name.clone()))
            .collect();
        Ok(KBox::new(names.into_iter())?)
    }