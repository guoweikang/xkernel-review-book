fn perform_write(
        &self,
        offset: u64,
        iter: &mut IovIterSource<'_>,
        len: usize,
    ) -> VfsResult<usize> {
        if !ktask::is_sleepable_context() {
            return Err(VfsError::InvalidInput);
        }
        let mut written = 0usize;
        let mut visible_len = self.visible_len()?;
        while written < len {
            let pos = offset
                .checked_add(written as u64)
                .ok_or(VfsError::InvalidInput)?;
            let index = pos / memaddr::PAGE_SIZE_4K as u64;
            let page_off = (pos % memaddr::PAGE_SIZE_4K as u64) as usize;
            let step = (len - written).min(memaddr::PAGE_SIZE_4K - page_off);
            let prepared_end = pos.checked_add(step as u64).ok_or(VfsError::InvalidInput)?;
            if let Err(error) = self
                .ops
                .write_begin(self, WriteBeginRequest::new(pos, step))
            {
                return write_prefix_or_error(written, error);
            }
            let grew_cache = prepared_end > visible_len;
            if grew_cache {
                self.i_pages
                    .resize_cached_folios(visible_len, prepared_end)?;
            }
            let mut copied = 0;
            let copy_result = self.with_folio_or_create(index, |folio| {
                let data = folio.data();
                copied = iter.copy_from_iter(&mut data[page_off..page_off + step])?;
                if copied != 0 {
                    self.dirty_folio(folio)?;
                }
                Ok(())
            });
            if let Err(error) = copy_result {
                iter.revert(copied)?;
                if let Err(cancel_error) =
                    self.ops.write_end(self, WriteEndRequest::new(pos, step, 0))
                {
                    log::warn!(
                        "failed to cancel buffered write at {pos} (len {step}): {cancel_error:?}"
                    );
                }
                if grew_cache {
                    self.i_pages
                        .resize_cached_folios(prepared_end, visible_len)?;
                }
                return write_prefix_or_error(written, error);
            }
            let accepted = match self
                .ops
                .write_end(self, WriteEndRequest::new(pos, step, copied))
            {
                Ok(accepted) => accepted,
                Err(error) => {
                    iter.revert(copied)?;
                    if grew_cache {
                        self.i_pages
                            .resize_cached_folios(prepared_end, visible_len)?;
                    }
                    return write_prefix_or_error(written, error);
                }
            };
            if accepted > copied {
                return Err(VfsError::InvalidInput);
            }
            if accepted < copied {
                iter.revert(copied - accepted)?;
            }
            // `write_end` publishes EOF as `pos + accepted`; roll the cache back
            // to that same end so unaccepted bytes are not left cached and dirty
            // beyond the visible size.
            let accepted_end = pos
                .checked_add(accepted as u64)
                .ok_or(VfsError::InvalidInput)?;
            if grew_cache && accepted_end < prepared_end {
                self.i_pages
                    .resize_cached_folios(prepared_end, accepted_end)?;
            }
            visible_len = visible_len.max(accepted_end);
            if accepted == 0 {
                break;
            }
            written += accepted;
            if accepted < step {
                break;
            }
        }

        Ok(written)
    }