fn command_file_read_rejects_missing_content() {
    let missing = CommandFile::new(|_| Ok(None::<Vec<u8>>));
    assert_eq!(missing.read_all(), Err(VfsError::InvalidData));
    let failed = CommandFile::new(|_| Err::<Option<Vec<u8>>, _>(VfsError::PermissionDenied));
    assert_eq!(failed.read_all(), Err(VfsError::PermissionDenied));
    let empty = CommandFile::new(|_| Ok(Some(Vec::<u8>::new())));
    assert_eq!(empty.read_all(), Ok(Cow::Owned(Vec::new())));
}