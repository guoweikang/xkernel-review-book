fn pipe_ioctl(file: &VfsFile, cmd: u32, arg: usize) -> VfsResult<usize> {
    let pipe = PipeObject::from_file(file)?;
    match cmd {
        FIONREAD => {
            // `write_vm` validates typed user-pointer alignment before writing.
            (arg as *mut i32).write_vm(pipe.readable_len() as i32)?;
            Ok(0)
        }
        _ => Err(KError::NotATty),
    }
}