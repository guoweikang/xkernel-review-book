fn test_direntry_parent_path_and_ancestor_helpers() {
    let fs = Arc::new(MockFilesystem);
    let root = make_dir_entry(fs.clone(), 10, "");
    let child = make_dir_entry_with_parent(fs.clone(), 11, Some(root.clone()), "child");
    let (leaf, _) = make_file_entry(fs, 12, Some(child.clone()), "leaf");

    assert!(root.is_root_of_mount());
    assert_eq!(child.parent().unwrap().as_ptr(), root.as_ptr());
    assert_eq!(leaf.absolute_path().unwrap().as_str(), "/child/leaf");
    assert!(root.is_ancestor_of(&leaf).unwrap());
    assert!(child.is_ancestor_of(&leaf).unwrap());
    assert!(!leaf.is_ancestor_of(&child).unwrap());
}