fn kstat(inode: u64, node_type: NodeType, size: u64) -> Metadata {
    Metadata {
        device: 0,
        inode,
        nlink: 1,
        mode: crate::Umode::new(node_type, NodePermission::default()),
        uid: 0,
        gid: 0,
        size,
        block_size: 4096,
        blocks: 1,
        rdev: Default::default(),
        atime: SystemTime::UNIX_EPOCH,
        mtime: SystemTime::UNIX_EPOCH,
        ctime: SystemTime::UNIX_EPOCH,
    }
}