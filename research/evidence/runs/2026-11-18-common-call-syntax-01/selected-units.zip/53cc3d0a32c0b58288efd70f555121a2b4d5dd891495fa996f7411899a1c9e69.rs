fn resident_timestamps_follow_values_returned_by_filesystem() {
    let super_block = second_resolution_super_block();
    let node = Arc::new(TestChrdevInode::new(DeviceId::new(1, 3)));
    let inode = super_block.get_or_init_inode(43, || {
        VfsInode::new_with_inode_attribute_operations(
            node.clone(),
            NodeFlags::NON_CACHEABLE,
            empty_address_space_operations(),
            VfsInodeInit::new(
                43,
                0,
                Umode::new(
                    NodeType::CharacterDevice,
                    NodePermission::from_bits_truncate(0o666),
                ),
            ),
        )
    });
    let dentry = Dentry::new_file_from_inode(inode.clone(), None, String::from("applied"));
    let applied_atime = SystemTime::from_unix_seconds(20);
    *node.next_applied_update.lock() = Some(MetadataUpdate {
        atime: Some(applied_atime),
        ..Default::default()
    });

    dentry
        .update_metadata(MetadataUpdate {
            atime: Some(SystemTime::from_unix_seconds(21)),
            mtime: Some(SystemTime::from_unix_seconds(22)),
            ..Default::default()
        })
        .unwrap();

    assert_eq!(inode.metadata().atime, applied_atime);
    assert_eq!(inode.metadata().mtime, SystemTime::UNIX_EPOCH);

    let applied_cmtime = SystemTime::from_unix_seconds(24);
    *node.next_applied_update.lock() = Some(MetadataUpdate {
        mtime: Some(applied_cmtime),
        ctime: Some(applied_cmtime),
        ..Default::default()
    });
    inode
        .update_time(
            &dentry,
            SystemTime::from_unix_seconds(25),
            InodeUpdateTime::ChangeAndModification,
        )
        .unwrap();

    assert_eq!(inode.metadata().mtime, applied_cmtime);
    assert_eq!(inode.metadata().ctime, applied_cmtime);
}