fn file_pair_step(
    input: &Arc<VfsFile>,
    output: &Arc<VfsFile>,
    input_pos: &mut u64,
    output_pos: &mut u64,
    buf: &mut [u8],
    chunk: usize,
) -> KResult<Step> {
    let mut read_pos = *input_pos;
    let read = input.read_from(&mut buf[..chunk], &mut read_pos)?;
    if read > chunk {
        return Err(KError::Io);
    }
    if read == 0 {
        return Ok(Step::Eof);
    }
    let mut write_pos = *output_pos;
    let written = output.write_from(&buf[..read], &mut write_pos)?;
    if written > read {
        return Err(KError::Io);
    }
    // Only the accepted prefix commits: the tail stays at the source
    // for the next step to re-read.
    *input_pos += written as u64;
    *output_pos = write_pos;
    Ok(Step::Data {
        confirmed: written,
        stop: written < read,
    })
}