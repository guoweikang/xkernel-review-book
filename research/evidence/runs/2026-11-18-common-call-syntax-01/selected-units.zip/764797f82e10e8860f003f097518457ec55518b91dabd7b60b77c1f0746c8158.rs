fn expansion_preserves_identity_and_close_hands_off_readers() {
    use alloc::task::Wake;
    use core::sync::atomic::{AtomicUsize, Ordering};

    struct WakeCount {
        context: Arc<FileLockContext>,
        count: AtomicUsize,
    }
    impl Wake for WakeCount {
        fn wake(self: Arc<Self>) {
            assert!(self.context.state.try_lock().is_some());
            assert!(node::wait_tree_unlocked());
            self.count.fetch_add(1, Ordering::Relaxed);
        }
    }
    let context = Arc::new(FileLockContext::new());
    let count = Arc::new(WakeCount {
        context: context.clone(),
        count: AtomicUsize::new(0),
    });
    let waker = Waker::from(count.clone());
    let holder = FileLockOwner::Posix(400);
    context
        .apply(
            &FileLock::new(holder, 0, FileLockType::Write, 10, 10).unwrap(),
            false,
        )
        .unwrap();
    let original = context
        .state
        .lock()
        .posix
        .find(|_| true)
        .unwrap()
        .downgrade();
    let mut readers = Vec::new();
    let mut wake = WakeQueue::new();
    for id in 401..465 {
        let request =
            FileLock::new(FileLockOwner::Posix(id), 0, FileLockType::Read, 10, 10).unwrap();
        let mut waiter = None;
        assert_eq!(
            context.try_apply(&request, true, &mut waiter, &mut wake),
            Ok(true)
        );
        let waiter = waiter.unwrap();
        assert!(waiter.poll_wait(&waker).is_pending());
        readers.push(waiter);
    }
    context
        .apply(
            &FileLock::new(holder, 0, FileLockType::Write, 0, 40).unwrap(),
            false,
        )
        .unwrap();
    {
        let state = context.state.lock();
        let installed = state.posix.find(|_| true).unwrap();
        assert!(original.upgrade().unwrap().ptr_eq(&installed));
        assert_eq!(state.posix.iter().next().unwrap().bounds(), (0, 39));
        assert_eq!(installed.children_count(), 64);
        for reader in &readers {
            assert!(reader.is_blocked_by_node(&installed));
        }
    }
    let mut waiter = None;
    assert_eq!(
        context.try_apply(&FileLock::unlock(holder), false, &mut waiter, &mut wake),
        Ok(false)
    );
    assert_eq!(wake.len(), 64);
    assert!(context.state.lock().posix.is_empty());
    assert!(original.upgrade().is_none());
    assert!(readers[0].poll_wait(&waker).is_pending());
    // A signal may cancel a request whose notification is already in
    // flight. Its existing node must remain alive until the handoff ends.
    let cancelled = readers.pop().unwrap();
    cancelled.cancel_waiter(&mut WakeQueue::new());
    drop(cancelled);
    wake.wake();
    assert_eq!(count.count.load(Ordering::Relaxed), 64);
    assert!(
        readers
            .iter()
            .all(|reader| reader.poll_wait(&waker).is_ready())
    );
}