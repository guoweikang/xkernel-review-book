fn open(self: Arc<Self>, inode: &VfsInode, file: &mut VfsFileBuilder) -> VfsResult<()> {
        let file_inode = file.inode()?;
        debug_assert!(core::ptr::eq(inode, file_inode.as_ref()));
        let ops =
            character_operations(file_inode).ok_or_else(|| VfsError::from(LinuxError::ENXIO))?;
        open_character_device(inode, file, ops)
    }