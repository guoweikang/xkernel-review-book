fn move_blocked(&self, target: &Arc<Self>, blocked: &mut MutexGuard<'_, BlockedOwners>) {
        while let Some(waiter) = self.state(blocked).requests.pop_front() {
            self.note_pop();
            waiter.state(blocked).blocker = Some(Arc::downgrade(target));
            target.state(blocked).requests.push_back(waiter);
            target.note_push();
        }
    }