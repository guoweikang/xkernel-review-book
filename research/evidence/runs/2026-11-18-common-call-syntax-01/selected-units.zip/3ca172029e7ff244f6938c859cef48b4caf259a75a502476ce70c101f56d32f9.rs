fn new_inode_with_owner(
        fs: Arc<SimpleFs>,
        ops: Arc<O>,
        permission: NodePermission,
        uid: u32,
        gid: u32,
    ) -> Arc<VfsInode> {
        let dir = SimpleDir::new(
            SimpleFsNode::new_with_owner(fs, NodeType::Directory, permission, uid, gid),
            ops.clone(),
        );
        let private_data: Arc<dyn Any + Send + Sync> = dir.clone();
        let inode_operations: Arc<dyn InodeOperations> =
            Arc::new(SimpleDirInodeOperations::new(dir.clone()));
        let file_operations: Arc<dyn FileOperations> =
            Arc::new(SimpleDirFileOperations::new(dir.clone()));
        let init = dir.node.inode_init();
        let flags = if ops.supports_dentry_cache() {
            NodeFlags::empty()
        } else {
            NodeFlags::NON_CACHEABLE
        };
        VfsInode::new_dir_with_operations(
            private_data,
            inode_operations,
            file_operations,
            flags,
            init,
        )
    }