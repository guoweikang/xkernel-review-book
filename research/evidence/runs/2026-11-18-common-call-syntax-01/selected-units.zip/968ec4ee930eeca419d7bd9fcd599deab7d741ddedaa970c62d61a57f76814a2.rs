fn simple_rename_timestamp(
    old_dir: &VfsInode,
    old_dentry: &Dentry,
    new_dir: &VfsInode,
    new_dentry: &Dentry,
) {
    let timestamp = old_dir.set_changed_at_to_now();
    old_dir.set_modified_at(timestamp);
    if !ptr::eq(old_dir, new_dir) {
        let timestamp = new_dir.set_changed_at_to_now();
        new_dir.set_modified_at(timestamp);
    }
    old_dentry.set_changed_at_to_now();
    if d_really_is_positive(new_dentry) {
        new_dentry.set_changed_at_to_now();
    }
}