fn new(first: DeviceId, count: u32, ops: Arc<dyn DeviceFileOps>) -> VfsResult<Self> {
        let last_minor = count
            .checked_sub(1)
            .and_then(|offset| first.minor().checked_add(offset))
            .ok_or(VfsError::InvalidInput)?;
        Ok(Self {
            first,
            last_minor,
            ops,
            is_registered: AtomicBool::new(true),
            identity: None,
        })
    }