fn clone_mnt(source: &Path) -> Self {
        Self {
            mnt: VfsMount::clone_from_path(source),
            mnt_location: Mutex::default(),
            mnt_mounts: Mutex::default(),
            mnt_id: MOUNT_ID_COUNTER.fetch_add(1, Ordering::Relaxed),
            covers: Mutex::default(),
            mnt_devname: source.mount().mnt_devname.clone(),
        }
    }