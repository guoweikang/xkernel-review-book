fn lookup_open(
        &mut self,
        file: &mut VfsFileBuilder,
        flags: &OpenParams,
        umask: NodePermission,
        cred: &Cred,
    ) -> VfsResult<Path> {
        file.clear_created();

        let name = self
            .last
            .as_ref()
            .map(Qstr::as_str)
            .ok_or(VfsError::InvalidInput)?;
        let dir = self.path.dentry().as_dir()?;
        if !flags.is_exclusive_create() {
            match dir.lookup(name) {
                Ok(entry) => return Ok(self.path.with_dentry(entry)),
                Err(err) if err.canonicalize() == VfsError::NotFound => {}
                Err(err) => return Err(err),
            }
        }

        if !flags.will_create() {
            return Err(VfsError::NotFound);
        }

        match dir.lookup_or_create_with(name, flags.is_exclusive_create(), |candidate| {
            self.path.vfs_create(
                candidate,
                flags.mode(),
                umask,
                flags.is_exclusive_create(),
                cred,
            )
        })? {
            LookupCreateResult::Existing(entry) => Ok(self.path.with_dentry(entry)),
            LookupCreateResult::Created(entry) => {
                file.mark_created();
                // Captured here, under the parent's namespace lock: the created
                // dentry's location is mutable afterwards, so the inotify
                // create event must use this snapshot of where and under what
                // name the entry was born.
                file.set_created_under(self.path.inode(), name);
                Ok(self.path.with_dentry(entry))
            }
        }
    }