fn block_unaligned_extents_preserve_read_modify_write_semantics() {
    for (offset, len) in [(1, 1), (0, 513), (511, 1024), (513, 1023)] {
        let fixture = BlockIoFixture::new(512);
        let input = vec![0x72; len];
        let mut output = vec![0; len];
        assert_eq!(
            write_block_device(&fixture.device, &input, offset as u64).unwrap(),
            len
        );
        assert_eq!(
            read_block_device(&fixture.device, &mut output, offset as u64).unwrap(),
            len
        );
        assert_eq!(output, input);
        let storage = fixture.backend.storage.lock();
        assert!(storage[..offset].iter().all(|&b| b == 0x35));
        assert!(storage[offset + len..].iter().all(|&b| b == 0x35));
    }
}