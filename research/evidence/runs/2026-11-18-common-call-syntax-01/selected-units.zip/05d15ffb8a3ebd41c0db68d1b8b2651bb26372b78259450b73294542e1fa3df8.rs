fn block_file_retains_open_identity_across_device_number_reuse() {
    use core::sync::atomic::Ordering::Relaxed;
    let old = OpenBlockDevice::new(8);
    let disk =
        block::Gendisk::alloc(String::from("open-old"), 242, 0, 1, Box::new(old.clone())).unwrap();
    let device = block::add_disk(disk).unwrap();
    let rdev = device.device_number();
    let flags =
        crate::OpenFlags::READ_WRITE | crate::OpenFlags::EXCLUSIVE | crate::OpenFlags::NONBLOCK;
    let (file, _) = open_block_device_file_with(rdev, flags).unwrap();
    let mode = BlockOpenMode::READ
        | BlockOpenMode::WRITE
        | BlockOpenMode::EXCLUSIVE
        | BlockOpenMode::NONBLOCK;
    assert_eq!(old.modes.lock().as_slice(), &[mode]);
    assert!(matches!(
        open_block_device_file_with(rdev, flags),
        Err(VfsError::ResourceBusy)
    ));
    block::del_gendisk(rdev).unwrap();
    assert_eq!(file.size(), 4096);
    file.fsync(false).unwrap();

    let replacement = OpenBlockDevice::new(16);
    let disk = block::Gendisk::alloc(
        String::from("open-new"),
        242,
        0,
        1,
        Box::new(replacement.clone()),
    )
    .unwrap();
    let new_device = block::add_disk(disk).unwrap();
    assert_eq!(file.llseek(0, SEEK_END).unwrap(), 4096);
    assert_eq!(new_device.size(), 8192);
    let mut offset = 0;
    file.write_from(&[0xa5; 512], &mut offset).unwrap();
    let mut output = [0; 512];
    let mut read_offset = 0;
    file.read_from(&mut output, &mut read_offset).unwrap();
    assert_eq!(output, [0xa5; 512]);
    assert!(
        replacement
            .memory
            .storage
            .lock()
            .iter()
            .all(|&byte| byte == 0x35)
    );
    let cred = kcred::initial_cred();
    assert_eq!(file.ioctl(&cred, u32::MAX, 0), Ok(17));
    file.set_nonblocking(false);
    assert_eq!(file.ioctl(&cred, u32::MAX, 0), Ok(17));
    assert_eq!(
        old.ioctl_modes.lock().as_slice(),
        &[mode, mode & !BlockOpenMode::NONBLOCK]
    );
    assert!(replacement.ioctl_modes.lock().is_empty());
    let duplicate = file.clone();
    drop(file);
    assert_eq!(old.releases.load(Relaxed), 0);
    drop(duplicate);
    assert_eq!(old.releases.load(Relaxed), 1);
    assert_eq!(replacement.releases.load(Relaxed), 0);
    device.open(BlockOpenMode::EXCLUSIVE, None).unwrap().release();
    assert_eq!(old.releases.load(Relaxed), 2);
    block::del_gendisk(rdev).unwrap();
}