fn open_test_character_at(
    device: DeviceId,
    ops: Arc<dyn DeviceFileOps>,
) -> VfsResult<Arc<VfsFile>> {
    // An inode-local registration exercises cached dispatch without
    // publishing a number or disturbing another test's registration.
    let init = VfsInodeInit::new(
        99,
        0,
        Umode::new(NodeType::CharacterDevice, NodePermission::default()),
    )
    .with_owner_links_and_rdev(0, 0, 1, device);
    let inode = VfsInode::new_special(
        Arc::new(TestChrdevInode { rdev: device }),
        NodeFlags::empty(),
        init,
    );
    let entry = Arc::new(ChrdevEntry::new(device, 1, ops).unwrap());
    inode.set_character_device(Arc::downgrade(&entry));
    let mount = crate::Mount::new_root(&crate::nullfs::new_superblock());
    let dentry = crate::Dentry::new_file_from_inode(inode, None, String::from("device"));
    let path = crate::Path::new(mount, dentry);
    VfsFileBuilder::allocate(crate::OpenFlags::READ_WRITE, kcred::initial_cred())?.vfs_open(path)
}