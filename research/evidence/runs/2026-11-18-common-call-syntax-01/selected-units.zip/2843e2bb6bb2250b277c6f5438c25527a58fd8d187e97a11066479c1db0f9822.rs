fn try_show(&self, _item: &Self::Item, buf: &mut String) -> crate::VfsResult<()> {
            if !self.0.replace(true) {
                buf.push_str("discard");
                return Err(crate::VfsError::NoSuchProcess);
            }
            buf.push_str("ready\n");
            Ok(())
        }