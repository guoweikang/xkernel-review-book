fn test_path_normalization() {
    let path = PathBuf::from("/path/to/file");
    assert_eq!(path.as_str(), "/path/to/file");

    let root = PathBuf::from("/");
    assert_eq!(root.as_str(), "/");

    let empty = PathBuf::new();
    assert_eq!(empty.as_str(), "");
}