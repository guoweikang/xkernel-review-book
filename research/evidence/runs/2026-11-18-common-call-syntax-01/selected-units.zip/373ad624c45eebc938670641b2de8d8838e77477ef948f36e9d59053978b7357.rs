fn write_iter(&self, iocb: &mut Kiocb<'_>, iter: &mut IovIterSource<'_>) -> VfsResult<usize> {
        crate::file::scalar_write_iter(iocb, iter, |file, data, offset| {
            self.write(file, data, offset)
        })
    }