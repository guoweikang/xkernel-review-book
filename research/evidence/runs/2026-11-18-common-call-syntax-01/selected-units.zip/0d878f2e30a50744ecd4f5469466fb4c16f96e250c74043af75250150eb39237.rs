fn publish(mut self, inode: &Arc<VfsInode>) {
        let mut inodes = self.cache.inodes.lock();
        let entry = inodes
            .get_mut(&self.key)
            .expect("an inode-cache reservation must retain its slot");
        assert!(
            matches!(entry.state, CachedInodeState::New),
            "an inode-cache reservation must remain I_NEW until publication"
        );
        entry.state = CachedInodeState::Live(Arc::downgrade(inode));
        let waiters = entry.waiters.clone();
        self.is_published = true;
        drop(inodes);
        waiters.notify_all(false);
    }