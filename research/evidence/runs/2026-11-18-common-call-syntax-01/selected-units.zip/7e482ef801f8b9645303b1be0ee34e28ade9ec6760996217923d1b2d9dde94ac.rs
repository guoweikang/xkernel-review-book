fn lookup_fast_for_open(&mut self, flags: &OpenParams) -> VfsResult<Option<Path>> {
        if flags.will_create() {
            if self.has_trailing_slashes() {
                return Err(VfsError::IsADirectory);
            }
            if flags.is_exclusive_create() {
                return Ok(None);
            }
        }

        if self.has_trailing_slashes() {
            self.flags |= LookupFlags::FOLLOW_FINAL | LookupFlags::DIRECTORY;
        }

        let name = self
            .last
            .as_ref()
            .map(Qstr::as_str)
            .ok_or(VfsError::InvalidInput)?;
        let Some(result) = self.lookup_fast(name) else {
            return Ok(None);
        };
        match result {
            Ok(path) => Ok(Some(path)),
            Err(err) if err.canonicalize() == VfsError::NotFound && flags.will_create() => Ok(None),
            Err(err) => Err(err),
        }
    }