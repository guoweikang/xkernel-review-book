fn link_path_walk(&mut self, base: &Path, cred: &Cred) -> VfsResult<Path> {
        if self.pathname.is_empty() {
            if self.flags.contains(LookupFlags::EMPTY_PATH) {
                return Ok(base.clone());
            }
            return Err(VfsError::NotFound);
        }

        self.path_init(base);
        let mut pathname = self.pathname;
        let mut at_start = true;

        while let Some((last_type, name)) = Self::next_path_component(&mut pathname, &mut at_start)
        {
            let has_more = Self::has_more_path_components(pathname, at_start);
            if last_type != LastType::Root {
                // The component being resolved must sit in a directory, and
                // Linux checks that before the search permission: `d_can_lookup`
                // reports ENOTDIR first, `may_lookup` only then EACCES
                // (fs/namei.c `link_path_walk`). Without this ordering a path
                // like `file/child` or `file/.` failed the MAY_EXEC check on the
                // regular file itself and surfaced EACCES instead.
                if !self.path.dentry().can_lookup() {
                    return Err(VfsError::NotADirectory);
                }
                self.path.permission(crate::Permission::MAY_EXEC, cred)?;
            }
            if !has_more {
                self.walk_path_component(last_type, name, WalkComponent::Final, cred)?;
                return Ok(self.path.clone());
            }
            self.walk_path_component(last_type, name, WalkComponent::More, cred)?;
        }

        Ok(self.path.clone())
    }