fn mock_superblock(root: Dentry, mount_flags: StatFsFlags) -> Arc<SuperBlock> {
    let mut superblock_flags = SuperBlockFlags::empty();
    if mount_flags.contains(StatFsFlags::RDONLY) {
        superblock_flags.insert(SuperBlockFlags::RDONLY);
    }
    SuperBlock::new_with_flags_and_private(
        &MOCK_FILE_SYSTEM_TYPE,
        &MOCK_SUPER_OPERATIONS,
        kalloc_types::KBox::new(MockSuperPrivate { mount_flags }).unwrap(),
        superblock_flags,
        1,
        crate::MAX_LFS_FILESIZE,
        |_| root,
    )
}