fn o_path_directory_rejects_non_directory() {
    let tree = test_tree();
    let flags = linux_raw_sys::general::O_PATH | linux_raw_sys::general::O_DIRECTORY;

    let regular = Filename::new("/target").open_with_flags_at(
        &tree.root,
        &tree.base,
        flags,
        NodePermission::empty(),
        NodePermission::empty(),
        kcred::initial_cred(),
    );
    assert!(matches!(regular, Err(VfsError::NotADirectory)));

    let directory = Filename::new("/dir")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            flags,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(directory.node_type(), NodeType::Directory);

    let autodir = Filename::new("/autodir").open_with_flags_at(
        &tree.root,
        &tree.base,
        flags,
        NodePermission::empty(),
        NodePermission::empty(),
        kcred::initial_cred(),
    );
    assert!(matches!(autodir, Err(VfsError::NotADirectory)));
}