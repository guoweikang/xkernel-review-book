fn check_xattr_permission(
    inode: &VfsInode,
    name: &XattrName,
    access: XattrAccess,
    cred: &Cred,
) -> VfsResult<()> {
    if matches!(access, XattrAccess::Write)
        && inode
            .flags()
            .intersects(crate::NodeFlags::IMMUTABLE | crate::NodeFlags::APPEND_ONLY)
    {
        return Err(VfsError::OperationNotPermitted);
    }

    let name = name.as_bytes();

    // Linux delegates security.* authorization to LSM hooks. Until KVFS has
    // that hook boundary, require `CAP_SYS_ADMIN` for mutations instead of
    // letting a caller without that authority forge security data.
    if name.starts_with(SECURITY_PREFIX) {
        return if matches!(access, XattrAccess::Write) && !cred.has_sys_admin() {
            Err(VfsError::OperationNotPermitted)
        } else {
            Ok(())
        };
    }

    // Linux leaves system.* authorization to the filesystem and ACL layers
    // instead of applying generic inode DAC here.
    if name.starts_with(SYSTEM_PREFIX) {
        return Ok(());
    }

    if name.starts_with(TRUSTED_PREFIX) {
        return if cred.has_sys_admin() {
            Ok(())
        } else {
            Err(access.namespace_error())
        };
    }

    if name.starts_with(USER_PREFIX) {
        match inode.node_type() {
            NodeType::RegularFile | NodeType::Socket => {}
            NodeType::Directory => {
                let metadata = inode.metadata();
                if matches!(access, XattrAccess::Write)
                    && metadata.mode.permission().contains(NodePermission::STICKY)
                    && cred.fsuid() != metadata.uid
                    && !cred.has_cap(kcred::CAP_FOWNER)
                {
                    return Err(VfsError::OperationNotPermitted);
                }
            }
            _ => return Err(access.namespace_error()),
        }
    }

    inode.permission(access.permission(), cred)
}