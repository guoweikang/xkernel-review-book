fn open_path(
        root: &Path,
        base: &Path,
        filename: &Filename,
        mut file: VfsFileBuilder,
        flags: &OpenParams,
        umask: NodePermission,
        cred: &Cred,
    ) -> VfsResult<Arc<VfsFile>> {
        let mut name = filename.clone();
        let mut walk_base = base.clone();
        let mut total_link_count = 0;
        // Resolution constraints accumulate in the lookup flags, as Linux keeps
        // them in `nd->flags` while it expands symlinks (`path_openat`). A
        // trailing slash demands a directory for the final resolved path, and
        // that demand cannot live in the path string: `link/` where `link`
        // points at a regular file must fail with ENOTDIR, yet the expanded
        // target ("target") carries no slash. Each hop's `Nameidata` inherits
        // the accumulated flags and contributes its own trailing-slash demand
        // through `lookup_fast_for_open`.
        let mut lookup_flags = flags.lookup_flags();
        loop {
            let mut nd = Nameidata::new(root, &walk_base, &name, LookupIntent::Open, lookup_flags);
            nd.total_link_count = total_link_count;
            nd.link_path_walk(&walk_base, cred)?;
            // `open_last_lookups` is where `lookup_fast_for_open` turns this
            // hop's trailing slash into `DIRECTORY`, so the demand is only
            // visible in `nd.flags` after it runs.
            let next = nd.open_last_lookups(&mut file, flags, umask, cred)?;
            lookup_flags |= nd.flags;
            let Some(next) = next else {
                let path = nd.path.clone();
                let may_open =
                    Self::may_open_resolved(&path, flags, lookup_flags, file.was_created(), cred)?;
                let opened = file.vfs_open(path)?;
                Self::handle_truncate(&opened, &may_open)?;
                return Ok(opened);
            };
            walk_base = if next.is_absolute() {
                root.clone()
            } else {
                nd.path.clone()
            };
            total_link_count = nd.total_link_count;
            name = Filename::new(next);
        }
    }