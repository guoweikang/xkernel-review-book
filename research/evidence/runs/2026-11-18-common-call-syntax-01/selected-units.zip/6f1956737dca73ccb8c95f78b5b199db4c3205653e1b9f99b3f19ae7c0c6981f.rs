fn read_inode(ops: &'static dyn AddressSpaceOperations, size: usize) -> Arc<VfsInode> {
    VfsInode::new_file_with_address_space(
        Arc::new(TruncateOps),
        ops,
        VfsInodeInit::new(
            1,
            size as u64,
            Umode::new(NodeType::RegularFile, NodePermission::default()),
        ),
    )
}