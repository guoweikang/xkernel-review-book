fn test_readonly_mount_blocks_create() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let mount = Mount::new_root_with_flags(&fs, MountFlags::RDONLY);
    let root = mount.root_path();

    let result = root.create("test", NodePermission::default(), &kcred::initial_cred());
    assert!(result.is_err());
    assert_eq!(result.unwrap_err(), VfsError::ReadOnlyFilesystem);
}