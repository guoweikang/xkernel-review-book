fn read_dir_at(
        &self,
        dir: &Dentry,
        offset: u64,
        sink: &mut dyn DirEntrySink,
    ) -> VfsResult<usize> {
        let children = [DOT, DOTDOT]
            .into_iter()
            .map(Cow::Borrowed)
            .chain(self.ops.child_names()?);

        let mut count = 0;
        for (i, name) in children.enumerate().skip(offset as usize) {
            let metadata = match name.as_ref() {
                DOT => dir.metadata(),
                DOTDOT => dir
                    .parent()
                    .map_or_else(|| dir.metadata(), |parent| parent.metadata()),
                other => {
                    let entry = dir.lookup(other)?;
                    entry.metadata()
                }
            };
            if !sink.accept(
                &name,
                metadata.inode,
                metadata.mode.node_type(),
                i as u64 + 1,
            ) {
                break;
            }
            count += 1;
        }

        Ok(count)
    }