fn validate_locked(&self, source: &Dentry, target: &Dentry) -> VfsResult<()> {
        if self.flags.contains(RenameFlags::EXCHANGE) {
            return Ok(());
        }
        if !target.is_really_positive() {
            return Ok(());
        }

        match (source.is_dir(), target.is_dir()) {
            (true, false) => return Err(VfsError::NotADirectory),
            (false, true) => return Err(VfsError::IsADirectory),
            _ => {}
        }
        Ok(())
    }