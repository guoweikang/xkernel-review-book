fn make_removable_dir_entry(
    inode: u64,
    parent: Option<Dentry>,
    name: &str,
) -> (Dentry, Arc<MockDirOps>) {
    let operations = Arc::new(MockDirOps::new_removable(inode));
    let inode = VfsInode::new_openable_dir(
        operations.clone(),
        inode_init(inode, NodeType::Directory, 0),
    );
    (
        Dentry::new_dir_from_inode(inode, parent, String::from(name)),
        operations,
    )
}