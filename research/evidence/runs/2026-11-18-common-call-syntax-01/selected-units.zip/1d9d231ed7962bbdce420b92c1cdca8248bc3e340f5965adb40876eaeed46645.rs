fn test_superblock_inode_cache_reuses_live_identity() {
    let fs = Arc::new(MockFilesystem);
    let super_block = SuperBlock::new(
        &MOCK_FILE_SYSTEM_TYPE,
        &MOCK_SUPER_OPERATIONS,
        |super_block| {
            let root_inode = super_block.get_or_init_inode(1, || {
                VfsInode::new_dir_with_defaults(
                    NodeFlags::empty(),
                    inode_init(1, NodeType::Directory, 0),
                )
            });
            Dentry::new_dir_from_inode(root_inode, None, String::new())
        },
    );
    let failed = super_block.get_or_try_init_inode(50, || Err::<Arc<VfsInode>, _>(7u8));
    assert!(matches!(failed, Err(7)));
    let first = super_block.get_or_init_inode(50, || {
        VfsInode::new_file_with_address_space_and_flags(
            Arc::new(MockFileOps::new(fs.clone(), 50, b"first")),
            NodeFlags::empty(),
            &MOCK_ADDRESS_SPACE_OPERATIONS,
            inode_init(50, NodeType::RegularFile, b"first".len() as u64),
        )
    });
    let second = super_block.get_or_init_inode(50, || panic!("live inode should be reused"));

    assert!(Arc::ptr_eq(&first, &second));
    assert!(Arc::ptr_eq(&first.super_block().unwrap(), &super_block));
    assert_eq!(first.inode(), 50);
    assert_eq!(super_block.root_dir().inode(), 1);
    assert!(super_block.lookup_inode(1).is_some());
    assert!(super_block.lookup_inode(50).is_some());

    let old_identity = Arc::downgrade(&first);
    drop(first);
    drop(second);
    assert!(old_identity.upgrade().is_none());
    assert!(super_block.lookup_inode(50).is_none());
    let replacement = super_block.get_or_init_inode(50, || {
        VfsInode::new_file_with_address_space_and_flags(
            Arc::new(MockFileOps::new(fs, 50, b"replacement")),
            NodeFlags::empty(),
            &MOCK_ADDRESS_SPACE_OPERATIONS,
            inode_init(50, NodeType::RegularFile, b"replacement".len() as u64),
        )
    });
    assert!(!core::ptr::eq(
        old_identity.as_ptr(),
        Arc::as_ptr(&replacement)
    ));
}