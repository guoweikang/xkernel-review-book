fn mknod_at(
        &self,
        root: &Path,
        base: &Path,
        mode: Umode,
        device: DeviceId,
        umask: NodePermission,
        cred: &Cred,
    ) -> VfsResult<Path> {
        self.mknod_at_entry(root, base, mode, device, umask, cred)
            .map(|created| created.path)
    }