fn new(
        owner: FileLockOwner,
        pid: i32,
        kind: FileLockType,
        start: i64,
        length: i64,
    ) -> KResult<Self> {
        if start < 0 {
            return Err(KError::InvalidInput);
        }
        let (start, end) = match length.cmp(&0) {
            core::cmp::Ordering::Greater => (
                start,
                start
                    .checked_add(length - 1)
                    .ok_or(KError::from(LinuxError::EOVERFLOW))?,
            ),
            core::cmp::Ordering::Less => {
                let lower = start
                    .checked_add(length)
                    .filter(|offset| *offset >= 0)
                    .ok_or(KError::InvalidInput)?;
                (lower, start - 1)
            }
            core::cmp::Ordering::Equal => (start, i64::MAX),
        };
        Ok(Self::range(owner, pid, kind, start, end))
    }