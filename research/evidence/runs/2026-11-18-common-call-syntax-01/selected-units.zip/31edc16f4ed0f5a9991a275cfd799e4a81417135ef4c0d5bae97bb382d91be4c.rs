fn trailing_dot_over_regular_file_is_not_a_directory() {
    let tree = test_tree();

    // `target` is a regular file. Linux rejects `target/.` with ENOTDIR because
    // the walk requires the component a `.` follows to be a directory
    // (`d_can_lookup` in fs/namei.c `link_path_walk`); dropping the component
    // made this path resolve as plain `target` and succeed.
    for intent in [LookupIntent::Open, LookupIntent::Stat] {
        let err = Filename::new("/target/.")
            .lookup_at(
                &tree.root,
                &tree.base,
                intent,
                LookupFlags::follow(),
                &kcred::initial_cred(),
            )
            .unwrap_err();
        assert_eq!(err, VfsError::NotADirectory);
    }

    // An open that would create or truncate through the file is rejected too.
    for flags in [
        linux_raw_sys::general::O_RDONLY,
        linux_raw_sys::general::O_WRONLY,
        linux_raw_sys::general::O_CREAT | linux_raw_sys::general::O_WRONLY,
    ] {
        let err = Filename::new("/target/.")
            .open_with_flags_at(
                &tree.root,
                &tree.base,
                flags,
                NodePermission::default(),
                NodePermission::empty(),
                kcred::initial_cred(),
            )
            .map(|_| ())
            .unwrap_err();
        assert_eq!(err, VfsError::NotADirectory);
    }

    // A directory still accepts the same shape.
    Filename::new("/dir/.")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
}