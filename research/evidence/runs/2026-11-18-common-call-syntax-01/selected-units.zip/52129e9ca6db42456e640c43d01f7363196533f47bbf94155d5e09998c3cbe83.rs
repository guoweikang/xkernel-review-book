fn child_names<'a>(&'a self) -> VfsResult<KBox<dyn Iterator<Item = Cow<'a, str>> + 'a>> {
        if self.fail {
            return Err(VfsError::NoMemory);
        }
        Ok(KBox::new(NamesIter {
            drops: self.drops.clone(),
            remaining: Some(Cow::Borrowed("entry")).into_iter(),
        })?)
    }