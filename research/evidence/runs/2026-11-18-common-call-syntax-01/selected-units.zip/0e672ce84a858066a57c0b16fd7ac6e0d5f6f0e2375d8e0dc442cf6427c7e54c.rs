fn read(&self, file: &VfsFile, buf: &mut [u8], offset: u64) -> VfsResult<usize> {
        let state = file
            .private_data_get::<Mutex<SeqFile<I>>>()
            .ok_or(VfsError::InvalidInput)?;
        state.lock().read(buf, offset)
    }