fn get_tree(
        &mut self,
        lookup_root: &Path,
        lookup_pwd: &Path,
    ) -> VfsResult<Arc<SuperBlock>> {
        if self.purpose != FsContextPurpose::Mount {
            return Err(VfsError::InvalidInput);
        }
        self.operations()?.get_tree(self, lookup_root, lookup_pwd)
    }