fn child_names<'a>(&'a self) -> VfsResult<KBox<dyn Iterator<Item = Cow<'a, str>> + 'a>> {
        Ok(KBox::new(
            self.0.child_names()?.chain(self.1.child_names()?),
        )?)
    }