fn make_dir_entry_with_parent(
    fs: Arc<MockFilesystem>,
    inode: u64,
    parent: Option<Dentry>,
    name: &str,
) -> Dentry {
    let inode = VfsInode::new_openable_dir(
        Arc::new(MockDirOps::new(fs, inode)),
        inode_init(inode, NodeType::Directory, 0),
    );
    Dentry::new_dir_from_inode(inode, parent, String::from(name))
}