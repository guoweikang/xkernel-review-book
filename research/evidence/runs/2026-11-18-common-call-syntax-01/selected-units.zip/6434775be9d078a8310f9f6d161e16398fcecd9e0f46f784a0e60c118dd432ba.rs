fn writeback_cached_ranges(
        &self,
        control: &mut WritebackControl,
        max_bytes: usize,
        mut write_range_fn: impl FnMut(u64, &[u8]) -> WritebackRangeResult,
    ) -> VfsResult<()> {
        self.i_pages.write_cache_pages(
            self.visible_len()?,
            control.range_start()..control.range_end(),
            &mut control.nr_to_write,
            &mut control.pages_skipped,
            max_bytes,
            &mut write_range_fn,
        )
    }