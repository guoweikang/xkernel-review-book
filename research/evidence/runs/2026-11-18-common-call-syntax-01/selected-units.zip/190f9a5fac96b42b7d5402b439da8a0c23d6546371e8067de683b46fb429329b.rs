fn lookup_no_follow(path: &Path, name: &str) -> VfsResult<Path> {
    use crate::path::{DOT, DOTDOT};

    Ok(match name {
        DOT => path.clone(),
        DOTDOT => path.parent().unwrap_or_else(|| path.clone()),
        _ => lookup_child_in_mount(path, name)?.resolve_final_mount(),
    })
}