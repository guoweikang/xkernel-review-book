fn simple_rename_noreplace_rejects_positive_target() {
    let old_dir = dir_inode(1, 2);
    let new_dir = dir_inode(2, 2);
    let source = file_inode(3, 1);
    let target = file_inode(4, 1);
    let old_parent = Dentry::new_dir_from_inode(old_dir.clone(), None, String::from("old"));
    let new_parent = Dentry::new_dir_from_inode(new_dir.clone(), None, String::from("new"));
    let old_dentry =
        Dentry::new_file_from_inode(source.clone(), Some(old_parent), String::from("source"));
    let new_dentry =
        Dentry::new_file_from_inode(target.clone(), Some(new_parent), String::from("target"));

    assert_eq!(
        simple_rename(
            &MountIdmap,
            &old_dir,
            &old_dentry.lock_location(),
            &new_dir,
            &new_dentry.lock_location(),
            RenameFlags::NOREPLACE,
        ),
        Err(VfsError::AlreadyExists)
    );
    assert_eq!(source.link_count(), 1);
    assert_eq!(target.link_count(), 1);
}