fn non_root_credential_without_capabilities_does_not_bypass_zero_mode() {
    let m = meta(2000, 2000, 0o000);
    assert!(check_dac_permission(&m, Permission::MAY_READ, &creds(1000, 1000, &[])).is_err());
    assert!(check_dac_permission(&m, Permission::MAY_WRITE, &creds(1000, 1000, &[])).is_err());
}