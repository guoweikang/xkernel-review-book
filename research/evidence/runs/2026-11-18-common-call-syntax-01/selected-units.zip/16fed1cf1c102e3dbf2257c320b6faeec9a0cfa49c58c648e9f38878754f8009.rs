fn wait() {
    static INIT: Once<usize> = Once::new();

    let t = std::thread::spawn(|| {
        assert_eq!(*INIT.wait(), 3);
        assert!(INIT.is_completed());
    });

    for _ in 0..4 {
        thread::yield_now()
    }

    assert!(INIT.poll().is_none());
    INIT.call_once(|| 3);

    t.join().unwrap();
}