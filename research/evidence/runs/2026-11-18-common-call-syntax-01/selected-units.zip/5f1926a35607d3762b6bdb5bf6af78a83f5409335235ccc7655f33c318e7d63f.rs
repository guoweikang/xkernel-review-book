fn walk_component(
        &mut self,
        name: &str,
        component: WalkComponent,
        cred: &Cred,
    ) -> VfsResult<()> {
        let qstr = self.hash_name(name);
        let name = qstr.as_str();
        // The container's directory-ness is owned by `link_path_walk`'s
        // `d_can_lookup` check, which runs for every component before it is
        // walked (and before the search permission), mirroring Linux.
        let containing_dir = self.path.clone();
        let next = match self.lookup_fast(name) {
            Some(dentry) => dentry?,
            None => self.lookup_slow(name)?,
        }
        .resolve_final_mount();
        let next = self.step_into(&containing_dir, next, component, cred)?;
        self.set_path(next);
        Ok(())
    }