fn grow_size_after_backing_write(&self, end: u64) -> VfsResult<()> {
        if self.node_type() != NodeType::RegularFile {
            return Ok(());
        }
        let _data_guard = self.data_lock.write();
        if end > self.size() {
            self.mapping.truncate_setsize_after_backing_change(end)?;
        }
        Ok(())
    }