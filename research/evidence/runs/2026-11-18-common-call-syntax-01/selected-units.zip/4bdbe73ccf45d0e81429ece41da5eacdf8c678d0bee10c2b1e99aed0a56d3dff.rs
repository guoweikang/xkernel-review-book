fn bind_super_block(&self, super_block: &Arc<SuperBlock>) {
        let inode = self.0.inode.lock().clone();
        if let Some(inode) = &inode {
            inode.bind_super_block(super_block);
        }
        let requested = Arc::downgrade(super_block);
        let bound = self.0.super_block.call_once(|| requested.clone());
        // Linux assigns `d_sb` at allocation and never rebinds a dentry.
        assert!(
            Weak::ptr_eq(bound, &requested),
            "one VFS dentry identity must not belong to multiple superblocks"
        );
        if let Some(default_operations) = super_block.default_dentry_operations() {
            let installed = self.0.operations.call_once(|| default_operations);
            assert!(
                core::ptr::eq(*installed, default_operations),
                "one VFS dentry identity must not change operation tables"
            );
        }

        // Only publish children into the dcache when they are cacheable,
        // mirroring `insert_cache`. `bind_super_block` must not defeat
        // `NON_CACHEABLE` filesystems (e.g. procfs), where every child dentry
        // would otherwise be retained by the superblock dcache forever.
        // Negative dentries carry no inode; `can_cache_children` requires one,
        // so check the already-held inode's flags directly instead.
        let cache_children = inode
            .as_ref()
            .is_some_and(|inode| !inode.flags().contains(NodeFlags::NON_CACHEABLE));
        let children: Vec<_> = self.0.children.lock().values().cloned().collect();
        for child in children {
            if let Some(child) = child.upgrade().map(Dentry) {
                child.bind_super_block(super_block);
                if cache_children && child.can_cache_as_child() {
                    super_block.cache_dentry(child);
                }
            }
        }
    }