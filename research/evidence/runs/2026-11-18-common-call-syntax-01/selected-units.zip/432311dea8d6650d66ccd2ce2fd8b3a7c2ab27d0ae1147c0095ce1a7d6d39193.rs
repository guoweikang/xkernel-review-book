fn non_final_symlink_is_followed_even_when_final_no_follow() {
    let tree = test_tree();

    let leaf = Filename::new("/dirlink/leaf")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::no_follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(leaf.name(), "leaf");
    assert_eq!(leaf.dentry().node_type(), NodeType::RegularFile);
}