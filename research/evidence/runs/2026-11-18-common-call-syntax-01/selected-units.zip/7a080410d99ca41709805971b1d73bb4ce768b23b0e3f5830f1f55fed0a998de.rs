fn mknod_at_strips_setgid_like_linux_vfs_prepare_mode() {
    let tree = test_tree();
    tree.root
        .dentry()
        .update_metadata(MetadataUpdate {
            mode: Some(NodePermission::from_bits_truncate(0o2777)),
            owner: Some((0, 4242)),
            ..Default::default()
        })
        .unwrap();
    let cred = kcred::Cred::new(1000, 1000);

    let stripped = Filename::new("/stripped")
        .mknod_at(
            &tree.root,
            &tree.base,
            Umode::new(
                NodeType::RegularFile,
                NodePermission::from_bits_truncate(0o2770),
            ),
            DeviceId::default(),
            NodePermission::empty(),
            &cred,
        )
        .unwrap();
    assert_eq!(
        stripped.metadata().mode.permission().bits(),
        NodePermission::from_bits_truncate(0o770).bits()
    );

    let preserved = Filename::new("/preserved")
        .mknod_at(
            &tree.root,
            &tree.base,
            Umode::new(
                NodeType::RegularFile,
                NodePermission::from_bits_truncate(0o2760),
            ),
            DeviceId::default(),
            NodePermission::empty(),
            &cred,
        )
        .unwrap();
    assert_eq!(
        preserved.metadata().mode.permission().bits(),
        NodePermission::from_bits_truncate(0o2760).bits()
    );

    tree.root
        .dentry()
        .update_metadata(MetadataUpdate {
            mode: Some(NodePermission::from_bits_truncate(0o0777)),
            owner: Some((0, 4242)),
            ..Default::default()
        })
        .unwrap();
    let preserved_without_parent_setgid = Filename::new("/ordinary-parent")
        .mknod_at(
            &tree.root,
            &tree.base,
            Umode::new(
                NodeType::RegularFile,
                NodePermission::from_bits_truncate(0o2770),
            ),
            DeviceId::default(),
            NodePermission::empty(),
            &cred,
        )
        .unwrap();
    assert_eq!(
        preserved_without_parent_setgid
            .metadata()
            .mode
            .permission()
            .bits(),
        NodePermission::from_bits_truncate(0o2770).bits()
    );
}