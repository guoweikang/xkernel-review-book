fn child_mount_at(&self, dentry: &Dentry) -> Option<Arc<Self>> {
        let key = dentry.key();
        let mut mounts = self.mnt_mounts.lock();
        let mount = mounts.get(&key).and_then(Weak::upgrade);
        if mount.is_none() {
            mounts.remove(&key);
        }
        mount
    }