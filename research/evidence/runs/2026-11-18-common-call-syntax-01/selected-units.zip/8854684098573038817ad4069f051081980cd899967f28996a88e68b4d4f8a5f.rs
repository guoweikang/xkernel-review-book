fn render_components(&self, root: Option<&Self>) -> VfsResult<(bool, Vec<String>)> {
        let mut components = Vec::new();
        let mut current = self.clone();
        loop {
            if root.is_some_and(|root| current.ptr_eq(root)) {
                return Ok((true, components));
            }

            if !current.dentry.ptr_eq(&current.mnt.mnt.mnt_root) {
                components.push(current.name());
                let Some(parent) = current.dentry.parent() else {
                    return Ok((root.is_none(), components));
                };
                current = current.with_dentry(parent);
                continue;
            }

            let Some(mountpoint) = current.mnt.location() else {
                return Ok((root.is_none(), components));
            };
            if root.is_some_and(|root| mountpoint.ptr_eq(root)) {
                return Ok((true, components));
            }
            components.push(mountpoint.name());
            let Some(parent) = mountpoint.parent() else {
                return Ok((root.is_none(), components));
            };
            current = parent;
        }
    }