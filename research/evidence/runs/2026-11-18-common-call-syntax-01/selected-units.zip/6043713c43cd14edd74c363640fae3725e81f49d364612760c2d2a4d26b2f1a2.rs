fn set_len(&self, len: u64) -> VfsResult<()> {
        let _data_guard = self.data_lock.write();
        let _invalidate_guard = self.mapping.lock_invalidate_exclusive();
        self.inode_operations.set_len(self, len)?;
        if self.size() == len {
            Ok(())
        } else {
            Err(VfsError::InvalidData)
        }
    }