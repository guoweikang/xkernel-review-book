fn read_with(
        &self,
        nonblocking: bool,
        mut read: impl FnMut(&mut PipeState) -> KResult<usize>,
    ) -> KResult<usize> {
        block_on(poll_file_io(self, IoEvents::IN, nonblocking, || {
            let (read, has_writers) = {
                let mut state = self.state.lock();
                let read = read(&mut state)?;
                (read, state.writers > 0)
            };

            if read > 0 {
                ktask::with_wake_sync(|| self.wr_wait.wake());
                Ok(read)
            } else if !has_writers {
                Ok(0)
            } else {
                Err(KError::WouldBlock)
            }
        }))
    }