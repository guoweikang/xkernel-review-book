fn test_metadata_uses_synthetic_device_identity() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::empty());

    let root_mount = Mount::new_root(&root_fs);
    let mount_dir = lookup_no_follow(&root_mount.root_path(), "mnt").unwrap();
    let child_mount = mount_filesystem(&mount_dir, &child_fs).unwrap();
    let child_root = child_mount.root_path();

    let root_metadata = root_mount.root_path().getattr().unwrap();
    let child_metadata = child_root.getattr().unwrap();

    assert_eq!(root_metadata.inode, 1);
    assert_eq!(child_metadata.inode, 1);
    assert_eq!(root_metadata.device, root_mount.synthetic_device_id());
    assert_eq!(child_metadata.device, child_mount.synthetic_device_id());
    assert!(root_metadata.device != child_metadata.device);
}