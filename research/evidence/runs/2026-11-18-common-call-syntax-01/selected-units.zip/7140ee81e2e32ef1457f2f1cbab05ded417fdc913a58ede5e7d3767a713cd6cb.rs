fn apply(&self, request: &FileLock, is_blocking: bool) -> KResult<()> {
        let mut waiter = None;
        let mut wake = WakeQueue::new();
        loop {
            let result = self.try_apply(request, is_blocking, &mut waiter, &mut wake);
            wake.wake();
            match result {
                Ok(true) => {
                    let result = waiter
                        .as_ref()
                        .expect("blocked request")
                        .wait_interruptible();
                    if result.is_ok() {
                        // Keep this request's children: a successful retry will
                        // transfer them to the installed lock without waking.
                        continue;
                    }
                    waiter
                        .as_ref()
                        .expect("blocked request")
                        .cancel_waiter(&mut wake);
                    wake.wake();
                    return result;
                }
                result => {
                    if let Some(waiter) = &waiter {
                        waiter.cancel_waiter(&mut wake);
                        wake.wake();
                    }
                    return result.map(|_| ());
                }
            }
        }
    }