fn readlink(root: &Path, base: &Path, name: &Filename, cred: &Cred) -> VfsResult<String> {
        let location = name.lookup_at(
            root,
            base,
            LookupIntent::Readlink,
            LookupFlags::no_follow(),
            cred,
        )?;
        if let Some(link) = d_inode(location.dentry()).magic_link() {
            link.readlink_display()
        } else {
            d_inode(location.dentry()).read_link(location.dentry())
        }
    }