fn test_root_dir_search_bypasses_missing_exec_bit() {
    let mut m = meta(1000, 1000, 0o000);
    m.mode = m.mode.with_node_type(NodeType::Directory);
    assert!(check_dac_permission(&m, Permission::MAY_EXEC, &creds(0, 0, &[])).is_ok());
}