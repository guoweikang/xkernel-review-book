fn page_mkwrite<R>(
        &self,
        index: PageIndex,
        update_mapping: impl FnOnce(&mut FolioGuard<'_>) -> VfsResult<R>,
    ) -> VfsResult<R> {
        // Timestamp policy may acquire filesystem locks; keep it outside the folio.
        self.file_update_time()?;
        self.mapping().page_mkwrite(
            index,
            |pos, len| {
                if let Some(ops) = self.operations().mapping_operations() {
                    ops.page_mkwrite(self, pos, len)?;
                }
                Ok(())
            },
            update_mapping,
        )
    }