fn readahead(&self, control: &mut crate::ReadaheadControl<'_>) -> VfsResult<()> {
        assert!(control.mapping().invalidate_lock.try_write().is_none());
        match control.index() {
            0 => {
                assert_eq!(control.count(), 4);
                for index in 0..4 {
                    let mut data = vec![0x11 * (index + 1) as u8; PAGE_SIZE_4K];
                    if index == 3 {
                        data[17..].fill(0);
                    }
                    assert_eq!(control.complete_folio(&data), Ok(()));
                }
                Ok(())
            }
            2 => {
                assert_eq!(control.count(), 2);
                // The run is already resident and locked; completion fills
                // those folios instead of racing to insert new backing copies.
                assert_eq!(control.complete_folio(&vec![0x22; PAGE_SIZE_4K]), Ok(()));
                assert_eq!(control.index(), 3);
                assert_eq!(control.count(), 1);
                assert_eq!(control.complete_folio(&[0x33]), Err(KError::InvalidInput));
                assert_eq!(control.index(), 4);
                assert_eq!(control.count(), 0);
                assert_eq!(control.complete_folio(&[]), Err(KError::InvalidInput));
                Err(KError::Io)
            }
            _ => panic!("resident folios must not be submitted for readahead"),
        }
    }