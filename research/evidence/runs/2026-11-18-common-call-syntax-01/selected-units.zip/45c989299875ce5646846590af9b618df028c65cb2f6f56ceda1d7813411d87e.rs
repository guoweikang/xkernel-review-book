fn open_character_device(
    inode: &VfsInode,
    file: &mut VfsFileBuilder,
    ops: Arc<dyn DeviceFileOps>,
) -> VfsResult<()> {
    // Linux derives the device type from the inode mode
    // (`devcgroup_inode_permission`), so an open reports READ/WRITE plus the
    // node's type half of `access_type`.
    let access = device_access_for_mode(file)
        | match inode.node_type() {
            NodeType::BlockDevice => DeviceAccess::TYPE_BLOCK,
            _ => DeviceAccess::TYPE_CHAR,
        };
    check_device_access(inode.rdev(), access)?;
    let fops = Arc::new(ChrdevFileOperations::new(ops));
    file.replace_fops(fops.clone());
    fops.open(inode, file)
}