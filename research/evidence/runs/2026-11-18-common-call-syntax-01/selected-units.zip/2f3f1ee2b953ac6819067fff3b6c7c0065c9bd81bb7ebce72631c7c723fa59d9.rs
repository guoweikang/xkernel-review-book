fn later_flags_change_does_not_affect_existing_control_block() {
    let file = test_file(OpenFlags::DIRECT);
    let iocb = Kiocb::new(&file, 0);
    file.replace_flags(OpenFlags::DIRECT, OpenFlags::empty());
    assert_eq!(iocb.flags(), KiocbFlags::DIRECT);
    assert!(Kiocb::new(&file, 0).flags().is_empty());
}