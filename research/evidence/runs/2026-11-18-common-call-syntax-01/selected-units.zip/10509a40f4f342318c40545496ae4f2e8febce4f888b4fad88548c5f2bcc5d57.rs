fn fill_next_entry(&mut self) -> VfsResult<bool> {
        if self.is_eof {
            return Ok(false);
        }

        self.buf.clear();
        self.buf_read_pos = 0;
        let next_item = if !self.started {
            self.started = true;
            self.iter.start()
        } else {
            self.iter.next()
        };

        match next_item {
            Some(item) => {
                if let Err(error) = self.iter.try_show(&item, &mut self.buf) {
                    self.reset();
                    return Err(error);
                }
                if self.buf.is_empty() {
                    return self.fill_next_entry();
                }
                Ok(true)
            }
            None => {
                self.is_eof = true;
                Ok(false)
            }
        }
    }