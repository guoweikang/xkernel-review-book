fn mknod(
        &self,
        _idmap: &crate::MountIdmap,
        _dir: &VfsInode,
        dentry: &LockedDentry<'_>,
        mode: Umode,
        device: DeviceId,
        _cred: &Cred,
    ) -> VfsResult<()> {
        self.creations.lock().push(CreateRecord {
            mode,
            exclusive: true,
            device,
        });
        self.instantiate_created(dentry, mode, device)
    }