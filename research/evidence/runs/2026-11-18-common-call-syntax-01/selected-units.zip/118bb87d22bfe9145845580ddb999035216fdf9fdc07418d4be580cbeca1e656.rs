fn cloned_from(
        base: &VfsFile,
        flags: FMode,
        open_flags: OpenFlags,
        f_op: Arc<dyn FileOperations>,
    ) -> Self {
        let mut file = Self::empty(flags, open_flags, base.cred.clone());
        file.bind_location(FileLocation::cloned_from(base));
        file.install_operations(f_op);
        file
    }