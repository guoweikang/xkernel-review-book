fn copy_file_range(
    input: &Arc<VfsFile>,
    input_position: TransferPosition<'_>,
    output: &Arc<VfsFile>,
    output_position: TransferPosition<'_>,
    len: usize,
    _nonblocking: bool,
) -> KResult<usize> {
    input.verify_mode(FMode::READ)?;
    output.verify_mode(FMode::WRITE)?;

    let mut input_scratch = 0;
    let mut output_scratch = 0;
    let mut positions = resolve_pair_positions(
        input,
        input_position,
        output,
        output_position,
        &mut input_scratch,
        &mut output_scratch,
    );
    let (input_start, output_start) = positions.starts();
    let count = verify_copy_file_range(input, output, input_start, output_start, len as u64)?;
    let mut input_pos = input_start;
    let mut output_pos = output_start;
    let result = pump(count as usize, |buf, chunk, _total| {
        match output.copy_chunk_from(input, input_pos, output_pos, chunk) {
            Some(native) => {
                let confirmed = native?;
                if confirmed > chunk {
                    return Err(KError::Io);
                }
                input_pos += confirmed as u64;
                output_pos += confirmed as u64;
                Ok(Step::Data {
                    confirmed,
                    stop: confirmed < chunk,
                })
            }
            None => file_pair_step(input, output, &mut input_pos, &mut output_pos, buf, chunk),
        }
    });

    // Position commit belongs to the completion protocol: publish only
    // after real progress — a zero-byte return leaves `f_pos` alone.
    if matches!(result, Ok(count) if count > 0) {
        positions.commit(input_pos, output_pos);
    }
    result
}