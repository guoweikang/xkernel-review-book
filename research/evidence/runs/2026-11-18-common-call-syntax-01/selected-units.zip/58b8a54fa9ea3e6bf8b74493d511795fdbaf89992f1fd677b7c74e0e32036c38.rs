fn execute<F>(self, may_rename_fn: F) -> VfsResult<()>
    where
        F: FnOnce(&Dentry, &Dentry) -> VfsResult<()>,
    {
        let old_dir_inode = self.old_parent.vfs_inode();
        let new_dir_inode = self.new_parent.vfs_inode();

        if self.old_parent.ptr_eq(self.new_parent) {
            let _parent_guard = old_dir_inode.lock_namespace_exclusive();
            return self.execute_with_parents_locked(
                &old_dir_inode,
                &new_dir_inode,
                false,
                None,
                may_rename_fn,
            );
        }

        let old_super_block = self
            .old_parent
            .super_block()
            .ok_or(VfsError::CrossesDevices)?;
        let new_super_block = self
            .new_parent
            .super_block()
            .ok_or(VfsError::CrossesDevices)?;
        if !Arc::ptr_eq(&old_super_block, &new_super_block) {
            return Err(VfsError::CrossesDevices);
        }

        let _topology_guard = old_super_block.lock_rename_topology();
        let (old_parent_first, trap) = self.parent_lock_order()?;
        if Arc::ptr_eq(&old_dir_inode, &new_dir_inode) {
            let _parent_guard = old_dir_inode.lock_namespace_exclusive();
            return self.execute_with_parents_locked(
                &old_dir_inode,
                &new_dir_inode,
                true,
                trap.as_ref(),
                may_rename_fn,
            );
        }
        if old_parent_first {
            let _old_parent_guard = old_dir_inode.lock_namespace_exclusive();
            let _new_parent_guard = new_dir_inode.lock_namespace_exclusive();
            self.execute_with_parents_locked(
                &old_dir_inode,
                &new_dir_inode,
                true,
                trap.as_ref(),
                may_rename_fn,
            )
        } else {
            let _new_parent_guard = new_dir_inode.lock_namespace_exclusive();
            let _old_parent_guard = old_dir_inode.lock_namespace_exclusive();
            self.execute_with_parents_locked(
                &old_dir_inode,
                &new_dir_inode,
                true,
                trap.as_ref(),
                may_rename_fn,
            )
        }
    }