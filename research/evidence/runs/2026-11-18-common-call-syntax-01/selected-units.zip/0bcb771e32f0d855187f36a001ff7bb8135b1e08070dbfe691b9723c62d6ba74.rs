fn test_readonly_mount_blocks_rename() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let mount = Mount::new_root_with_flags(&fs, MountFlags::RDONLY);
    let root = mount.root_path();

    let result = root.rename(
        "a",
        &root,
        "b",
        RenameFlags::empty(),
        &kcred::initial_cred(),
    );
    assert_eq!(result, Err(VfsError::ReadOnlyFilesystem));
}