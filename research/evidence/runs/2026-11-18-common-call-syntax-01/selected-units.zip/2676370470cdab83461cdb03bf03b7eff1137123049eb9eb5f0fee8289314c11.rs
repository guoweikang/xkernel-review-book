fn open_read_inode(inode: Arc<VfsInode>) -> Arc<crate::VfsFile> {
    let sb = crate::nullfs::new_superblock();
    let mount = crate::Mount::new_root(&sb);
    let dentry = crate::Dentry::new_file_from_inode(inode, None, "readahead".into());
    dentry.bind_super_block(&sb);
    let mut builder = crate::VfsFileBuilder::from_path_state(
        crate::Path::new(mount, dentry),
        crate::FMode::READ | crate::FMode::PREAD,
        crate::OpenFlags::empty(),
        Arc::new(BufferedReadOps),
        kcred::initial_cred(),
    );
    builder.mark_opened().unwrap();
    builder.finish().unwrap()
}