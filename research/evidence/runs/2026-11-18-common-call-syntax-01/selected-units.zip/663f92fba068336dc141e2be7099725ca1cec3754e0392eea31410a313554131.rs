fn test_mountpoint_child_tracking_updates_for_mount_and_unmount() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::empty());

    let root_mount = Mount::new_root(&root_fs);
    assert_eq!(root_mount.children().len(), 0);

    let mount_dir = lookup_no_follow(&root_mount.root_path(), "mnt").unwrap();
    let child_mount = mount_filesystem(&mount_dir, &child_fs).unwrap();

    let children = root_mount.children();
    assert_eq!(children.len(), 1);
    assert!(Arc::ptr_eq(&children[0], &child_mount));

    child_mount.root_path().unmount().unwrap();
    assert_eq!(root_mount.children().len(), 0);
}