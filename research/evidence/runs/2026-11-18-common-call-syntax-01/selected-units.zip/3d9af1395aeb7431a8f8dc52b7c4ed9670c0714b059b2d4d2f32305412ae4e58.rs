fn poll(&self) -> Option<&T> {
        loop {
            // Check current initialization state
            let current_state = self.state.load(Ordering::Acquire);

            match current_state {
                Status::Uninitialized => return None,
                Status::Initializing => {
                    // Spin while another thread is initializing
                    core::hint::spin_loop();
                }
                Status::Ready => {
                    // SAFETY: `Status::Ready` is only observable after the
                    // initialized value has been published to `storage`.
                    return Some(unsafe { self.get_value_unchecked() });
                }
                #[expect(
                    clippy::panic,
                    reason = "CG-021-no-panic-on-reachable-failure: A previous initializer \
                              panicked and left no value; like std's poisoned Once and LazyLock, \
                              the value can never be produced"
                )]
                Status::Failed => {
                    panic!("OnceCell was contaminated by a previous panic")
                }
            }
        }
    }