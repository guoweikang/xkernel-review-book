fn inode_link_count_helpers_update_link_count() {
    let node = Arc::new(TestChrdevInode::new(DeviceId::default()));
    let init = VfsInodeInit::new(
        7,
        0,
        Umode::new(
            NodeType::CharacterDevice,
            NodePermission::from_bits_truncate(0o666),
        ),
    )
    .with_owner_links_and_rdev(0, 0, 1, DeviceId::new(1, 3));
    let inode = VfsInode::new_special(node, NodeFlags::NON_CACHEABLE, init);

    assert_eq!(inode.link_count(), 1);
    inode.increment_link_count();
    assert_eq!(inode.link_count(), 2);
    inode.decrement_link_count();
    assert_eq!(inode.link_count(), 1);
    inode.increment_link_count();
    assert_eq!(inode.link_count(), 2);
    inode.decrement_link_count();
    assert_eq!(inode.link_count(), 1);
    inode.set_link_count(7);
    assert_eq!(inode.link_count(), 7);
    inode.clear_link_count();
    assert_eq!(inode.link_count(), 0);
}