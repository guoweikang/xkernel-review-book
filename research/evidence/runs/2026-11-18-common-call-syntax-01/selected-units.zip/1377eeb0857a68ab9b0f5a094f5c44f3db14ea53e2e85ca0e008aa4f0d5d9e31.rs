fn drop(&mut self) {
        let cache = inode_cache();
        let cache_key = cache.begin_eviction(self);
        let result = self.evict_inode();
        if let Some(cache_key) = cache_key {
            cache.finish_eviction(self, &cache_key);
        }
        if let Err(err) = result {
            log::warn!("failed to evict inode {}: {err:?}", self.inode());
        }
    }