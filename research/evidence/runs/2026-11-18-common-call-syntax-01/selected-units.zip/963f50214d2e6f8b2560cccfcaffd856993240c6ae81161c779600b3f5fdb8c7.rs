fn new(init: VfsInodeInit) -> Self {
        Self {
            mode: InodeMode::new(init.mode),
            owner: Mutex::new(InodeOwner::new(init.uid, init.gid)),
            link_count: Mutex::new(init.link_count),
            generation: init.generation,
            rdev: init.rdev,
            size: Mutex::new(init.size),
            times: Mutex::new(StoredInodeTimes::new(
                init.accessed_at,
                init.modified_at,
                init.changed_at,
            )),
            block_accounting: Mutex::new(InodeBlockAccounting::new(init.blocks, init.block_bytes)),
        }
    }