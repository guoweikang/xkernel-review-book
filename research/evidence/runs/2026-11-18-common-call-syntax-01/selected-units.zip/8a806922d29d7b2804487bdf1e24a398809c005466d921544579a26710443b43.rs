fn test_render_from_reports_unreachable_mount_tree() {
    let first = Mount::new_root(&mock_filesystem(StatFsFlags::empty())).root_path();
    let second = Mount::new_root(&mock_filesystem(StatFsFlags::empty())).root_path();

    assert_eq!(
        second.render_from(&first),
        Ok(RenderedPath::Unreachable(PathBuf::from("/")))
    );
}