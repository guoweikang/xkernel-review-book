fn wait_until_available_or_dead(&self) -> bool {
        loop {
            self.lifecycle_waiters
                .wait_until(|| !self.lifecycle.lock().is_initializing_or_dying());
            match &*self.lifecycle.lock() {
                SuperBlockLifecycle::Available { .. } => return true,
                SuperBlockLifecycle::Dead => return false,
                SuperBlockLifecycle::Nascent | SuperBlockLifecycle::Dying => {}
            }
        }
    }