fn shutdown(&self) -> VfsResult<()> {
        // X-Kernel does not retain dirty inodes independently of dentries yet,
        // so write back before dropping dcache ownership. Eviction can publish
        // additional filesystem metadata, which requires the second sync.
        let writeback_result = self.sync_fs_locked();
        if let Some(root) = self.root.get()
            && let Ok(root) = root.as_dir()
        {
            root.forget();
        }
        let flush_result = self.sync_fs_locked();
        writeback_result.and(flush_result)
    }