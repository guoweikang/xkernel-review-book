fn open_magic_link_uses_captured_path_not_display_name() {
    let tree = test_tree();
    // The display name is not a path in this tree. Following the link must
    // use its retained Path, just as procfd retains an unlinked inode.
    let file = Filename::new("/magic")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            linux_raw_sys::general::O_RDONLY,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .unwrap();
    assert!(file.path().ptr_eq(&tree.target));
    assert_eq!(tree.magic_file.last_intent(), Some(LookupIntent::Open));
    assert_eq!(tree.magic_file.follow_count(), 1);
}