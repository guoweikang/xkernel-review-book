fn uncache_lookup_candidate(&self, name: &str, candidate: &Dentry) {
        let mut children = self.0.children.lock();
        let is_candidate = children
            .get(name)
            .is_some_and(|entry| Weak::ptr_eq(entry, &Arc::downgrade(&candidate.0)));
        if is_candidate {
            children.remove(name);
        }
        drop(children);
        if is_candidate && let Some(super_block) = candidate.super_block() {
            super_block.uncache_dentry(candidate);
        }
    }