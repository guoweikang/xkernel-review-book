fn from_parts(first: &'a [u8], second: &'a [u8]) -> VfsResult<Self> {
        let len = first
            .len()
            .checked_add(second.len())
            .ok_or_else(|| VfsError::from(LinuxError::ERANGE))?;
        if len == 0 || len > XATTR_NAME_MAX || first.contains(&0) || second.contains(&0) {
            return Err(VfsError::from(LinuxError::ERANGE));
        }
        Ok(Self { first, second })
    }