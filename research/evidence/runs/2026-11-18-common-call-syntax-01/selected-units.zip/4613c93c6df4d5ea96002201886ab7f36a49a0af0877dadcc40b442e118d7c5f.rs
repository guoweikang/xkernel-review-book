fn failed_fill_wakes_waiter_and_allows_retry() {
    reset_transition_test_state();
    let (disk, block_device) = add_test_disk("kvfs-failed-fill", 250);
    let owner_device = block_device.clone();
    let owner = ktask::spawn(move || {
        match super_block_registry().get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            owner_device,
            SuperBlockFlags::empty(),
            fail_test_bdev,
        ) {
            Err(VfsError::InvalidInput) => {}
            result => panic!("failed fill returned an unexpected result: {result:?}"),
        }
    });
    TRANSITION_WAITERS.wait_until(|| TRANSITION_STAGE.load(Ordering::Acquire) == 1);

    let waiter = spawn_successful_waiting_mount(block_device);
    TRANSITION_WAITERS.wait_until(|| TRANSITION_WAITER_STARTED.load(Ordering::Acquire) == 1);
    ktask::yield_now();
    assert_eq!(TRANSITION_WAITER_DONE.load(Ordering::Acquire), 0);

    TRANSITION_STAGE.store(2, Ordering::Release);
    TRANSITION_WAITERS.notify_all(true);
    owner.join();
    waiter.join();

    assert_eq!(TRANSITION_WAITER_DONE.load(Ordering::Acquire), 1);
    assert_eq!(FILL_COUNT.load(Ordering::Relaxed), 2);
    block::del_gendisk(disk.device_number()).expect("remove failed-fill test disk");
}