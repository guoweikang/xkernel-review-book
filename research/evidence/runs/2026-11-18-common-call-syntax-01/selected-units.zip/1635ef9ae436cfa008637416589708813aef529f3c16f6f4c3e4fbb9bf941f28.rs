fn attach_bind(&self, source: &Path, mountpoint: &Path) -> VfsResult<Arc<Mount>> {
        let mut mounts = self.mounts.lock();
        Self::require_mount(&mounts, source.mount())?;
        Self::require_mount(&mounts, mountpoint.mount())?;
        let mount = mountpoint.mount_bind(source)?;
        mounts.insert(mount.mount_id(), mount.clone());
        Ok(mount)
    }