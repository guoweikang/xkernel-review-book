fn register_filesystem(file_system_type: &'static FileSystemType) -> VfsResult<()> {
    let mut file_systems = FILE_SYSTEMS.lock();
    if file_systems
        .iter()
        .any(|registered| registered.name == file_system_type.name)
    {
        return Err(VfsError::ResourceBusy);
    }
    file_systems.push(file_system_type);
    Ok(())
}