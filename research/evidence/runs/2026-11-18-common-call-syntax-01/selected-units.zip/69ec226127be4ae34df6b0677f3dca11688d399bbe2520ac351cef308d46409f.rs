fn block_device_file_reports_live_capacity() {
    const BLOCK_SIZE: usize = 512;
    const BLOCKS: usize = 4;
    let backend = Arc::new(MemoryBlockDevice {
        storage: Arc::new(Mutex::new(vec![0u8; BLOCK_SIZE * BLOCKS])),
        block_size: BLOCK_SIZE,
        flushes: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        reads: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        writes: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        fail_io: Arc::new(core::sync::atomic::AtomicBool::new(false)),
        fail_after_write_bytes: core::sync::atomic::AtomicUsize::new(usize::MAX),
    });
    let disk = block::Gendisk::alloc(
        String::from("kvfs-size-test"),
        245,
        0,
        1,
        Box::new(backend.clone()),
    )
    .expect("valid size test disk");
    let device = block::add_disk(disk).expect("publish size test disk");

    let rdev = device.disk().device_number();
    let (file, stat_path) = open_block_device_file(rdev).expect("open block device");

    // Regression for the fallocate-clamp regression: the opened file must
    // expose the device capacity (the `blkdev_llseek` view), not the special
    // node's zero size.
    assert_eq!(file.size(), (BLOCK_SIZE * BLOCKS) as u64);
    // The node metadata stays zero-sized on purpose: Linux device nodes also
    // stat as zero while `SEEK_END` reports the capacity through the opened
    // file. getattr must NOT report the capacity.
    assert_eq!(file.inode().size(), 0);
    assert_eq!(stat_path.getattr().unwrap().size, 0);

    // SEEK_END is the capacity view (`blkdev_llseek` reads bd_inode).
    assert_eq!(file.llseek(0, SEEK_END).unwrap(), (BLOCK_SIZE * BLOCKS) as u64);
    // Seeks are bounded by the capacity (`fixed_size_llseek` in
    // `blkdev_llseek`): at-end allowed, past-end EINVAL.
    assert_eq!(file.llseek((BLOCK_SIZE * BLOCKS) as i64, SEEK_SET).unwrap(), (BLOCK_SIZE * BLOCKS) as u64);
    assert_eq!(
        LinuxError::from(
            file.llseek((BLOCK_SIZE * BLOCKS + 1) as i64, SEEK_SET)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );

    // Live view: capacity changes after open (loop attach/detach style) are
    // visible without reopening; the file holds no snapshot.
    device
        .set_capacity(((BLOCK_SIZE * 8) / 512) as u64)
        .expect("resize test device");
    // Keep the fixture self-consistent: the backend storage grows with the
    // announced capacity (pattern-filled, like the initial fill).
    backend.storage.lock().resize(BLOCK_SIZE * 8, 0x35);
    assert_eq!(file.size(), (BLOCK_SIZE * 8) as u64);
    assert_eq!(stat_path.getattr().unwrap().size, 0);
    // The seek bound follows the live capacity.
    assert_eq!(
        file.llseek((BLOCK_SIZE * 8) as i64, SEEK_SET).unwrap(),
        (BLOCK_SIZE * 8) as u64
    );
    assert_eq!(
        LinuxError::from(
            file.llseek((BLOCK_SIZE * 8 + 1) as i64, SEEK_SET)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );

    // Append writes keep the caller's position on block devices
    // (`blkdev_write_iter` writes at ki_pos): with O_APPEND and f_pos 0, the
    // data lands at the device start, not at the capacity end.
    let append = crate::OpenFlags::READ_WRITE | crate::OpenFlags::APPEND;
    let (append_file, _append_stat) =
        open_block_device_file_with(rdev, append).expect("open append test device");
    let payload: Vec<u8> = (0..64u8).collect();
    let mut pos = 0u64;
    let written = append_file.write_from(&payload, &mut pos).expect("append write");
    assert_eq!(written, payload.len());
    {
        let storage = backend.storage.lock();
        assert_eq!(&storage[..payload.len()], &payload[..]);
        // The capacity-end tail stays pattern-filled: the append did NOT
        // relocate to the capacity end.
        let tail = BLOCK_SIZE * 8;
        assert!(storage[tail - payload.len()..tail].iter().all(|&b| b == 0x35));
    }

    block::del_gendisk(device.disk().device_number()).expect("remove size test disk");
}