fn parent_at_preserves_root_final_type() {
    let tree = test_tree();

    let lookup = Filename::new("/")
        .parent_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            &kcred::initial_cred(),
        )
        .unwrap();

    assert!(lookup.parent().ptr_eq(&tree.root));
    assert_eq!(lookup.name(), "/");
    assert_eq!(lookup.last_type(), LastType::Root);
}