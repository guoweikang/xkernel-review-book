fn test_seq_file_rewinds_on_zero_offset() {
    let mut seq = SeqFile::new(LinesIter::new());
    let mut buf = [0; 6];
    assert_eq!(seq.read(&mut buf, 0).unwrap(), 6);
    assert_eq!(&buf, b"hello\n");
    assert_eq!(seq.read(&mut buf, 0).unwrap(), 6);
    assert_eq!(&buf, b"hello\n");
}