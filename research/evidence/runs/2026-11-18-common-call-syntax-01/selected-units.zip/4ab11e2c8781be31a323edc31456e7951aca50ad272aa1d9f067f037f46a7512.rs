fn test_dentry_positive_and_negative_helpers() {
    let negative = Dentry::new_negative(None, String::from("missing"));
    assert!(d_is_negative(&negative));
    assert!(!negative.is_positive());
    assert!(!d_is_dir(&negative));
    assert!(!negative.is_regular_entry());
    assert!(!negative.is_special_entry());
    assert!(!d_is_symlink(&negative));
    assert!(negative.is_really_negative());
    assert!(!d_really_is_positive(&negative));

    let _fs = Arc::new(MockFilesystem);
    let unknown_inode = VfsInode::new_file(
        Arc::new(MockFileOps::new_with_type(
            23,
            NodeType::Unknown,
            b"unknown",
        )),
        inode_init(23, NodeType::Unknown, b"unknown".len() as u64),
    );
    let unknown = Dentry::new_file_from_inode(unknown_inode, None, String::from("unknown"));
    assert!(!d_is_negative(&unknown));
    assert!(unknown.is_positive());
    assert!(!d_is_dir(&unknown));
    assert!(!unknown.is_regular_entry());
    assert!(unknown.is_special_entry());
    assert!(unknown.is_file_entry());
    assert!(!d_is_symlink(&unknown));
    assert!(!unknown.is_really_negative());
    assert!(d_really_is_positive(&unknown));
}