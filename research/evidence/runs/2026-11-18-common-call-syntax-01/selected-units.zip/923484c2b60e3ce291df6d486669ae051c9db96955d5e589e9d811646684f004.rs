fn may_mknod(mode: Umode) -> VfsResult<NodeType> {
    match mode.mknod_node_type() {
        node_type @ (NodeType::RegularFile
        | NodeType::CharacterDevice
        | NodeType::BlockDevice
        | NodeType::Fifo
        | NodeType::Socket) => Ok(node_type),
        NodeType::Directory => Err(VfsError::OperationNotPermitted),
        NodeType::Unknown | NodeType::Symlink => Err(VfsError::InvalidInput),
    }
}