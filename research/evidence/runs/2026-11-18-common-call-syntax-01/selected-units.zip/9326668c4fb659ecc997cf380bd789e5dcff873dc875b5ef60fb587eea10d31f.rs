fn chown(&self, uid: Option<u32>, gid: Option<u32>, cred: &Cred) -> VfsResult<()> {
        self.check_writable_mount()?;
        let metadata = self.metadata();
        let is_owner = cred.fsuid() == metadata.uid;
        let can_chown = cred.has_cap_chown();

        if uid.is_some_and(|uid| !can_chown && (!is_owner || uid != metadata.uid)) {
            return Err(VfsError::OperationNotPermitted);
        }
        if gid.is_some_and(|gid| {
            !can_chown && (!is_owner || (gid != metadata.gid && !cred.in_group(gid)))
        }) {
            return Err(VfsError::OperationNotPermitted);
        }

        let new_gid = gid.unwrap_or(metadata.gid);
        let mode = Self::chown_mode(metadata.mode, metadata.gid, gid, cred);
        // Linux `chown_common()` turns the set-ID cleanup into an `ATTR_MODE`
        // update, and `setattr_prepare()` authorizes that generated mode change
        // through inode ownership or effective `CAP_FOWNER` — not through
        // `CAP_CHOWN`/`CAP_FSETID`. `chown(-1, -1)` therefore remains a
        // successful no-op for an unrelated caller unless it would actually
        // clear a set-ID bit.
        if mode.bits() != metadata.mode.permission().bits()
            && cred.fsuid() != metadata.uid
            && !cred.has_cap_fowner()
        {
            return Err(VfsError::OperationNotPermitted);
        }
        self.dentry.update_metadata(MetadataUpdate {
            owner: Some((uid.unwrap_or(metadata.uid), new_gid)),
            mode: Some(mode),
            ..Default::default()
        })
    }