fn scalar_write_iter_rewinds_unaccepted_bytes() {
    let file = sync_test_file(Arc::new(ShortWriteOperations), FMode::WRITE);
    let mut iocb = Kiocb::new(&file, 7);
    let mut iter = iov_iter_kvec_source(b"abcdef");
    assert_eq!(file.operations().write_iter(&mut iocb, &mut iter), Ok(2));
    assert_eq!(iter.count(), 4);
    assert_eq!(iocb.ki_pos(), 9);
}