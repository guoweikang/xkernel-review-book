fn character_replacement_opens_once_and_releases_only_final_backend() {
    for can_read in [false, true] {
        for can_write in [false, true] {
            let backend = CharacterBackend::new(can_read, can_write, false);
            let multiplexer = Arc::new(CharacterMultiplexer {
                backend: backend.clone(),
                opens: AtomicUsize::new(0),
                releases: AtomicUsize::new(0),
            });
            let file = open_test_character(multiplexer.clone()).unwrap();
            assert_eq!(multiplexer.opens.load(Ordering::Relaxed), 1);
            assert_eq!(backend.opens.load(Ordering::Relaxed), 1);
            assert_eq!(file.mode().contains(FMode::CAN_READ), can_read);
            assert_eq!(file.mode().contains(FMode::CAN_WRITE), can_write);
            let alias = file.clone();
            drop(file);
            assert_eq!(backend.releases.load(Ordering::Relaxed), 0);
            drop(alias);
            assert_eq!(backend.releases.load(Ordering::Relaxed), 1);
            assert_eq!(multiplexer.releases.load(Ordering::Relaxed), 0);
        }
    }
    let backend = CharacterBackend::new(true, true, true);
    let multiplexer = Arc::new(CharacterMultiplexer {
        backend: backend.clone(),
        opens: AtomicUsize::new(0),
        releases: AtomicUsize::new(0),
    });
    assert!(matches!(
        open_test_character(multiplexer.clone()),
        Err(VfsError::NoSuchDevice)
    ));
    assert_eq!(multiplexer.opens.load(Ordering::Relaxed), 1);
    assert_eq!(backend.opens.load(Ordering::Relaxed), 1);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 0);
    assert_eq!(multiplexer.releases.load(Ordering::Relaxed), 0);
}