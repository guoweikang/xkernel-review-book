fn next_path_component<'p>(
        pathname: &mut &'p str,
        at_start: &mut bool,
    ) -> Option<(LastType, &'p str)> {
        loop {
            if (*pathname).is_empty() {
                return None;
            }
            let current = *pathname;
            let (component, rest) = match current.find('/') {
                Some(index) => (&current[..index], &current[index + 1..]),
                None => (current, ""),
            };
            *pathname = rest;
            let result = match component {
                "" if *at_start => Some((LastType::Root, "/")),
                "" => None,
                // A "." is a component wherever it appears: Linux keeps it (leading or
                // not), so the walk still verifies that the component it follows
                // sits in a directory (`d_can_lookup` -> ENOTDIR). Dropping a
                // non-leading "." made `file/.` resolve as `file` and succeed.
                "." => Some((LastType::Dot, ".")),
                ".." => Some((LastType::Dotdot, "..")),
                name => Some((LastType::Norm, name)),
            };
            *at_start = false;
            if let Some(result) = result {
                return Some(result);
            }
        }
    }