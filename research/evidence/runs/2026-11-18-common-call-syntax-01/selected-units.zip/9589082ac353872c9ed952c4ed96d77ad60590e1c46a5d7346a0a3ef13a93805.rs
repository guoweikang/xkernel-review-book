fn lock(&self) -> SpinLockGuard<'_, G, T> {
        let guard_state = G::acquire();

        #[cfg(feature = "smp")]
        {
            #[cfg(feature = "stats")]
            let mut did_wait = false;
            // Opportunistic acquire: weak CAS in a loop, with a secondary
            // spin phase while the lock appears taken.
            loop {
                if self
                    .flag
                    .compare_exchange_weak(false, true, Ordering::Acquire, Ordering::Relaxed)
                    .is_ok()
                {
                    #[cfg(feature = "stats")]
                    self.record_acquisitions();
                    #[cfg(feature = "stats")]
                    if did_wait {
                        self.record_contentions();
                    }
                    break;
                }
                while self.is_locked() {
                    #[cfg(feature = "stats")]
                    {
                        did_wait = true;
                    }
                    core::hint::spin_loop();
                }
            }
        }

        #[cfg(all(feature = "stats", not(feature = "smp")))]
        self.record_acquisitions();

        SpinLockGuard {
            _token: &PhantomData,
            guard_state,
            // SAFETY: the guard has acquired the spinlock and will release it
            // on drop, so this guard is the unique mutable accessor until then.
            ptr: unsafe { &mut *self.storage.get() },
            #[cfg(feature = "smp")]
            flag_ref: &self.flag,
        }
    }