fn readahead_reads_singletons_preserves_residents_and_completes_eof() {
    let size = PAGE_SIZE_4K * 3 + 17;
    let initial_inode = read_inode(&READAHEAD_OPS, size);
    let mut initial_byte = [0];
    assert_eq!(
        initial_inode
            .address_space()
            .read_from_page_cache(&mut iov_iter_kvec_dest(&mut initial_byte), 0),
        Ok(1)
    );
    assert_eq!(initial_byte, [0x11]);
    assert_eq!(initial_inode.address_space().nrpages(), 4);
    let small_inode = read_inode(&READAHEAD_OPS, 1);
    let mut byte = [0];
    assert_eq!(
        small_inode
            .address_space()
            .read_from_page_cache(&mut iov_iter_kvec_dest(&mut byte), 0),
        Ok(1)
    );
    assert_eq!(byte[0], 0x11);
    let inode = read_inode(&READAHEAD_OPS, size);
    let mapping = inode.address_space();
    mapping
        .i_pages
        .filemap_add_folio(super::folio_from_bytes(1, &vec![0x99; PAGE_SIZE_4K]))
        .unwrap_or_else(|_| panic!("fixture index is absent"));
    let mut output = vec![0xff; size + 10];
    assert_eq!(
        mapping.read_from_page_cache(&mut iov_iter_kvec_dest(&mut output), 0),
        Ok(size)
    );
    assert!(output[..PAGE_SIZE_4K].iter().all(|&byte| byte == 0x11));
    assert!(
        output[PAGE_SIZE_4K..PAGE_SIZE_4K * 2]
            .iter()
            .all(|&byte| byte == 0x99)
    );
    assert!(
        output[PAGE_SIZE_4K * 2..PAGE_SIZE_4K * 3]
            .iter()
            .all(|&byte| byte == 0x22)
    );
    assert!(
        output[PAGE_SIZE_4K * 3..size]
            .iter()
            .all(|&byte| byte == 0x33)
    );
    assert!(output[size..].iter().all(|&byte| byte == 0xff));
    mapping
        .with_folio(3, |folio| {
            assert!(folio.unwrap().data()[17..].iter().all(|&byte| byte == 0))
        })
        .unwrap();
}