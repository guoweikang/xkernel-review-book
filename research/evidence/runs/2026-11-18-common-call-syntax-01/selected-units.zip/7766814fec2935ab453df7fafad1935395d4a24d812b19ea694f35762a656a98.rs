fn del(&mut self, first: DeviceId, count: u32) -> Option<Arc<ChrdevEntry>> {
        let last_minor = first.minor().checked_add(count.checked_sub(1)?)?;
        let key = (first.major(), first.minor());
        if self.entries.get(&key)?.last_minor != last_minor {
            return None;
        }
        let entry = self.entries.remove(&key)?;
        entry.is_registered.store(false, Ordering::Release);
        Some(entry)
    }