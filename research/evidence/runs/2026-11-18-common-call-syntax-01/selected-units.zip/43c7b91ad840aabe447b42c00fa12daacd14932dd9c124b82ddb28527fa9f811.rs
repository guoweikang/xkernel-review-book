fn fill_next_extent_adds_implied_flags() {
    let mut writer = CollectingWriter::default();
    let mut info = FiemapExtentInfo::new(FiemapFlags::empty(), 1, &mut writer);

    assert!(
        !info
            .fill_next_extent(0, 0, 4096, FiemapExtentFlags::DELALLOC)
            .expect("delayed extent should be valid")
    );
    assert_eq!(info.mapped_extents(), 1);
    assert!(
        writer.extents[0]
            .3
            .contains(FiemapExtentFlags::DELALLOC | FiemapExtentFlags::UNKNOWN)
    );
}