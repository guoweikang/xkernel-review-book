fn read(&self, file: &VfsFile, buf: &mut [u8], offset: u64) -> VfsResult<usize> {
        let snapshot = file
            .private_data_get::<SimpleFileSnapshot>()
            .ok_or(VfsError::InvalidData)?;
        read_generated_bytes(&snapshot.0, buf, offset)
    }