fn initialize_inner<E>(
        self: &Arc<Self>,
        ops: &'static dyn SuperBlockOperations,
        default_dentry_operations: Option<&'static dyn DentryOperations>,
        private: Option<KBox<dyn Any + Send + Sync>>,
        block_size: u64,
        max_file_size: u64,
        init_root_fn: impl FnOnce(&Arc<Self>) -> Result<Dentry, E>,
    ) -> Result<(), E> {
        assert!(
            matches!(*self.lifecycle.lock(), SuperBlockLifecycle::Nascent),
            "only a nascent superblock can be initialized"
        );
        assert!(
            self.ops.get().is_none()
                && self.default_dentry_operations.get().is_none()
                && self.private.get().is_none()
                && self.root.get().is_none()
                && self.block_size.get().is_none()
                && self.max_file_size.get().is_none()
                && self.timestamp_limits.get().is_none(),
            "a superblock can only be initialized once"
        );
        assert!(
            block_size.is_power_of_two(),
            "a superblock block size must be a non-zero power of two"
        );
        self.ops.call_once(|| ops);
        if let Some(default_dentry_operations) = default_dentry_operations {
            self.default_dentry_operations
                .call_once(|| default_dentry_operations);
        }
        if let Some(private) = private {
            self.private.call_once(|| private);
        }
        self.block_size.call_once(|| block_size);
        self.max_file_size
            .call_once(|| max_file_size.min(MAX_LFS_FILESIZE));
        self.timestamp_limits
            .call_once(|| ops.timestamp_limits(self));
        let root = init_root_fn(self)?;
        Self::publish_root(self, root);
        Ok(())
    }