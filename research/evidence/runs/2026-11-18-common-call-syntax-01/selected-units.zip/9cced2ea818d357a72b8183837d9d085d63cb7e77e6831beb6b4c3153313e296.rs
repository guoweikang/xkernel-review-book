fn initialized_and_from_start_ready() {
    let from_initialized = Once::initialized(7u32);
    assert!(from_initialized.is_completed());
    assert_eq!(from_initialized.get().copied(), Some(7));

    let from_trait: Once<u32> = 9u32.into();
    assert!(from_trait.is_completed());
    assert_eq!(from_trait.get().copied(), Some(9));
}