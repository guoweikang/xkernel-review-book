fn test_rename_rejects_directory_move_into_descendant() {
    let root = make_renamable_dir_entry(46, None, "");
    let source = make_renamable_dir_entry(47, Some(root.clone()), "source");
    let child = make_renamable_dir_entry(48, Some(source.clone()), "child");
    root.insert_cache(String::from("source"), source.clone());
    source.insert_cache(String::from("child"), child.clone());
    let _super_block = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        root.clone()
    });

    assert_eq!(
        root.rename("source", &child, "moved", RenameFlags::empty()),
        Err(VfsError::InvalidInput)
    );
    assert!(root.lookup_cache("source").unwrap().ptr_eq(&source));
}