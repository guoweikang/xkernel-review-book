fn drop(&mut self) {
        if self.is_published {
            return;
        }
        let mut inodes = self.cache.inodes.lock();
        let waiters = if matches!(
            inodes.get(&self.key),
            Some(entry) if matches!(entry.state, CachedInodeState::New)
        ) {
            inodes.remove(&self.key).map(|entry| entry.waiters)
        } else {
            None
        };
        drop(inodes);
        if let Some(waiters) = waiters {
            waiters.notify_all(false);
        }
    }