fn metadata_only_inode_operations_accepts_owner_changes() {
    let ops = metadata_only_inode_operations();
    let inode = VfsInode::new_dir(
        Arc::new(EmptyInodeOperations),
        VfsInodeInit::new(
            1,
            0,
            Umode::new(NodeType::Directory, NodePermission::empty()),
        ),
    );
    let dentry = Dentry::new_dir_from_inode(inode, None, String::new());
    let update = MetadataUpdate {
        owner: Some((1, 2)),
        mode: Some(NodePermission::from_bits_truncate(0o600)),
        ..Default::default()
    };
    let applied = ops
        .setattr(&MountIdmap, &dentry, update.clone())
        .expect("metadata-only ops must accept setattr");
    assert_eq!(applied.owner, Some((1, 2)));
    assert_eq!(
        applied.mode.map(|mode| mode.bits()),
        Some(NodePermission::from_bits_truncate(0o600).bits())
    );
}