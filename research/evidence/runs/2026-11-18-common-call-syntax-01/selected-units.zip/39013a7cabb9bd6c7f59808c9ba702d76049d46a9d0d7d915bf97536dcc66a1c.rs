fn get_or_try_init_inode<E>(
    super_block: &Arc<SuperBlock>,
    inode_number: u64,
    init_inode_fn: impl FnOnce() -> Result<Arc<VfsInode>, E>,
) -> Result<Arc<VfsInode>, E> {
    inode_cache().get_or_try_insert_with(super_block, inode_number, || {
        let inode = init_inode_fn()?;
        inode.bind_super_block(super_block);
        Ok(inode)
    })
}