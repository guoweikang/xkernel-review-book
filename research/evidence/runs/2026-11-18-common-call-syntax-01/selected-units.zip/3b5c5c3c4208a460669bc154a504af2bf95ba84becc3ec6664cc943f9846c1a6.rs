fn root_path<O: SimpleDirOps>(ops: Arc<O>) -> Path {
    let super_block = SimpleFs::new_with(&TEST_FILE_SYSTEM_TYPE, 0, move |fs| {
        SimpleDir::new_maker(fs, ops)
    })
    .unwrap();
    Mount::new_root(&super_block).root_path()
}