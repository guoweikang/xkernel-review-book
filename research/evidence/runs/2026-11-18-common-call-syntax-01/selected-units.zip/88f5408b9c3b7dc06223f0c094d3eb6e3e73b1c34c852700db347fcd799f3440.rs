fn copy_to_iter(&mut self, src: &[u8]) -> KResult<usize> {
            assert_eq!(src[0], 1);
            let mut ra = self.file.readahead.lock();
            while ra.is_enabled() {
                ra.shrink_after_io_error();
            }
            let copied = self.remaining.min(src.len());
            self.remaining -= copied;
            Ok(copied)
        }