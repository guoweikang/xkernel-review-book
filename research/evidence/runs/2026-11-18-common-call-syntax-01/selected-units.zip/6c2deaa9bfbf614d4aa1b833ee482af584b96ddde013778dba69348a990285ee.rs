fn test_make_mount_private_rejects_non_mount_root_path() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::new_root(&root_fs, kcred::initial_user_namespace());
    let mount_dir = lookup_no_follow(&namespace.root_path(), "mnt").unwrap();

    assert_eq!(
        namespace.make_mount_private(&mount_dir),
        Err(VfsError::InvalidInput)
    );
}