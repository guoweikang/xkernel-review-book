async fn poll_file_io<P: Pollable, F: FnMut() -> KResult<T>, T>(
    pollable: &P,
    events: IoEvents,
    is_nonblocking: bool,
    mut operation_fn: F,
) -> KResult<T> {
    match operation_fn() {
        Err(KError::WouldBlock) if !is_nonblocking => {}
        result => return result,
    }

    match poll_io_with_cause(pollable, events, false, &mut operation_fn).await {
        Ok(result) => result,
        Err(interrupted) if interrupted.is_task_interrupt() => match operation_fn() {
            Err(KError::WouldBlock) => Err(KError::IoWaitInterrupted),
            result => result,
        },
        Err(error) => Err(error.into()),
    }
}