fn move_cached_dentry(
        &self,
        old_key: &DentryKey,
        new_key: &DentryKey,
        source: &Dentry,
    ) {
        let mut cache = self.dentry_cache.lock();
        let removed = cache.remove(old_key);
        if let Some(target_slot) = cache.get_mut(new_key) {
            *target_slot = source.clone();
        }
        drop(cache);
        drop(removed);
    }