fn test_pivot_root_rejects_put_old_outside_new_root() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let new_root_fs = mock_filesystem(StatFsFlags::empty());
    let other_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::build_initial_mount_tree(&root_fs).unwrap();
    let visible = namespace.visible_root_path();
    let cred = kcred::initial_cred();
    let new_mnt = namespace
        .attach(
            &visible
                .mkdir("newroot", NodePermission::default(), &cred)
                .unwrap(),
            &new_root_fs,
        )
        .unwrap();
    let other_mnt = namespace
        .attach(
            &visible
                .mkdir("other", NodePermission::default(), &cred)
                .unwrap(),
            &other_fs,
        )
        .unwrap();
    let put_old = other_mnt
        .root_path()
        .mkdir("oldroot", NodePermission::default(), &cred)
        .unwrap();

    assert_eq!(
        namespace.pivot_root(
            &new_mnt.root_path(),
            &put_old,
            &namespace.visible_root_path()
        ),
        Err(VfsError::InvalidInput),
        "put_old must be reachable from new_root"
    );
}