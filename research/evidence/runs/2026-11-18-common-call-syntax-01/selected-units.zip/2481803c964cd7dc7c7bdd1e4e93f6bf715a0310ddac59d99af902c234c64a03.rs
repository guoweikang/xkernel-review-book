fn read_iter(
        &self,
        iocb: &mut Kiocb<'_>,
        iter: &mut IovIterDest<'_>,
    ) -> VfsResult<usize> {
        let read = self.read_with_ra(iter, iocb.ki_pos(), &iocb.file().readahead)?;
        iocb.advance(read);
        Ok(read)
    }