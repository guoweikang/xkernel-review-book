fn handle_dots(&mut self, last_type: LastType) {
        match last_type {
            LastType::Root => self.set_path(self.root.clone()),
            LastType::Dot => {}
            LastType::Dotdot => {
                if !self.path.ptr_eq(&self.root) {
                    let parent = self.path.parent().unwrap_or_else(|| self.root.clone());
                    self.set_path(parent);
                }
            }
            LastType::Norm => {}
        }
    }