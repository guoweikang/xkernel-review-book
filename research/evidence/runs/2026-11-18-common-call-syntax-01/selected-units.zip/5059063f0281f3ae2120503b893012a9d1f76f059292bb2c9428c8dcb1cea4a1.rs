fn get_no_wait() {
    static INIT: Once<usize> = Once::new();

    assert!(INIT.get().is_none());
    let t = thread::spawn(move || {
        INIT.call_once(|| {
            thread::sleep(std::time::Duration::from_secs(3));
            42
        });
    });
    assert!(INIT.get().is_none());

    t.join().unwrap();
}