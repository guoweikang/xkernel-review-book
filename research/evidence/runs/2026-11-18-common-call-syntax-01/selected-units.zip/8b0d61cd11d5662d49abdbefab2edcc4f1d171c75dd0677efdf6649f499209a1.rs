fn remove_owner(&mut self, owner: FileLockOwner, wake: &mut WakeQueue) {
        let mut cursor = self.0.front_mut();
        while let Some(node) = cursor.get() {
            if node.owner == owner {
                if let Some(node) = cursor.remove() {
                    OwnedLock(node).detach_blocked(wake);
                }
            } else {
                cursor.move_next();
            }
        }
    }