fn read(&self) -> SpinRwLockReadGuard<'_, G, T> {
        let guard_state = G::acquire();
        #[cfg(feature = "stats")]
        let mut did_wait = false;

        loop {
            let state = self.state.load(Ordering::Acquire);
            if state & WRITE_LOCKED != 0 {
                #[cfg(feature = "stats")]
                {
                    did_wait = true;
                }
                core::hint::spin_loop();
                continue;
            }
            if state == READER_MASK {
                panic!("too many spin rwlock readers");
            }
            if self
                .state
                .compare_exchange_weak(state, state + 1, Ordering::Acquire, Ordering::Relaxed)
                .is_ok()
            {
                #[cfg(feature = "stats")]
                self.record_read_acquisition(did_wait);
                return SpinRwLockReadGuard {
                    lock: self,
                    guard_state,
                };
            }
        }
    }