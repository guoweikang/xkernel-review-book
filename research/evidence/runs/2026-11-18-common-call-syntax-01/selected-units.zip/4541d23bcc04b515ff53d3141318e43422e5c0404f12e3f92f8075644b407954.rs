fn buffered_read_stops_on_short_or_zero_copy() {
    for limit in [0, 23] {
        let inode = read_inode(&READ_OPS, PAGE_SIZE_4K * 40);
        let mapping = inode.address_space();
        let mut sink = ShortSink { copied: 0, limit };
        let mut iter = iov_iter_dest(&mut sink);
        assert_eq!(mapping.read_from_page_cache(&mut iter, 0), Ok(limit));
        assert_eq!(sink.copied, limit);
        // A short copy retains completed prefetch within the 128 KiB window.
        assert_eq!(mapping.nrpages(), 32);
    }
}