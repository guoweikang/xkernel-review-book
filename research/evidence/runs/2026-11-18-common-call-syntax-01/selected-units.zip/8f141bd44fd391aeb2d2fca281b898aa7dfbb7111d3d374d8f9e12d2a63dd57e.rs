fn test_chmod_setgid_retention_requires_fsetid_not_fowner() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let root = Mount::new_root(&fs).root_path();
    root.dentry
        .update_metadata(MetadataUpdate {
            mode: Some(NodePermission::from_bits_truncate(0o666)),
            owner: Some((1000, 100)),
            ..Default::default()
        })
        .unwrap();

    let cred_with = |capability: u32| {
        let mut cred = Cred::new(0, 0);
        cred.set_securebits(0x4).unwrap();
        cred.set_fsuid(1000);
        let set = kcred::CapSet::from_bits(1u64 << capability);
        cred.set_capabilities(kcred::CapSets::new(set, set, kcred::CapSet::EMPTY))
            .unwrap();
        cred
    };

    let fsetid = cred_with(kcred::CAP_FSETID);
    root.chmod(NodePermission::from_bits_truncate(0o2660), &fsetid)
        .unwrap();
    assert!(
        root.metadata()
            .mode
            .permission()
            .contains(NodePermission::SET_GID)
    );

    let fowner = cred_with(kcred::CAP_FOWNER);
    root.chmod(NodePermission::from_bits_truncate(0o2660), &fowner)
        .unwrap();
    assert!(
        !root
            .metadata()
            .mode
            .permission()
            .contains(NodePermission::SET_GID)
    );
}