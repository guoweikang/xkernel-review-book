fn new(rdev: DeviceId) -> Self {
        Self {
            metadata: Mutex::new(Metadata {
                device: 0,
                inode: 42,
                nlink: 1,
                mode: Umode::new(
                    NodeType::CharacterDevice,
                    NodePermission::from_bits_truncate(0o666),
                ),
                uid: 0,
                gid: 0,
                size: 0,
                block_size: 0,
                blocks: 0,
                rdev,
                atime: Default::default(),
                mtime: Default::default(),
                ctime: Default::default(),
            }),
            last_update: Mutex::new(None),
            next_applied_update: Mutex::new(None),
        }
    }