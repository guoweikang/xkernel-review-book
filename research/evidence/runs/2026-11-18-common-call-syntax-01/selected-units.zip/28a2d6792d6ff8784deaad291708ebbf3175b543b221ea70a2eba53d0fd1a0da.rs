fn new(
        root: &Path,
        base: &Path,
        filename: &'a Filename,
        intent: LookupIntent,
        flags: LookupFlags,
    ) -> Self {
        let pathname = filename.as_pathname();
        let path = if pathname.is_absolute() {
            root.clone()
        } else {
            base.clone()
        };
        Self {
            path,
            root: root.clone(),
            last: None,
            last_type: LastType::Root,
            inode: None,
            state: 0,
            depth: 0,
            total_link_count: 0,
            stack: Vec::new(),
            name: filename,
            pathname: pathname.as_str(),
            dfd: AT_FDCWD,
            intent,
            flags,
        }
    }