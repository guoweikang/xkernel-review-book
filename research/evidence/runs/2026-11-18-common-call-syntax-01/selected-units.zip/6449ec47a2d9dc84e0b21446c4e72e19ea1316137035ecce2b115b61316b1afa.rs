fn test_root_mount_defaults_to_writable() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let mount = Mount::new_root(&fs);
    let root = mount.root_path();

    assert_eq!(mount.flags(), MountFlags::empty());
    assert!(!mount.is_readonly());
    assert!(!root.is_mount_readonly());
    assert!(!root.is_effectively_readonly());
    assert_eq!(root.check_writable_mount(), Ok(()));
}