fn magic_link_no_follow_and_readlink_do_not_follow_target() {
    let tree = test_tree();

    let link = Filename::new("/magic")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::no_follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(link.dentry().node_type(), NodeType::Symlink);
    assert_eq!(tree.magic_file.follow_count(), 0);

    assert_eq!(
        Filename::new("/magic")
            .readlink_at(&tree.root, &tree.base, &kcred::initial_cred())
            .unwrap(),
        "/display/target"
    );
    assert_eq!(tree.magic_file.follow_count(), 0);
}