fn fail_test_bdev(_super_block: &Arc<SuperBlock>) -> VfsResult<()> {
    FILL_COUNT.fetch_add(1, Ordering::Relaxed);
    TRANSITION_STAGE.store(1, Ordering::Release);
    TRANSITION_WAITERS.notify_all(false);
    TRANSITION_WAITERS.wait_until(|| TRANSITION_STAGE.load(Ordering::Acquire) >= 2);
    Err(VfsError::InvalidInput)
}