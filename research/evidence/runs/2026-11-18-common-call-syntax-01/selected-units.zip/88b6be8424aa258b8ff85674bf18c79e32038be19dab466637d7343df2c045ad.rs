fn close(&self, mode: FMode) -> KResult<()> {
        let access = PipeAccess::from_mode(mode)?;
        let (wake_readers, wake_writers) = remove_access(&mut self.state.lock(), access);
        self.wake(wake_readers, wake_writers);
        Ok(())
    }