fn add_test_range(
    registry: &mut ChrdevRegistry,
    first: DeviceId,
    count: u32,
    ops: &Arc<dyn DeviceFileOps>,
) -> VfsResult<()> {
    let entry = Arc::new(ChrdevEntry::new(first, count, ops.clone())?);
    registry.add(&entry)
}