fn flock_domain_and_conversion() {
    let context = FileLockContext::new();
    let first = FileLockOwner::Flock(1);
    let second = FileLockOwner::Flock(2);
    context
        .apply(
            &FileLock::new(FileLockOwner::Posix(1), 1, FileLockType::Write, 0, 0).unwrap(),
            false,
        )
        .unwrap();
    for owner in [first, second] {
        context
            .apply(
                &FileLock::new(owner, 1, FileLockType::Read, 0, 0).unwrap(),
                false,
            )
            .unwrap();
    }
    assert_eq!(
        context.apply(
            &FileLock::new(first, 1, FileLockType::Write, 0, 0).unwrap(),
            false
        ),
        Err(KError::WouldBlock)
    );
    let state = context.state.lock();
    assert_eq!(state.flock.iter().count(), 1);
    assert_eq!(state.flock.iter().next().unwrap().owner, second);
}