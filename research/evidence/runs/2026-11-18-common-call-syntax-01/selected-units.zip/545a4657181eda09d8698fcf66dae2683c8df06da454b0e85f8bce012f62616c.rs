fn splice_rejects_oversized_write_without_consuming_source() {
    for reported in [4, usize::MAX] {
        let pipe = PipeObject::new_anonymous();
        pipe.write(true, true, b"abcdef").unwrap();
        let mut scratch = [0; 3];
        assert_eq!(
            pipe.splice_read(true, &mut scratch, |bytes| {
                assert_eq!(bytes, b"abc");
                Ok(reported)
            }),
            Err(KError::Io)
        );
        let mut remaining = [0; 6];
        assert_eq!(pipe.read(true, &mut remaining), Ok(6));
        assert_eq!(&remaining, b"abcdef");
    }
}