fn copy_to_iter(&mut self, src: &[u8]) -> KResult<usize> {
        self.output.extend_from_slice(src);
        if self.output.len() == PAGE_SIZE_4K {
            // Remove only future pages: the current folio is still locked by
            // the copy callback. This models residency changing during a read.
            if self.truncate {
                // The sink borrows the mapping of a live test inode.
                self.mapping.inode().unwrap().set_len(PAGE_SIZE_4K as u64)?;
            } else {
                self.mapping
                    .i_pages
                    .resize_cached_folios((PAGE_SIZE_4K * 3) as u64, PAGE_SIZE_4K as u64)
                    .unwrap();
            }
        }
        Ok(src.len())
    }