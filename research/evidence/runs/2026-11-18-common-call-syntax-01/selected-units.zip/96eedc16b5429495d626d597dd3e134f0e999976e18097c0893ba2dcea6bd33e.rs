fn pipe_read_iter(iocb: &mut Kiocb<'_>, iter: &mut IovIterDest<'_>) -> VfsResult<usize> {
    let read = {
        let file = iocb.file();
        file.verify_mode(FMode::READ)?;
        PipeObject::from_file(file)?.read_iter(file.is_nonblocking(), iter)?
    };
    iocb.advance(read);
    Ok(read)
}