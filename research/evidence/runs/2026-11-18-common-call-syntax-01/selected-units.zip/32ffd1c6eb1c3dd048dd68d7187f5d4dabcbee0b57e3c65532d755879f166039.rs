fn absolute_path(&self) -> VfsResult<PathBuf> {
        if !self.dentry.ptr_eq(&self.mnt.mnt.mnt_root)
            && let Some(dynamic_name) = self.dentry.dynamic_name()?
        {
            return Ok(PathBuf::from(dynamic_name));
        }

        let (_, components) = self.render_components(None)?;
        Ok(Self::components_to_path(&components))
    }