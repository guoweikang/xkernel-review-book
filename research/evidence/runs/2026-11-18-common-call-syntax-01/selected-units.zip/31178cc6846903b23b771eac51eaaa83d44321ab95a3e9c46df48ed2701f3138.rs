fn read_iter(&self, iocb: &mut Kiocb<'_>, iter: &mut IovIterDest<'_>) -> VfsResult<usize> {
        let mut total = 0usize;
        let mut chunk = [0u8; memaddr::PAGE_SIZE_4K];
        while iter.count() != 0 {
            let want = chunk.len().min(iter.count());
            if want == 0 {
                break;
            }
            let read = match self.read(iocb.file(), &mut chunk[..want], iocb.ki_pos()) {
                Ok(read) => read,
                Err(_) if total != 0 => break,
                Err(err) => return Err(err),
            };
            if read == 0 {
                break;
            }
            let copied = iter.copy_to_iter(&chunk[..read])?;
            total += copied;
            iocb.advance(copied);
            if copied < read || read < want {
                break;
            }
        }
        Ok(total)
    }