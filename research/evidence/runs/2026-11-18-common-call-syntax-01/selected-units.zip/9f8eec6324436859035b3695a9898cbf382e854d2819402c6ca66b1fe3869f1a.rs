fn test_file(flags: OpenFlags) -> Arc<VfsFile> {
    let root = crate::Mount::new_root(&crate::nullfs::new_superblock()).root_path();
    crate::VfsFileBuilder::from_path_state(
        root,
        crate::FMode::READ,
        flags,
        Arc::new(TestFileOperations),
        kcred::initial_cred(),
    )
    .finish()
    .unwrap()
}