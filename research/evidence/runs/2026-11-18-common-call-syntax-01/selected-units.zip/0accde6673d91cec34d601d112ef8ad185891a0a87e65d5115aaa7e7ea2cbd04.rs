fn new(_fs: Arc<MockFilesystem>, inode: u64) -> Self {
        Self {
            inode,
            can_rename: false,
            can_remove: false,
            unlink_count: AtomicUsize::new(0),
            rmdir_count: AtomicUsize::new(0),
            lookup_result: crate::Mutex::new(None),
        }
    }