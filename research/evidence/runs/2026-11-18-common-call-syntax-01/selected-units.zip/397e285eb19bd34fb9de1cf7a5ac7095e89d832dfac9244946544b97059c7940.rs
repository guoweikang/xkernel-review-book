fn chained_names_propagate_failure_and_drop_first_iterator() {
    let drops = Arc::new(AtomicU64::new(0));
    let chained = NamesOps { drops: drops.clone(), fail: false }
        .chain(NamesOps { drops: drops.clone(), fail: true });
    assert_eq!(chained.child_names().err(), Some(VfsError::NoMemory));
    assert_eq!(drops.load(Ordering::Relaxed), 1);
}