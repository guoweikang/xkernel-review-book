fn new_with_type(inode: u64, node_type: NodeType, data: &[u8]) -> Self {
        Self {
            inode,
            node_type,
            data: crate::Mutex::new(data.to_vec()),
            owner: crate::Mutex::new(None),
            update_count: AtomicUsize::new(0),
        }
    }