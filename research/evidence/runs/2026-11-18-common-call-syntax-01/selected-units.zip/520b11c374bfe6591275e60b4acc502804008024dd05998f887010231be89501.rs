fn lookup(
        &self,
        _dir: &VfsInode,
        dentry: &LockedDentry<'_>,
        _flags: crate::InodeLookupFlags,
    ) -> VfsResult<Option<Dentry>> {
        let name = dentry.name();
        if name != "mnt" {
            return Ok(None);
        }

        let inode = VfsInode::new_openable_dir(
            Arc::new(MockDirOps::new(self.mount_flags, self.inode + 1)),
            inode_init(self.inode + 1),
        );
        dentry.instantiate_or_alias(inode)
    }