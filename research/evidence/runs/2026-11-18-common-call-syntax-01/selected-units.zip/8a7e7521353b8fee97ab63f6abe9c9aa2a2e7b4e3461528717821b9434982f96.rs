fn open_block_device_file_with(
    rdev: DeviceId,
    flags: crate::OpenFlags,
) -> VfsResult<(Arc<VfsFile>, crate::Path)> {
    let init = VfsInodeInit::new(
        crate::get_next_ino(),
        0,
        Umode::new(
            NodeType::BlockDevice,
            NodePermission::from_bits_truncate(0o666),
        ),
    )
    .with_owner_links_and_rdev(0, 0, 1, rdev);
    let inode = VfsInode::new_special(
        Arc::new(TestBlkdevInode { rdev }),
        NodeFlags::empty(),
        init,
    );
    let mount = crate::Mount::new_root(&crate::nullfs::new_superblock());
    let dentry = crate::Dentry::new_file_from_inode(inode, None, String::from("blockdev"));
    let path = crate::Path::new(mount, dentry);
    let stat_path = path.clone();
    let file = VfsFileBuilder::allocate(flags, kcred::initial_cred())?.vfs_open(path)?;
    Ok((file, stat_path))
}