fn test_remount_updates_mount_and_shared_superblock_flags() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::new_root(&root_fs, kcred::initial_user_namespace());
    let root = namespace.root_path();
    let mountpoint = lookup_child_in_mount(&root, "mnt").unwrap();
    let cred = kcred::initial_cred();
    let mut readonly_context = FsContext::new_reconfigure(
        child_fs.as_ref(),
        None,
        None,
        SuperBlockFlags::RDONLY,
        SuperBlockFlags::RDONLY,
        &cred,
    )
    .unwrap();

    assert_eq!(
        namespace.remount(&mountpoint, &mut readonly_context, MountFlags::RDONLY),
        Err(VfsError::InvalidInput)
    );

    let child = namespace.attach(&mountpoint, &child_fs).unwrap();
    let child_root = child.root_path();
    let mut mount_context = FsContext::new(
        &MOCK_FILE_SYSTEM_TYPE,
        None,
        None,
        SuperBlockFlags::RDONLY,
        &cred,
    )
    .unwrap();
    assert_eq!(
        namespace.remount(&child_root, &mut mount_context, MountFlags::RDONLY),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(child.flags(), MountFlags::empty());
    assert_eq!(child.super_block_flags(), SuperBlockFlags::empty());

    let bind_mountpoint = lookup_child_in_mount(&child_root, "mnt").unwrap();
    let bind = namespace
        .attach_bind(&child_root, &bind_mountpoint)
        .unwrap();
    let bind_root = bind.root_path();

    namespace
        .remount(
            &child_root,
            &mut readonly_context,
            MountFlags::RDONLY | MountFlags::NOEXEC,
        )
        .unwrap();

    assert_eq!(child.flags(), MountFlags::RDONLY | MountFlags::NOEXEC);
    assert!(!bind.flags().contains(MountFlags::RDONLY));
    assert_eq!(
        child_root.check_writable_mount(),
        Err(VfsError::ReadOnlyFilesystem)
    );
    assert_eq!(
        bind_root.check_writable_mount(),
        Err(VfsError::ReadOnlyFilesystem)
    );

    let mut writable_context = FsContext::new_reconfigure(
        child_fs.as_ref(),
        None,
        None,
        SuperBlockFlags::empty(),
        SuperBlockFlags::RDONLY,
        &cred,
    )
    .unwrap();
    namespace
        .remount(&child_root, &mut writable_context, MountFlags::NOEXEC)
        .unwrap();
    assert!(child_root.check_writable_mount().is_ok());
    assert!(bind_root.check_writable_mount().is_ok());

    namespace
        .reconfigure_mount(&bind_root, MountFlags::RDONLY)
        .unwrap();
    assert!(child_root.check_writable_mount().is_ok());
    assert_eq!(
        bind_root.check_writable_mount(),
        Err(VfsError::ReadOnlyFilesystem)
    );
}