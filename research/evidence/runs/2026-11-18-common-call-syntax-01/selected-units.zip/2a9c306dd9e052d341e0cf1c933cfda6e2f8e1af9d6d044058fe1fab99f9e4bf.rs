fn unmount(&self) -> VfsResult<()> {
        if !self.dentry.ptr_eq(&self.mnt.mnt.mnt_root) {
            return Err(VfsError::InvalidInput);
        }
        let parent_path = self.mnt.location().ok_or(VfsError::InvalidInput)?;
        let inode = parent_path.inode();
        let _namespace_guard = inode.lock_namespace_exclusive();
        if !parent_path
            .mnt
            .child_mount_at(&parent_path.dentry)
            .is_some_and(|mount| Arc::ptr_eq(&mount, &self.mnt))
        {
            return Err(VfsError::InvalidInput);
        }
        if !self.mnt.mnt_mounts.lock().is_empty() {
            return Err(VfsError::ResourceBusy);
        }

        let covered = self.mnt.covers.lock().take();
        match covered {
            Some(ref mount) => {
                parent_path
                    .mnt
                    .install_child_mount(&parent_path.dentry, mount);
            }
            None => {
                parent_path.mnt.remove_child_mount(&parent_path.dentry);
            }
        }
        self.mnt.detach();
        Ok(())
    }