fn test_rename_moves_cache_entry_without_changing_inode_identity() {
    let fs = Arc::new(MockFilesystem);
    let root = make_renamable_dir_entry(30, None, "");
    let (source, _) = make_file_entry(fs, 31, Some(root.clone()), "tmp");

    root.insert_cache(String::from("tmp"), source.clone());
    root.rename("tmp", &root, "final", RenameFlags::empty())
        .unwrap();

    assert!(root.lookup_cache("tmp").is_none());
    let moved = root.lookup_cache("final").unwrap();
    assert!(moved.ptr_eq(&source));
    assert!(moved.is_same_inode(&source));
    assert_eq!(moved.name_snapshot(), "final");
    assert_eq!(moved.absolute_path().unwrap().as_str(), "/final");
}