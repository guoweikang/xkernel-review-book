fn with_pinned_file_page<R>(
        &self,
        index: PageIndex,
        f: impl FnOnce(PinnedFolio) -> VfsResult<R>,
    ) -> VfsResult<R> {
        let _invalidate_guard = self.invalidate_lock.read();
        let offset = index
            .checked_mul(PAGE_SIZE_4K as u64)
            .ok_or(VfsError::BadAddress)?;
        if offset >= self.visible_len()? {
            return Err(VfsError::BadAddress);
        }
        let pin = self
            .i_pages
            .pin_folio_or_create(index, |folio| self.ops.read_folio(self, folio))?;
        f(pin)
    }