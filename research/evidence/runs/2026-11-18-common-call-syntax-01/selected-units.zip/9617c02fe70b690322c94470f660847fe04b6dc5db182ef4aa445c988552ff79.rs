fn o_path_trailing_slash_follows_symlink_and_requires_directory() {
    let tree = test_tree();

    let regular = Filename::new("/target/").open_with_flags_at(
        &tree.root,
        &tree.base,
        linux_raw_sys::general::O_PATH,
        NodePermission::empty(),
        NodePermission::empty(),
        kcred::initial_cred(),
    );
    assert!(matches!(regular, Err(VfsError::NotADirectory)));

    let flags = linux_raw_sys::general::O_PATH | linux_raw_sys::general::O_NOFOLLOW;
    let directory = Filename::new("/dirlink/")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            flags,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(directory.node_type(), NodeType::Directory);

    let regular_link = Filename::new("/link/").open_with_flags_at(
        &tree.root,
        &tree.base,
        flags,
        NodePermission::empty(),
        NodePermission::empty(),
        kcred::initial_cred(),
    );
    assert!(matches!(regular_link, Err(VfsError::NotADirectory)));
}