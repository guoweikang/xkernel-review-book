fn nullfs_root_dentry() -> Dentry {
    let root = Arc::new(NullFsRoot);
    let private_data: Arc<dyn core::any::Any + Send + Sync> = root.clone();
    let inode_operations: Arc<dyn InodeOperations> = root.clone();
    let file_operations: Arc<dyn FileOperations> = root;
    let inode = VfsInode::new_dir_with_operations(
        private_data,
        inode_operations,
        file_operations,
        NodeFlags::PRIVATE,
        NullFsRoot::inode_init(),
    );
    Dentry::new_dir_from_inode(inode, None, alloc::string::String::new())
}