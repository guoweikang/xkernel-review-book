fn mknod_at_preserves_linux_error_precedence() {
    let tree = test_tree();
    tree.root
        .dentry()
        .update_metadata(MetadataUpdate {
            mode: Some(NodePermission::from_bits_truncate(0o777)),
            ..Default::default()
        })
        .unwrap();
    let cred = kcred::Cred::new(1000, 1000);

    let existing = Filename::new("/target").mknod_at(
        &tree.root,
        &tree.base,
        Umode::new(
            NodeType::CharacterDevice,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::new(1, 3),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(existing, Err(VfsError::AlreadyExists)));

    let existing_with_trailing_slash = Filename::new("/target/").mknod_at(
        &tree.root,
        &tree.base,
        Umode::new(
            NodeType::RegularFile,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::default(),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(
        existing_with_trailing_slash,
        Err(VfsError::AlreadyExists)
    ));

    let denied = Filename::new("/device").mknod_at(
        &tree.root,
        &tree.base,
        Umode::new(
            NodeType::CharacterDevice,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::new(1, 3),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(denied, Err(VfsError::OperationNotPermitted)));

    let trailing = Filename::new("/absent/").mknod_at(
        &tree.root,
        &tree.base,
        Umode::new(
            NodeType::RegularFile,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::default(),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(trailing, Err(VfsError::NotFound)));

    let readonly_mount = Mount::new_root_with_flags(&tree.fs, crate::MountFlags::RDONLY);
    let readonly_root = readonly_mount.root_path();
    let existing_readonly = Filename::new("/target").mknod_at(
        &readonly_root,
        &readonly_root,
        Umode::new(
            NodeType::RegularFile,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::default(),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(existing_readonly, Err(VfsError::AlreadyExists)));
    let absent_readonly = Filename::new("/readonly").mknod_at(
        &readonly_root,
        &readonly_root,
        Umode::new(
            NodeType::RegularFile,
            NodePermission::from_bits_truncate(0o600),
        ),
        DeviceId::default(),
        NodePermission::empty(),
        &cred,
    );
    assert!(matches!(absent_readonly, Err(VfsError::ReadOnlyFilesystem)));
}