fn simple_rename_rejects_unsupported_flags() {
    let old_dir = dir_inode(20, 2);
    let new_dir = dir_inode(21, 2);
    let source = file_inode(22, 1);
    let old_parent = Dentry::new_dir_from_inode(old_dir.clone(), None, String::from("old"));
    let new_parent = Dentry::new_dir_from_inode(new_dir.clone(), None, String::from("new"));
    let old_dentry = Dentry::new_file_from_inode(source, Some(old_parent), String::from("source"));
    let new_dentry = Dentry::new_negative(Some(new_parent), String::from("target"));

    assert_eq!(
        simple_rename(
            &MountIdmap,
            &old_dir,
            &old_dentry.lock_location(),
            &new_dir,
            &new_dentry.lock_location(),
            RenameFlags::WHITEOUT,
        ),
        Err(VfsError::InvalidInput)
    );
}