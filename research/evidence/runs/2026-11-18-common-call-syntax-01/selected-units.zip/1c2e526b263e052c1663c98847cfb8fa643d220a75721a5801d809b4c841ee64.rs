fn stampede_once() {
    static O: Once = Once::new();
    static RUN: AtomicBool = AtomicBool::new(false);

    let (tx, rx) = channel();
    let mut ts = Vec::new();
    for _ in 0..10 {
        let tx = tx.clone();
        ts.push(thread::spawn(move || {
            for _ in 0..4 {
                thread::yield_now()
            }
            O.call_once(|| {
                assert!(!RUN.load(Ordering::Acquire));
                RUN.store(true, Ordering::Release);
            });
            assert!(RUN.load(Ordering::Acquire));
            tx.send(()).unwrap();
        }));
    }

    O.call_once(|| {
        assert!(!RUN.load(Ordering::Acquire));
        RUN.store(true, Ordering::Release);
    });
    assert!(RUN.load(Ordering::Acquire));

    for _ in 0..10 {
        rx.recv().unwrap();
    }

    for t in ts {
        t.join().unwrap();
    }
}