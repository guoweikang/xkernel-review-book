fn registry_lookup_defers_final_superblock_drop_until_after_unlock() {
    let backend = Arc::new(OpenLifecycleDevice {
        modes: crate::Mutex::new(alloc::vec::Vec::new()),
        releases: AtomicUsize::new(0),
        fail_open: core::sync::atomic::AtomicBool::new(false),
    });
    let device = block::Gendisk::alloc(
        String::from("lookup-drop"),
        0,
        0,
        1,
        Box::new(backend.clone()),
    )
    .unwrap()
    .part0();
    let registry = super_block_registry();
    let sb = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::empty(),
            |sb| initialize_test_bdev(sb, &BDEV_TEST_SUPER_OPERATIONS),
        )
        .unwrap();
    let mut live_refs = alloc::vec::Vec::new();
    let mut entries = registry.super_blocks.lock();
    assert!(
        entries
            .lookup_bdev(&BDEV_ALT_FILE_SYSTEM_TYPE, &device, &mut live_refs)
            .is_none()
    );
    drop(sb);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 0);
    drop(entries);
    drop(live_refs);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 1);
}