fn lookup_bdev(
        &mut self,
        file_system_type: &'static FileSystemType,
        block_device: &Arc<block::BlockDevice>,
        live_refs: &mut Vec<Arc<SuperBlock>>,
    ) -> Option<Arc<SuperBlock>> {
        let mut matching = None;
        self.super_blocks
            .retain(|registered| match registered.upgrade() {
                Some(super_block) => {
                    if matching.is_none()
                        && core::ptr::eq(super_block.file_system_type(), file_system_type)
                        && super_block.block_device().is_some_and(|registered_device| {
                            Arc::ptr_eq(registered_device, block_device)
                        })
                    {
                        matching = Some(super_block.clone());
                    }
                    // A temporary Weak upgrade can become the final owner.
                    // Defer its drop so driver release cannot reenter this lock.
                    live_refs.push(super_block);
                    true
                }
                None => false,
            });
        matching
    }