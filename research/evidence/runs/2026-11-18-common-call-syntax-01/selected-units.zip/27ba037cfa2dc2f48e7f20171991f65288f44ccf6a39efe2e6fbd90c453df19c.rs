fn component_under_regular_file_is_not_a_directory() {
    let tree = test_tree();

    // Linux runs `d_can_lookup` (ENOTDIR) before `may_lookup` (EACCES), so a
    // last component under a regular file reports ENOTDIR for every mode.
    let err = Filename::new("/target/leaf")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::follow(),
            &kcred::initial_cred(),
        )
        .unwrap_err();
    assert_eq!(err, VfsError::NotADirectory);
}