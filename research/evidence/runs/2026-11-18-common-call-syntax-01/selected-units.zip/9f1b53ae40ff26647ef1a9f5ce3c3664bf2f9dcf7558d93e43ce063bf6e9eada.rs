fn simple_getattr(
    _idmap: &MountIdmap,
    path: Option<&Path>,
    _request_mask: GetattrRequestMask,
    _query_flags: GetattrQueryFlags,
) -> VfsResult<Metadata> {
    let path = path.ok_or(VfsError::InvalidInput)?;
    let inode = path.inode();
    let mut stat = inode.metadata();
    stat.blocks = inode
        .address_space()
        .nrpages()
        .saturating_mul((PAGE_SIZE_4K >> 9) as u64);
    Ok(stat)
}