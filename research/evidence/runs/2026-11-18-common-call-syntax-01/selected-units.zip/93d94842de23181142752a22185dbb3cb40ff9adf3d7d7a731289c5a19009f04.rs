fn alloc_clone_with_private_data<T>(
        &self,
        flags: FMode,
        open_flags: OpenFlags,
        f_op: Arc<dyn FileOperations>,
        private_data: Arc<T>,
    ) -> VfsResult<Arc<Self>>
    where
        T: Any + Send + Sync + 'static,
    {
        let mut file = VfsFileBuilder::cloned_from(self, flags, open_flags, f_op);
        file.set_private_data(private_data);
        file.mark_opened()?;
        file.finish()
    }