fn register(
        &self,
        context: &mut PollContext<'_>,
        _: IoEvents,
    ) -> Result<(), PollRegisterError> {
        context.register(&self.events)?;
        if self.publish_on_register.replace(false) {
            self.value.set(11);
        }
        Ok(())
    }