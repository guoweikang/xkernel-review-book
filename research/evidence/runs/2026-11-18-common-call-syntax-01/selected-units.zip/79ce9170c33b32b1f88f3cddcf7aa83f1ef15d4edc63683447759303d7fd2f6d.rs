fn drm_ioctl(args: TokenStream, input: TokenStream) -> TokenStream {
    let mut impl_block = parse_macro_input!(input as ItemImpl);
    let args = parse_macro_input!(args as DrmIoctlArgs);

    // Extract the struct name from `impl DrmIoctl for T`.
    // self_ty is the type after `for`, e.g. `DrmVersion`.
    let struct_name = if let syn::Type::Path(type_path) = &*impl_block.self_ty {
        #[expect(
            clippy::unwrap_used,
            reason = "CG-021-no-panic-on-reachable-failure: syn parses a Type::Path with at least \
                      one path segment"
        )]
        &type_path.path.segments.last().unwrap().ident
    } else {
        return Error::new_spanned(&impl_block.self_ty, "expected a path type")
            .to_compile_error()
            .into();
    };

    // Build the CMD expression.
    let cmd_expr = match args {
        DrmIoctlArgs::Formula { dir, nr } => {
            quote! { #dir::<#struct_name>(DRM_TYPE, #nr) }
        }
        DrmIoctlArgs::Raw { cmd } => {
            quote! { #cmd }
        }
    };

    // Inject `const CMD` at the beginning of the impl block.
    let const_cmd: syn::ImplItem = syn::parse_quote! {
        const CMD: u32 = #cmd_expr;
    };
    impl_block.items.insert(0, const_cmd);

    let expanded = quote! { #impl_block };
    TokenStream::from(expanded)
}