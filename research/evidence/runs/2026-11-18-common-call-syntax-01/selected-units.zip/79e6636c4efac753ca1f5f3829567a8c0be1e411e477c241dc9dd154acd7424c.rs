fn observe_readahead_run(mapping: &AddressSpace, run: &core::ops::Range<u64>) {
    let Some(inode) = mapping.inode() else { return };
    let Ok(_) = inode.private::<ReadaheadConflict>() else {
        return;
    };
    if run.start == 4 {
        assert_eq!(run, &(4..8));
        // Model a competing publisher after the missing-run hint was sampled.
        // A resident first hinted page is the regression this observer reports.
        mapping
            .i_pages
            .filemap_add_folio(super::folio_from_bytes(
                run.start,
                &vec![0x44; PAGE_SIZE_4K],
            ))
            .unwrap_or_else(|_| panic!("first hinted page must still be absent"));
    } else {
        assert_eq!(run, &(5..8));
    }
}