fn new_snapshot(fs: Arc<SimpleFs>, ops: impl SimpleFileOps) -> Arc<Self> {
        let ops: Arc<dyn SimpleFileOps> = Arc::new(ops);
        Self::new_with_options(
            fs,
            NodeType::RegularFile,
            NodePermission::default(),
            ops.clone(),
            Arc::new(SnapshotFileOperations(ops)),
        )
    }