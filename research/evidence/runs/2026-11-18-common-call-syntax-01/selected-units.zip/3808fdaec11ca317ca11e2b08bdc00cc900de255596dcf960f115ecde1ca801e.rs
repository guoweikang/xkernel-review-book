fn trusted_and_sticky_user_namespaces_require_privilege_or_owner() {
    let root = Cred::new(0, 0);
    let other = Cred::new(2000, 2000);
    let trusted = XattrName::new(b"trusted.test".to_vec()).unwrap();
    let regular = inode(NodeType::RegularFile, 0o666, 1000);
    assert_eq!(
        check_xattr_permission(&regular, &trusted, XattrAccess::Write, &root),
        Ok(())
    );
    assert!(matches!(
        check_xattr_permission(&regular, &trusted, XattrAccess::Read, &other),
        Err(err) if LinuxError::from(err) == LinuxError::ENODATA
    ));

    let user = XattrName::new(b"user.test".to_vec()).unwrap();
    let sticky = inode(NodeType::Directory, 0o1777, 1000);
    assert!(matches!(
        check_xattr_permission(&sticky, &user, XattrAccess::Write, &other),
        Err(err) if LinuxError::from(err) == LinuxError::EPERM
    ));
}