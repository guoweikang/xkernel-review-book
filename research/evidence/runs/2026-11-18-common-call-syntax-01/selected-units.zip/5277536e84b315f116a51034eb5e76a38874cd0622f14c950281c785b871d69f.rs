fn device_access_for_mode(file: &VfsFileBuilder) -> DeviceAccess {
    let mut access = DeviceAccess::empty();
    if file.mode().contains(FMode::READ) {
        access |= DeviceAccess::READ;
    }
    if file.mode().contains(FMode::WRITE) {
        access |= DeviceAccess::WRITE;
    }
    access
}