fn with_locked_child<R>(
        &self,
        name: &str,
        operation_fn: impl FnOnce(&Dentry) -> VfsResult<R>,
    ) -> VfsResult<R> {
        self.as_dir()?;
        Self::verify_child_name(name)?;
        let dir_inode = self.vfs_inode();
        let _namespace_guard = dir_inode.lock_namespace_exclusive();
        let candidate = self.lookup_locked(&dir_inode, name)?;
        operation_fn(&candidate)
    }