fn test_relatime_future_atime_skips_touch_atime() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let root = Mount::new_root_with_flags(&fs, MountFlags::RELATIME).root_path();

    let accessed_at = SystemTime::from_unix_parts(4_102_444_800, 0).unwrap();
    let inode = root.inode();
    inode.set_accessed_at(accessed_at);
    inode.set_modified_at(SystemTime::from_unix_seconds(1));
    inode.set_changed_at(SystemTime::from_unix_seconds(1));

    root.touch_atime();

    let times = inode.times();
    assert_eq!(times.accessed_at, accessed_at);
    assert_eq!(times.modified_at, SystemTime::from_unix_seconds(1));
    assert_eq!(times.changed_at, SystemTime::from_unix_seconds(1));
}