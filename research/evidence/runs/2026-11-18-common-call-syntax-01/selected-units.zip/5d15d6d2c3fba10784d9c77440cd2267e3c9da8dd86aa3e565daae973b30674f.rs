fn may_mknod_assigns_linux_errors_to_decoded_types() {
    assert_eq!(
        may_mknod(Umode::from_bits(0o600)),
        Ok(NodeType::RegularFile)
    );
    assert_eq!(
        may_mknod(Umode::from_bits(0o040700)),
        Err(VfsError::OperationNotPermitted)
    );
    assert_eq!(
        may_mknod(Umode::from_bits(0o120777)),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(
        may_mknod(Umode::from_bits(0o030600)),
        Err(VfsError::InvalidInput)
    );
}