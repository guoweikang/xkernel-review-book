fn truncate_shrink_then_regrow_does_not_reveal_discarded_cache() {
    let old_len = (PAGE_SIZE_4K * 2) as u64;
    let inode = VfsInode::new_file_with_address_space_and_flags(
        Arc::new(TruncateOps),
        NodeFlags::ALWAYS_CACHE,
        &TRUNCATE_OPERATIONS,
        VfsInodeInit::new(
            2,
            old_len,
            Umode::new(NodeType::RegularFile, NodePermission::default()),
        ),
    );
    let address_space = inode.address_space();
    let stale = vec![0x5a; PAGE_SIZE_4K];
    address_space
        .i_pages
        .filemap_add_folio(super::folio_from_bytes(0, &stale))
        .unwrap_or_else(|_| panic!("fixture index is absent"));
    address_space
        .i_pages
        .filemap_add_folio(super::folio_from_bytes(1, &stale))
        .unwrap_or_else(|_| panic!("fixture index is absent"));

    inode.set_len(0).expect("shrink succeeds");
    assert_eq!(inode.size(), 0);
    assert_eq!(address_space.nrpages(), 0);

    inode.set_len(old_len).expect("regrow succeeds");
    assert_eq!(inode.size(), old_len);
    assert_eq!(address_space.nrpages(), 0);
    address_space
        .with_folio_or_create(0, |folio| {
            assert!(folio.data().iter().all(|byte| *byte == 0));
            Ok(())
        })
        .expect("read regrown sparse page");
}