fn truncate_publishes_i_size_before_two_mapping_invalidations() {
    let inode = VfsInode::new_file_with_address_space_and_flags(
        Arc::new(TruncateOps),
        NodeFlags::ALWAYS_CACHE,
        &TRUNCATE_OPERATIONS,
        VfsInodeInit::new(
            1,
            (PAGE_SIZE_4K * 2) as u64,
            Umode::new(NodeType::RegularFile, NodePermission::default()),
        ),
    );
    let address_space = inode.address_space();
    address_space
        .i_pages
        .filemap_add_folio(super::folio_from_bytes(1, b"cached tail"))
        .unwrap_or_else(|_| panic!("fixture index is absent"));
    let notifier = Arc::new(RecordingNotifier {
        address_space: Arc::downgrade(&address_space),
        observed_sizes: Mutex::new(Vec::new()),
    });
    let _view = address_space.register_view(MappingViewSpec {
        mm_id: 1,
        vma_start: 0x4000,
        vma_len: PAGE_SIZE_4K * 2,
        object_start: 0,
        object_len: PAGE_SIZE_4K * 2,
        kind: MappingViewKind::Private,
        notifier: Some(notifier.clone()),
    });

    inode.set_len(0).expect("truncate succeeds");

    assert_eq!(inode.size(), 0);
    assert_eq!(address_space.nrpages(), 0);
    assert_eq!(*notifier.observed_sizes.lock(), [0, 0]);
}