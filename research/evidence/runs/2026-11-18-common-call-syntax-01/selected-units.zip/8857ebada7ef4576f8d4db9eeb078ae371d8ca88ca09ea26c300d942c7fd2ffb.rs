fn check_device_access(&self, device: DeviceId, access: DeviceAccess) -> VfsResult<()> {
        self.consulted
            .lock()
            .push((device.major(), device.minor(), access.bits()));
        if device.major() == 1 && device.minor() == 3 {
            Err(VfsError::OperationNotPermitted)
        } else {
            Ok(())
        }
    }