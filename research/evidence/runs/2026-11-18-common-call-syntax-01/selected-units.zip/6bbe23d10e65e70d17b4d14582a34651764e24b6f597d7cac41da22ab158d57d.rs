fn visit_resident_folios(
        &self,
        start: PageIndex,
        count: usize,
        visit: impl FnMut(PageIndex, Option<&mut FolioGuard<'_>>) -> KResult<ControlFlow<()>>,
    ) -> KResult<usize> {
        let _invalidate = self.invalidate_lock.read();
        self.i_pages.visit_resident_folios(
            start,
            count,
            |folio| self.ops.read_folio(self, folio),
            visit,
        )
    }