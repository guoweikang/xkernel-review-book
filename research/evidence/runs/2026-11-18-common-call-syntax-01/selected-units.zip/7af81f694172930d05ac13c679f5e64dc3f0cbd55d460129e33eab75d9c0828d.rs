fn test_rename_noreplace_rejects_existing_target_before_filesystem_callback() {
    let fs = Arc::new(MockFilesystem);
    let root = make_renamable_dir_entry(35, None, "");
    let (source, _) = make_file_entry(fs.clone(), 36, Some(root.clone()), "tmp");
    let (target, _) = make_file_entry(fs, 37, Some(root.clone()), "final");

    root.insert_cache(String::from("tmp"), source.clone());
    root.insert_cache(String::from("final"), target.clone());

    assert_eq!(
        root.rename("tmp", &root, "final", RenameFlags::NOREPLACE),
        Err(VfsError::AlreadyExists)
    );
    assert!(root.lookup_cache("tmp").unwrap().ptr_eq(&source));
    assert!(root.lookup_cache("final").unwrap().ptr_eq(&target));
}