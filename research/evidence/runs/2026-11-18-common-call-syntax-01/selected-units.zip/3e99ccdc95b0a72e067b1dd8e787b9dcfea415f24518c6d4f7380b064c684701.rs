fn readahead_pages(&self) -> usize {
        if self.node_type() == NodeType::BlockDevice {
            return block::lookup_block_device(self.rdev())
                .map_or(block::BackingDevInfo::DEFAULT_RA_PAGES, |device| {
                    device.disk().backing_dev_info().readahead_pages()
                });
        }
        self.super_block()
            .ok()
            .and_then(|sb| {
                sb.block_device()
                    .map(|device| device.disk().backing_dev_info().readahead_pages())
            })
            .unwrap_or(block::BackingDevInfo::DEFAULT_RA_PAGES)
    }