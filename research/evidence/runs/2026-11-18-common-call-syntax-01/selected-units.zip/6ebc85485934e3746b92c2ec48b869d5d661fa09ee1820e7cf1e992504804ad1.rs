fn from_open_flags(flags: OpenFlags) -> Self {
        let mut kiocb_flags = Self::empty();
        kiocb_flags.set(Self::DIRECT, flags.contains(OpenFlags::DIRECT));
        kiocb_flags.set(Self::DSYNC, flags.contains(OpenFlags::DSYNC));
        kiocb_flags.set(Self::SYNC, flags.contains(OpenFlags::SYNC));
        kiocb_flags
    }