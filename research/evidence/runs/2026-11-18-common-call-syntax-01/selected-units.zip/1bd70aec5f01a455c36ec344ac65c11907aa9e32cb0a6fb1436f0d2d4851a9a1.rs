fn fill_next_extent(
        &mut self,
        logical: u64,
        physical: u64,
        length: u64,
        mut flags: FiemapExtentFlags,
    ) -> VfsResult<bool> {
        if length == 0
            || logical.checked_add(length).is_none()
            || physical.checked_add(length).is_none()
        {
            return Err(VfsError::InvalidInput);
        }
        if flags.contains(FiemapExtentFlags::DELALLOC) {
            flags.insert(FiemapExtentFlags::UNKNOWN);
        }
        if flags.contains(FiemapExtentFlags::DATA_ENCRYPTED) {
            flags.insert(FiemapExtentFlags::ENCODED);
        }
        if flags.intersects(FiemapExtentFlags::DATA_INLINE | FiemapExtentFlags::DATA_TAIL) {
            flags.insert(FiemapExtentFlags::NOT_ALIGNED);
        }

        if self.extents_max == 0 {
            self.extents_mapped = self
                .extents_mapped
                .checked_add(1)
                .ok_or(VfsError::OutOfRange)?;
            return Ok(!flags.contains(FiemapExtentFlags::LAST));
        }
        if self.extents_mapped >= self.extents_max {
            return Ok(false);
        }

        self.writer
            .write_extent(self.extents_mapped, logical, physical, length, flags)?;
        self.extents_mapped = self
            .extents_mapped
            .checked_add(1)
            .ok_or(VfsError::OutOfRange)?;
        Ok(self.extents_mapped < self.extents_max && !flags.contains(FiemapExtentFlags::LAST))
    }