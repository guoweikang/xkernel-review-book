fn truncate_pagecache(&self, old_len: u64, len: u64) -> VfsResult<()> {
        let invalid_start = (len < old_len).then(|| {
            len.div_ceil(PAGE_SIZE_4K as u64)
                .saturating_mul(PAGE_SIZE_4K as u64)
        });
        if let Some(start) = invalid_start {
            self.invalidate_mappings_from(start);
        }
        self.i_pages.resize_cached_folios(old_len, len)?;
        if let Some(start) = invalid_start {
            self.invalidate_mappings_from(start);
        }
        Ok(())
    }