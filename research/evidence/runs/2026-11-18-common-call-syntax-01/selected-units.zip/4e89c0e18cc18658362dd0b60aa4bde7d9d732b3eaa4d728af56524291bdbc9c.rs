fn inode_time_updates_use_superblock_timestamp_limits() {
    let super_block = second_resolution_super_block();
    let node = Arc::new(TestChrdevInode::new(DeviceId::new(1, 3)));
    let inode = super_block.get_or_init_inode(42, || {
        VfsInode::new_with_inode_attribute_operations(
            node.clone(),
            NodeFlags::NON_CACHEABLE,
            empty_address_space_operations(),
            VfsInodeInit::new(
                42,
                0,
                Umode::new(
                    NodeType::CharacterDevice,
                    NodePermission::from_bits_truncate(0o666),
                ),
            )
            .with_owner_links_and_rdev(0, 0, 1, DeviceId::new(1, 3)),
        )
    });
    let dentry = Dentry::new_file_from_inode(inode.clone(), None, String::from("timestamp"));

    dentry
        .update_metadata(MetadataUpdate {
            atime: Some(SystemTime::from_unix_parts(11, 111).unwrap()),
            mtime: Some(SystemTime::from_unix_parts(12, 222).unwrap()),
            ctime: Some(SystemTime::from_unix_parts(13, 333).unwrap()),
            ..Default::default()
        })
        .unwrap();

    let callback_update = node.last_update.lock().clone().unwrap();
    assert_eq!(
        callback_update.atime,
        Some(SystemTime::from_unix_seconds(11))
    );
    assert_eq!(
        callback_update.mtime,
        Some(SystemTime::from_unix_seconds(12))
    );
    assert_eq!(
        callback_update.ctime,
        Some(SystemTime::from_unix_seconds(13))
    );
    assert_eq!(inode.metadata().atime, SystemTime::from_unix_seconds(11));
    assert_eq!(inode.metadata().mtime, SystemTime::from_unix_seconds(12));
    assert_eq!(inode.metadata().ctime, SystemTime::from_unix_seconds(13));

    inode
        .update_time(
            &dentry,
            inode.truncate_timestamp(SystemTime::from_unix_parts(14, 444).unwrap()),
            InodeUpdateTime::ChangeAndModification,
        )
        .unwrap();
    let callback_update = node.last_update.lock().clone().unwrap();
    assert_eq!(
        callback_update.mtime,
        Some(SystemTime::from_unix_seconds(14))
    );
    assert_eq!(
        callback_update.ctime,
        Some(SystemTime::from_unix_seconds(14))
    );
    assert_eq!(inode.metadata().mtime, SystemTime::from_unix_seconds(14));
    assert_eq!(inode.metadata().ctime, SystemTime::from_unix_seconds(14));

    assert_eq!(
        inode.truncate_timestamp(SystemTime::from_unix_parts(15, 555).unwrap()),
        SystemTime::from_unix_seconds(15)
    );
    assert_eq!(inode.current_time().subsec_nanos(), 0);
    assert_eq!(
        inode.set_accessed_at(SystemTime::from_unix_parts(15, 555).unwrap()),
        SystemTime::from_unix_parts(15, 555).unwrap()
    );
    assert_eq!(
        inode.metadata().atime,
        SystemTime::from_unix_parts(15, 555).unwrap()
    );
}