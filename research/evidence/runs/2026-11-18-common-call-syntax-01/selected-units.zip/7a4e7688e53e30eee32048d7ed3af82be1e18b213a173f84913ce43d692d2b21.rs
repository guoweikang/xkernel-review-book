fn release_fifo_pipe(&self, pipe: &Arc<PipeObject>) {
        let mut fifo_pipe = self.special_state.fifo_pipe.lock();
        assert!(
            fifo_pipe
                .as_ref()
                .is_some_and(|active| Arc::ptr_eq(active, pipe)),
            "released FIFO pipe is not attached to its inode"
        );
        if pipe.release_file() {
            *fifo_pipe = None;
        }
    }