fn test_parallel_lookup_candidate_does_not_escape_cache_snapshot() {
    let fs = Arc::new(MockFilesystem);
    let (dir, _) = make_non_cacheable_dir(fs, 2, None, "dir");
    let candidate = Dentry::new_negative(Some(dir.clone()), String::from("ptmx"));
    candidate.begin_parallel_lookup();
    assert!(dir.cache_lookup_candidate("ptmx", &candidate).is_none());

    let observed = dir.lookup_cache_entry("ptmx");
    dir.uncache_lookup_candidate("ptmx", &candidate);
    candidate.end_parallel_lookup();

    assert!(observed.is_none());
    assert!(dir.lookup_cache_entry("ptmx").is_none());
}