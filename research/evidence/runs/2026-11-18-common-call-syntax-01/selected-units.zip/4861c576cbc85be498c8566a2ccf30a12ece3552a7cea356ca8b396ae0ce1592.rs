fn retarget_path(path: &Path, mount_map: &HashMap<usize, Arc<Mount>>) -> VfsResult<Path> {
    let key = Arc::as_ptr(path.mount()) as usize;
    let mount = mount_map.get(&key).ok_or(VfsError::InvalidInput)?;
    Ok(Path::new(mount.clone(), path.dentry.clone()))
}