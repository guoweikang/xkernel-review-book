fn test_child_mount_flags_are_independent_from_parent() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::empty());
    let root_mount = Mount::new_root_with_flags(&root_fs, MountFlags::RDONLY);
    let mount_dir = lookup_no_follow(&root_mount.root_path(), "mnt").unwrap();
    let child_mount = mount_dir
        .mount_filesystem_with_requested_superblock_flags(
            &child_fs,
            MountFlags::empty(),
            None,
            None,
        )
        .unwrap();
    let child_root = child_mount.root_path();

    assert!(root_mount.is_readonly());
    assert!(!child_mount.is_readonly());
    assert!(!child_root.is_mount_readonly());
    assert!(!child_root.is_effectively_readonly());
}