fn lookup_fast(&self, name: &str) -> Option<VfsResult<Path>> {
        self.path.dentry().lookup_cache(name).map(|dentry| {
            if d_is_negative(&dentry) {
                Err(VfsError::NotFound)
            } else {
                Ok(Path::new(self.path.mount().clone(), dentry))
            }
        })
    }