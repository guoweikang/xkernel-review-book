fn dir_entry(inode: u64, parent: &Dentry, name: &str) -> (Dentry, Arc<TestDir>) {
    let ops = Arc::new(TestDir::new(inode));
    let inode = VfsInode::new_openable_dir(ops.clone(), inode_init(inode, NodeType::Directory, 0));
    let entry = Dentry::new_dir_from_inode(inode, Some(parent.clone()), String::from(name));
    (entry, ops)
}