fn test_dentry_backing_metadata_refresh_validates_entry_state() {
    let fs = Arc::new(MockFilesystem);
    let (entry, _) = make_file_entry(fs, 2, None, "leaf");
    let mut updated = entry.metadata();
    updated.nlink = 2;
    updated.size = 11;

    entry
        .update_metadata_after_backing_change(&updated)
        .unwrap();
    assert_eq!(entry.metadata().nlink, 2);
    assert_eq!(entry.metadata().size, 11);

    updated.inode = 3;
    assert_eq!(
        entry.update_metadata_after_backing_change(&updated),
        Err(VfsError::InvalidInput)
    );

    let negative = Dentry::new_negative(None, String::from("missing"));
    assert_eq!(
        negative.update_metadata_after_backing_change(&updated),
        Err(VfsError::NotFound)
    );
}