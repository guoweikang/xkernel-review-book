fn buffered_read_rechecks_eof_between_folios() {
    let inode = read_inode(&READ_OPS, PAGE_SIZE_4K * 3);
    let mapping = inode.address_space();
    let mut sink = InvalidatingSink {
        mapping: &mapping,
        output: Vec::new(),
        truncate: true,
    };
    assert_eq!(
        mapping.read_from_page_cache(&mut iov_iter_dest(&mut sink), 0),
        Ok(PAGE_SIZE_4K)
    );
    assert_eq!(sink.output.len(), PAGE_SIZE_4K);
    assert_eq!(mapping.nrpages(), 1);
}