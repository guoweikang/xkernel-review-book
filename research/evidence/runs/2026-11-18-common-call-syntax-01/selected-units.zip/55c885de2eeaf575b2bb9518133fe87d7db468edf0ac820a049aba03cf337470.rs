fn get(&self, device: DeviceId) -> Option<Arc<ChrdevEntry>> {
        let (_, entry) = self
            .entries
            .range(..=(device.major(), device.minor()))
            .next_back()?;
        (entry.first.major() == device.major() && device.minor() <= entry.last_minor)
            .then(|| entry.clone())
    }