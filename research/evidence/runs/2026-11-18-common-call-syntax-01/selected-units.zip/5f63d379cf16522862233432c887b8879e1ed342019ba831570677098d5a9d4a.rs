fn key(&self) -> DentryKey {
        let location = self.0.location.read();
        let parent = location
            .parent
            .as_ref()
            .map(|parent| Arc::downgrade(&parent.0));
        DentryKey::new(parent, location.name.clone())
    }