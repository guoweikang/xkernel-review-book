fn setattr(
        &self,
        _idmap: &MountIdmap,
        _dentry: &Dentry,
        update: MetadataUpdate,
    ) -> VfsResult<MetadataUpdate> {
        *self.last_update.lock() = Some(update.clone());
        Ok(self.next_applied_update.lock().take().unwrap_or(update))
    }