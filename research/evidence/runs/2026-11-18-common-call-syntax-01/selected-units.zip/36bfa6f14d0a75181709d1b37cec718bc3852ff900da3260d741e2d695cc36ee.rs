fn prepare_create_mode(
        &self,
        mode: Umode,
        umask: NodePermission,
        allowed_permission: NodePermission,
        node_type: NodeType,
        cred: &Cred,
    ) -> Umode {
        let (parent_permission, parent_gid) = self.attributes.creation_mode_context();
        let mut permission = mode.permission();
        // Linux `mode_strip_sgid()` reaches the credential check only for a
        // non-directory SGID+group-executable mode below an SGID directory.
        let should_strip_set_gid = mode.node_type() != NodeType::Directory
            && permission.contains(NodePermission::SET_GID | NodePermission::GROUP_EXEC)
            && parent_permission.contains(NodePermission::SET_GID)
            && !cred.in_group(parent_gid)
            && !cred.has_cap(kcred::CAP_FSETID);
        if should_strip_set_gid {
            permission.remove(NodePermission::SET_GID);
        }
        permission.remove(umask);
        permission &= allowed_permission;
        Umode::new(node_type, permission)
    }