fn cdev_removal_preserves_open_files_but_not_inode_backend_ownership() {
    let first = DeviceId::new(242, 20);
    let backend = CharacterBackend::new(true, true, false);
    let weak = Arc::downgrade(&backend);
    let registration = TestRegistration::new(first, 2, backend.clone());
    let inode = test_character_inode(DeviceId::new(242, 21));
    let mount = crate::Mount::new_root(&crate::nullfs::new_superblock());
    let dentry = crate::Dentry::new_file_from_inode(inode.clone(), None, String::from("range"));
    let path = crate::Path::new(mount, dentry);
    let file = VfsFileBuilder::allocate(crate::OpenFlags::READ_WRITE, kcred::initial_cred())
        .unwrap()
        .vfs_open(path.clone())
        .unwrap();
    assert_eq!(backend.opens.load(Ordering::Relaxed), 1);
    drop(registration);
    assert!(character_operations(&inode).is_none());
    assert_eq!(
        VfsFileBuilder::allocate(crate::OpenFlags::READ_WRITE, kcred::initial_cred())
            .unwrap()
            .vfs_open(path)
            .err(),
        Some(VfsError::from(LinuxError::ENXIO))
    );
    backend.is_ready.store(true, Ordering::Relaxed);
    assert!(file.poll().contains(IoEvents::IN));
    drop(file);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 1);
    drop(backend);
    assert!(weak.upgrade().is_none());
    // A live inode does not retain either a retired backend or its strong entry.
    assert!(inode.character_device().is_none());
}