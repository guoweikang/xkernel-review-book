fn mount_opens_once_and_closes_at_failure_or_logical_shutdown() {
    let backend = Arc::new(OpenLifecycleDevice {
        modes: crate::Mutex::new(alloc::vec::Vec::new()),
        releases: AtomicUsize::new(0),
        fail_open: core::sync::atomic::AtomicBool::new(true),
    });
    let device = block::Gendisk::alloc(
        String::from("mount-open"),
        0,
        0,
        1,
        Box::new(backend.clone()),
    )
    .unwrap()
    .part0();
    let registry = super_block_registry();
    let mut did_fill = false;
    assert!(matches!(
        registry.get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::empty(),
            |_| {
                did_fill = true;
                Ok(())
            }
        ),
        Err(VfsError::Io)
    ));
    assert!(!did_fill);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 0);
    backend.fail_open.store(false, Ordering::Relaxed);
    assert!(matches!(
        registry.get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::empty(),
            |_| Err(VfsError::InvalidInput)
        ),
        Err(VfsError::InvalidInput)
    ));
    assert_eq!(backend.releases.load(Ordering::Relaxed), 1);
    let sb = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::empty(),
            |sb| initialize_test_bdev(sb, &BDEV_TEST_SUPER_OPERATIONS),
        )
        .unwrap();
    sb.activate_mount();
    let shared = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::empty(),
            |_| panic!("shared mount must not fill again"),
        )
        .unwrap();
    assert!(Arc::ptr_eq(&sb, &shared));
    shared.activate_mount();
    assert_eq!(backend.modes.lock().len(), 3);
    sb.deactivate_mount();
    assert_eq!(backend.releases.load(Ordering::Relaxed), 1);
    shared.deactivate_mount();
    assert_eq!(backend.releases.load(Ordering::Relaxed), 2);
    let readonly = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device.clone(),
            SuperBlockFlags::RDONLY,
            |sb| initialize_test_bdev(sb, &BDEV_TEST_SUPER_OPERATIONS),
        )
        .unwrap();
    readonly.activate_mount();
    let read_mode = block::BlockOpenMode::READ | block::BlockOpenMode::EXCLUSIVE;
    let write_mode = read_mode | block::BlockOpenMode::WRITE;
    {
        let modes = backend.modes.lock();
        assert_eq!(
            modes.as_slice(),
            &[write_mode, write_mode, write_mode, read_mode]
        );
    }
    readonly.deactivate_mount();
    drop((sb, shared, readonly));
    assert_eq!(backend.releases.load(Ordering::Relaxed), 3);

    device.set_disk_read_only(true).unwrap();
    did_fill = false;
    assert!(matches!(
        registry.get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            device,
            SuperBlockFlags::empty(),
            |_| {
                did_fill = true;
                Ok(())
            }
        ),
        Err(VfsError::PermissionDenied)
    ));
    assert!(!did_fill);
    assert_eq!(backend.releases.load(Ordering::Relaxed), 4);
}