fn from_parts_with_attribute_operations(
        parts: InodeParts,
        operations: Arc<dyn InodeAttributeOperations>,
    ) -> Arc<Self> {
        let metadata = operations.fill_metadata(parts.init.number, 1_u64 << parts.init.block_bits);
        assert_eq!(
            metadata.inode, parts.init.number,
            "inode attribute operations must describe the constructed inode"
        );
        assert_eq!(
            metadata.mode.node_type(),
            parts.init.node_type(),
            "inode attribute operations must preserve the constructed inode type"
        );
        let attributes =
            InodeAttributes::from_operations(operations, parts.flags, parts.init.block_bits);
        Self::from_parts_with_attributes(parts, attributes)
    }