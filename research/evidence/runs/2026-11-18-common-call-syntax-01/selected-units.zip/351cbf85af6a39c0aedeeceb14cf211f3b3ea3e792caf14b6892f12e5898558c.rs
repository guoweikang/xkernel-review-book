fn test_pivot_root_rejects_mounted_put_old() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let new_root_fs = mock_filesystem(StatFsFlags::empty());
    let put_old_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::build_initial_mount_tree(&root_fs).unwrap();
    let visible = namespace.visible_root_path();
    let cred = kcred::initial_cred();
    let new_mnt = namespace
        .attach(
            &visible
                .mkdir("first", NodePermission::default(), &cred)
                .unwrap(),
            &new_root_fs,
        )
        .unwrap();
    let put_old_mountpoint = visible
        .mkdir("second", NodePermission::default(), &cred)
        .unwrap();
    namespace.attach(&put_old_mountpoint, &put_old_fs).unwrap();

    assert_eq!(
        namespace.pivot_root(
            &new_mnt.root_path(),
            &put_old_mountpoint,
            &namespace.visible_root_path()
        ),
        Err(VfsError::ResourceBusy),
        "put_old inside the old root's filesystem is a loop (Linux EBUSY)"
    );
}