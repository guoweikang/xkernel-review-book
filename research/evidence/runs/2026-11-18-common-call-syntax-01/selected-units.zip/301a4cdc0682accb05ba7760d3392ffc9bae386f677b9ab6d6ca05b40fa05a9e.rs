fn inode_with_flags(
    node_type: NodeType,
    permission: u16,
    uid: u32,
    flags: NodeFlags,
) -> Arc<VfsInode> {
    let init = VfsInodeInit::new(
        1,
        0,
        Umode::new(node_type, NodePermission::from_bits_truncate(permission)),
    )
    .with_owner_links_and_rdev(uid, uid, 1, Default::default());
    if node_type == NodeType::Directory {
        VfsInode::new_dir_with_defaults(flags, init)
    } else {
        VfsInode::new_file_with_flags(Arc::new(TestOps), flags, init)
    }
}