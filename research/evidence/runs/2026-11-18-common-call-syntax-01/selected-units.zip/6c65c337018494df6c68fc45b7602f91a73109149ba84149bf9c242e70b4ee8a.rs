fn non_final_magic_link_is_followed_by_namei() {
    let tree = test_tree();

    let leaf = Filename::new("/magicdir/leaf")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Stat,
            LookupFlags::no_follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(leaf.name(), "leaf");
    assert_eq!(tree.magic_dir.last_intent(), Some(LookupIntent::Stat));
}