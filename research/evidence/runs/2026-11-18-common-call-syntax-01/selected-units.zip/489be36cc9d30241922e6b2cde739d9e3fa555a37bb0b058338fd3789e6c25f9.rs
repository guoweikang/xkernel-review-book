fn test_unmount_rejects_non_mount_root_path() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let root_mount = Mount::new_root(&root_fs);
    let mount_dir = lookup_no_follow(&root_mount.root_path(), "mnt").unwrap();

    assert_eq!(mount_dir.unmount(), Err(VfsError::InvalidInput));
    assert_eq!(mount_dir.unmount_tree(), Err(VfsError::InvalidInput));
}