fn instantiate(&self, inode: Arc<VfsInode>) -> VfsResult<()> {
        let mut attached = self.0.inode.lock();
        if attached.is_some() {
            return Err(VfsError::AlreadyExists);
        }
        if !inode.add_dentry_alias(self) {
            return Err(VfsError::InvalidInput);
        }
        let mut flags = self.0.flags.lock();
        let retained =
            *flags & (DentryFlags::PAR_LOOKUP | DentryFlags::DONTCACHE | DentryFlags::PERSISTENT);
        *flags = DentryFlags::for_inode(&inode) | retained;
        drop(flags);
        *attached = Some(inode.clone());
        drop(attached);
        if let Some(super_block) = self.super_block() {
            inode.bind_super_block(&super_block);
        }
        Ok(())
    }