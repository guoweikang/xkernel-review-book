fn inode_init_owner(dir: &VfsInode, mode: Umode, cred: &Cred) -> (Umode, u32, u32) {
    let (parent_permission, parent_gid) = dir.attributes.creation_mode_context();
    let mut permission = mode.permission();
    let gid = if parent_permission.contains(NodePermission::SET_GID) {
        if mode.node_type() == NodeType::Directory {
            permission.insert(NodePermission::SET_GID);
        }
        parent_gid
    } else {
        cred.fsgid()
    };
    (mode.with_permission(permission), cred.fsuid(), gid)
}