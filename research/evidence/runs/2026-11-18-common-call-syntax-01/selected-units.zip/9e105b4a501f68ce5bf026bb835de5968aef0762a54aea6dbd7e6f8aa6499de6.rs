fn collect_subtree(self: &Arc<Self>) -> Vec<Arc<Self>> {
        let mut mounts = vec![self.clone()];
        let mut index = 0;
        while index < mounts.len() {
            let mount = mounts[index].clone();
            for child in mount.children() {
                let mut layer = Some(child);
                while let Some(mount) = layer {
                    layer = mount.covered_mount();
                    mounts.push(mount);
                }
            }
            index += 1;
        }
        mounts
    }