fn inode_init() -> VfsInodeInit {
        VfsInodeInit::new(
            NULLFS_ROOT_INO,
            0,
            Umode::new(
                NodeType::Directory,
                NodePermission::from_bits_truncate(0o555),
            ),
        )
        .with_owner_links_and_rdev(0, 0, 2, Default::default())
        .with_stat_data(
            NULLFS_BLOCK_SIZE,
            0,
            SystemTime::UNIX_EPOCH,
            SystemTime::UNIX_EPOCH,
            SystemTime::UNIX_EPOCH,
        )
    }