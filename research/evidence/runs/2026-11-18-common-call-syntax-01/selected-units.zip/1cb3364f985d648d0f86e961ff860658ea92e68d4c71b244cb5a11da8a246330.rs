fn completed_folio_read_survives_eof_growth() {
    let inode = read_inode(&GROWING_READ_OPS, 17);
    let mapping = inode.address_space();
    let mut output = [0xff; PAGE_SIZE_4K];
    let mut iter = iov_iter_kvec_dest(&mut output);
    assert_eq!(mapping.read_from_page_cache(&mut iter, 0), Ok(PAGE_SIZE_4K));
    assert!(output[..17].iter().all(|byte| *byte == 0x6b));
    assert!(output[17..].iter().all(|byte| *byte == 0));
}