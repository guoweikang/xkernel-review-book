fn do_o_path(
        root: &Path,
        base: &Path,
        filename: &Filename,
        file: VfsFileBuilder,
        flags: &OpenParams,
        cred: &Cred,
    ) -> VfsResult<Arc<VfsFile>> {
        let path =
            filename.lookup_at(root, base, LookupIntent::Open, flags.lookup_flags(), cred)?;
        file.vfs_open(path)
    }