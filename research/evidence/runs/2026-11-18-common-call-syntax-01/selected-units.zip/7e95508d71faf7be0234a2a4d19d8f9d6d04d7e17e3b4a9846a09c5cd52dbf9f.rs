fn fsync_path_only_file_returns_ebadf_without_calling_backend() {
    let operations = Arc::new(SyncOperations {
        intents: Mutex::new(Vec::new()),
    });
    let file = sync_test_file(operations.clone(), FMode::PATH);
    for data_only in [false, true] {
        assert_eq!(file.fsync(data_only), Err(VfsError::BadFileDescriptor));
    }
    assert_eq!(operations.intents.lock().len(), 0);
}