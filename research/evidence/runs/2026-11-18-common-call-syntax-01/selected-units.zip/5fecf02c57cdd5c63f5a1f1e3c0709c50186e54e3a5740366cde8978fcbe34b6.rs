fn test_dentry_key_uniqueness() {
    let fs = Arc::new(MockFilesystem);
    let (entry1, _) = make_file_entry(fs.clone(), 1, None, "file1.txt");
    let (entry2, _) = make_file_entry(fs.clone(), 2, None, "file2.txt");
    let (entry3, _) = make_file_entry(fs, 3, None, "file1.txt");

    assert_ne!(entry1.key(), entry2.key());
    assert_eq!(entry1.key(), entry3.key());
}