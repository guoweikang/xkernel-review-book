fn copy_prefix(&self, dst: &mut [u8]) -> usize {
        let count = dst.len().min(self.buffer.len());
        if count == 0 {
            return 0;
        }

        let (head, tail) = self.buffer.as_slices();
        let head_len = count.min(head.len());
        dst[..head_len].copy_from_slice(&head[..head_len]);
        let tail_len = count - head_len;
        if tail_len != 0 {
            dst[head_len..count].copy_from_slice(&tail[..tail_len]);
        }
        count
    }