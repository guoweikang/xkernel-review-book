fn namespace_lock_key(&self) -> Vec<usize> {
        let mut chain = Vec::new();
        let mut current = Some(self.clone());
        while let Some(dentry) = current {
            chain.push(Arc::as_ptr(&dentry.vfs_inode()) as usize);
            current = dentry.parent();
        }
        chain.reverse();
        chain
    }