fn cdev_callbacks_and_backend_destruction_run_without_registry_lock() {
    struct Backend;
    impl DeviceFileOps for Backend {
        fn open(&self, _: &VfsInode, _: &mut VfsFileBuilder) -> VfsResult<()> {
            assert!(CHRDEV_MAP.try_lock().is_some());
            Err(VfsError::Io)
        }
    }
    impl Drop for Backend {
        fn drop(&mut self) {
            assert!(CHRDEV_MAP.try_lock().is_some());
        }
    }
    let first = DeviceId::new(242, 30);
    let registration = TestRegistration::new(first, 1, Arc::new(Backend));
    assert_eq!(
        cdev_add(first, 1, Arc::new(Backend)),
        Err(VfsError::ResourceBusy)
    );
    assert_eq!(
        cdev_add(first, 0, Arc::new(Backend)),
        Err(VfsError::InvalidInput)
    );
    let inode = test_character_inode(first);
    let mount = crate::Mount::new_root(&crate::nullfs::new_superblock());
    let dentry = crate::Dentry::new_file_from_inode(inode, None, String::from("range"));
    let path = crate::Path::new(mount, dentry);
    assert_eq!(
        VfsFileBuilder::allocate(crate::OpenFlags::READ_WRITE, kcred::initial_cred())
            .unwrap()
            .vfs_open(path)
            .err(),
        Some(VfsError::Io)
    );
    drop(registration);
}