fn new(can_read: bool, can_write: bool, fail_open: bool) -> Arc<Self> {
        Arc::new(Self {
            can_read,
            can_write,
            fail_open,
            is_ready: AtomicBool::new(false),
            reject_registration: AtomicBool::new(false),
            opens: AtomicUsize::new(0),
            releases: AtomicUsize::new(0),
            waiters: PollSet::new(),
        })
    }