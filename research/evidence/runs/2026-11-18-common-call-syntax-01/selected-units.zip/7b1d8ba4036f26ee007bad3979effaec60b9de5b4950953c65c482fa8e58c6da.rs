fn new_with_flags(
        file_system_type: &'static FileSystemType,
        ops: &'static dyn SuperBlockOperations,
        flags: SuperBlockFlags,
        init_root_fn: impl FnOnce(&Arc<Self>) -> Dentry,
    ) -> Arc<Self> {
        match Self::try_new_with_flags(file_system_type, ops, flags, |super_block| {
            Ok::<_, core::convert::Infallible>(init_root_fn(super_block))
        }) {
            Ok(super_block) => super_block,
            Err(error) => match error {},
        }
    }