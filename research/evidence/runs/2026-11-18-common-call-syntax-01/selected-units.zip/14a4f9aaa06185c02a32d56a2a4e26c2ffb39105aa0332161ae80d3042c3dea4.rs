fn failed_prefix_writeback_redirties_and_retry_converges() {
    let operations: &'static PrefixRetryWritebackOps =
        Box::leak(Box::new(PrefixRetryWritebackOps {
            state: Mutex::new(PrefixRetryState {
                fail_once: true,
                calls: 0,
                durable: Vec::new(),
            }),
        }));
    let input = vec![0x6d; PAGE_SIZE_4K * 2];
    let inode = VfsInode::new_file_with_address_space_and_flags(
        Arc::new(TruncateOps),
        NodeFlags::ALWAYS_CACHE,
        operations,
        VfsInodeInit::new(
            3,
            u64::try_from(input.len()).unwrap(),
            Umode::new(NodeType::RegularFile, NodePermission::default()),
        ),
    );
    let address_space = inode.address_space();
    address_space
        .write_cached_bytes(0, &input)
        .expect("populate dirty page-cache batch");

    let mut control = WritebackControl::all(false).with_nr_to_write(2);
    assert_eq!(
        address_space.writepages_control(&mut control),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(control.nr_to_write(), 1);
    for (index, expected_dirty) in [(0, false), (1, true)] {
        let state = address_space
            .i_pages
            .with_folio(index, |folio| {
                let folio = folio.expect("failed batch folio remains cached");
                (folio.is_dirty(), folio.is_under_writeback())
            })
            .unwrap();
        assert_eq!(state, (expected_dirty, false));
    }
    {
        let state = operations.state.lock();
        assert_eq!(state.calls, 1);
        assert_eq!(&state.durable[..PAGE_SIZE_4K], &input[..PAGE_SIZE_4K]);
        assert!(state.durable[PAGE_SIZE_4K..].iter().all(|byte| *byte == 0));
    }

    address_space
        .writepages_control(&mut control)
        .expect("redirtied batch converges on retry");
    assert_eq!(control.nr_to_write(), 0);
    for index in 0..2 {
        let state = address_space
            .i_pages
            .with_folio(index, |folio| {
                let folio = folio.expect("retried batch folio remains cached");
                (folio.is_dirty(), folio.is_under_writeback())
            })
            .unwrap();
        assert_eq!(state, (false, false));
    }
    let state = operations.state.lock();
    assert_eq!(state.calls, 2);
    assert_eq!(state.durable, input);
}