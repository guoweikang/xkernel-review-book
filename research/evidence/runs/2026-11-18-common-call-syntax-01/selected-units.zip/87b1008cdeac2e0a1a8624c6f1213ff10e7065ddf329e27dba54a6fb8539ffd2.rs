fn file_wait_preserves_io_registration_errors() {
    struct InvalidPoll;
    impl Pollable for InvalidPoll {
        fn poll(&self) -> IoEvents {
            IoEvents::empty()
        }

        fn register(&self, _: &mut PollContext<'_>, _: IoEvents) -> Result<(), PollRegisterError> {
            Err(PollRegisterError::InvalidState)
        }
    }
    let _cleanup = InterruptCleanup;
    ktask::current().clear_interrupt();
    let result: KResult<usize> =
        ktask::future::block_on(poll_file_io(&InvalidPoll, IoEvents::IN, false, || {
            Err(KError::WouldBlock)
        }));
    assert_eq!(result, Err(KError::InvalidInput));
}