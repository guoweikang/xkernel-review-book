fn new(record: FileLock) -> Self {
        Self {
            owner: record.owner,
            kind: record.kind,
            pid: record.pid,
            bounds: UnsafeCell::new(record.bounds),
            links: LinkedListLink::new(),
            blocked: UnsafeCell::new(FileLockBlocked {
                blocker: None,
                requests: LinkedList::new(LockAdapter::new()),
                wait: None,
            }),
            waiter_count: AtomicUsize::new(0),
        }
    }