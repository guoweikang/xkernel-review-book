fn open_fifo(&self, access: PipeAccess, nonblocking: bool) -> KResult<u64> {
        let (partner_counter, pipe_generation, wake_readers, wake_writers) = {
            let mut state = self.state.lock();
            if access == PipeAccess::Write && nonblocking && state.readers == 0 {
                return Err(KError::from(LinuxError::ENXIO));
            }

            let partner_counter = match access {
                PipeAccess::Read if !nonblocking && state.writers == 0 => Some(state.w_counter),
                PipeAccess::Write if state.readers == 0 => Some(state.r_counter),
                PipeAccess::Read | PipeAccess::Write | PipeAccess::ReadWrite => None,
            };
            let pipe_generation = if access == PipeAccess::Read && nonblocking && state.writers == 0
            {
                state.w_counter
            } else {
                0
            };
            let (wake_readers, wake_writers) = add_access(&mut state, access)?;
            (partner_counter, pipe_generation, wake_readers, wake_writers)
        };

        self.wake(wake_readers, wake_writers);
        if let Some(partner_counter) = partner_counter {
            let events = if access == PipeAccess::Read {
                IoEvents::IN
            } else {
                IoEvents::OUT
            };
            if let Err(error) = block_on(poll_io(self, events, false, || {
                if self.partner_counter(access) != partner_counter {
                    Ok(())
                } else {
                    Err(KError::WouldBlock)
                }
            })) {
                let (is_satisfied, wake_readers, wake_writers) = {
                    let mut state = self.state.lock();
                    if peer_counter(&state, access) != partner_counter {
                        (true, false, false)
                    } else {
                        let (wake_readers, wake_writers) = remove_access(&mut state, access);
                        (false, wake_readers, wake_writers)
                    }
                };
                if is_satisfied {
                    return Ok(pipe_generation);
                }
                self.wake(wake_readers, wake_writers);
                return Err(error);
            }
        }

        Ok(pipe_generation)
    }