fn special_inodes_preserve_rdev() {
    let node = Arc::new(TestChrdevInode::new(DeviceId::default()));
    let init = VfsInodeInit::new(
        7,
        0,
        Umode::new(
            NodeType::CharacterDevice,
            NodePermission::from_bits_truncate(0o666),
        ),
    )
    .with_owner_links_and_rdev(0, 0, 1, DeviceId::new(1, 3));
    let inode = VfsInode::new_special(node, NodeFlags::NON_CACHEABLE, init);
    assert_eq!(inode.metadata().inode, 7);
    assert_eq!(inode.metadata().rdev, DeviceId::new(1, 3));
    assert_eq!(inode.grow_size_after_backing_write(16), Ok(()));
    assert_eq!(inode.size(), 0);
}