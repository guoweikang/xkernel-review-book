fn mock_filesystem(mount_flags: StatFsFlags) -> Arc<SuperBlock> {
    let inode =
        VfsInode::new_openable_dir(Arc::new(MockDirOps::new(mount_flags, 1)), inode_init(1));
    let root = Dentry::new_dir_from_inode(inode, None, String::new());
    mock_superblock(root, mount_flags)
}