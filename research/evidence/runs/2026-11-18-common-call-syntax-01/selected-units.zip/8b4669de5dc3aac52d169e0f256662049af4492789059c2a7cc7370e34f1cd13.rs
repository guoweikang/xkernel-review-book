fn test_metadata_owner_and_group_authorization() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let root = Mount::new_root(&fs).root_path();
    root.dentry
        .update_metadata(MetadataUpdate {
            mode: Some(NodePermission::from_bits_truncate(0o666)),
            owner: Some((1000, 100)),
            ..Default::default()
        })
        .unwrap();

    let mut owner = Cred::new(1000, 100);
    owner.set_supplementary_groups(vec![200]);
    let other = Cred::new(2000, 300);

    assert_eq!(
        root.chmod(NodePermission::from_bits_truncate(0o600), &other),
        Err(VfsError::OperationNotPermitted)
    );
    assert_eq!(
        root.chown(Some(2000), None, &owner),
        Err(VfsError::OperationNotPermitted)
    );
    assert_eq!(
        root.chown(None, Some(300), &owner),
        Err(VfsError::OperationNotPermitted)
    );

    root.chown(None, Some(200), &owner).unwrap();
    assert_eq!(root.metadata().gid, 200);
    root.chmod(NodePermission::from_bits_truncate(0o2660), &owner)
        .unwrap();
    assert!(
        root.metadata()
            .mode
            .permission()
            .contains(NodePermission::SET_GID)
    );
}