fn test_rename_replace_keeps_source_inode_identity() {
    let fs = Arc::new(MockFilesystem);
    let root = make_renamable_dir_entry(32, None, "");
    let (source, _) = make_file_entry(fs.clone(), 33, Some(root.clone()), "tmp");
    let (target, _) = make_file_entry(fs, 34, Some(root.clone()), "final");

    root.insert_cache(String::from("tmp"), source.clone());
    root.insert_cache(String::from("final"), target.clone());
    root.rename("tmp", &root, "final", RenameFlags::empty())
        .unwrap();

    let moved = root.lookup_cache("final").unwrap();
    assert!(moved.ptr_eq(&source));
    assert!(!moved.is_same_inode(&target));
}