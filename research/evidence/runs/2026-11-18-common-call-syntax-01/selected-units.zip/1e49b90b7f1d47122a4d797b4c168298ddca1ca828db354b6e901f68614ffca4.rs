fn initialize_test_bdev(
    super_block: &Arc<SuperBlock>,
    operations: &'static dyn SuperBlockOperations,
) -> VfsResult<()> {
    super_block.initialize(operations, 512, MAX_LFS_FILESIZE, |super_block| {
        let inode = super_block.get_or_init_inode(1, || {
            VfsInode::new_dir_with_defaults(
                NodeFlags::empty(),
                VfsInodeInit::new(
                    1,
                    0,
                    Umode::new(NodeType::Directory, NodePermission::default()),
                ),
            )
        });
        Ok(Dentry::new_dir_from_inode(inode, None, String::new()))
    })
}