fn invalidate_cached_child(&self, name: &str) -> VfsResult<()> {
        self.as_dir()?;
        Self::verify_child_name(name)?;
        let dir_inode = self.vfs_inode();
        let _namespace_guard = dir_inode.lock_namespace_exclusive();
        self.forget_cache_entry(name);
        Ok(())
    }