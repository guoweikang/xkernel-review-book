fn test_nested_mount_root_dotdot_crosses_to_parent_mount() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::empty());
    let grandchild_fs = mock_filesystem(StatFsFlags::empty());

    let root_mount = Mount::new_root(&root_fs);
    let first_mount_dir = lookup_no_follow(&root_mount.root_path(), "mnt").unwrap();
    let child_mount = mount_filesystem(&first_mount_dir, &child_fs).unwrap();
    let second_mount_dir = lookup_no_follow(&child_mount.root_path(), "mnt").unwrap();
    let grandchild_mount = mount_filesystem(&second_mount_dir, &grandchild_fs).unwrap();
    let grandchild_root = grandchild_mount.root_path();
    let grandchild_path = grandchild_root.absolute_path().unwrap();

    assert_eq!(grandchild_path.as_str(), "/mnt/mnt");
    assert_eq!(
        grandchild_root.render_from(&root_mount.root_path()),
        Ok(RenderedPath::Reachable(PathBuf::from("/mnt/mnt")))
    );
    assert_eq!(grandchild_root.name(), "");
    assert!(grandchild_root.dentry().is_root_of_mount());
    assert!(
        lookup_no_follow(&grandchild_root, "..")
            .unwrap()
            .absolute_path()
            == Ok(PathBuf::from("/mnt"))
    );
}