fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let location = self.location.read();
        f.debug_struct("DentryInner")
            .field("flags", &*self.flags.lock())
            .field("inode", &*self.inode.lock())
            .field("name", &location.name)
            .finish()
    }