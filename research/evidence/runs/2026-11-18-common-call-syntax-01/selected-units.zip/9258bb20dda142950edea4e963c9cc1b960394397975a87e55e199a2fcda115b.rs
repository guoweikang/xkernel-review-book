fn magic_link_rejection_applies_to_final_and_non_final_components() {
    let tree = test_tree();

    let err = Filename::new("/magic")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::follow() | LookupFlags::NO_MAGIC_LINKS,
            &kcred::initial_cred(),
        )
        .unwrap_err();
    assert_eq!(err, VfsError::FilesystemLoop);

    let err = Filename::new("/magicdir/leaf")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::no_follow() | LookupFlags::NO_MAGIC_LINKS,
            &kcred::initial_cred(),
        )
        .unwrap_err();
    assert_eq!(err, VfsError::FilesystemLoop);
    assert_eq!(tree.magic_dir.follow_count(), 0);
}