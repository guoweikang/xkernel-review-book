fn test_lookup_non_cacheable_negative_retracts() {
    let fs = Arc::new(MockFilesystem);
    let (dir, _) = make_non_cacheable_dir(fs.clone(), 2, None, "dir");
    let sb = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        dir.clone()
    });

    // Default MockDirOps::lookup returns Ok(None).
    assert!(matches!(dir.lookup("missing"), Err(VfsError::NotFound)));

    // The negative candidate must not survive in the children map or the
    // dcache (checked by key), and a repeated lookup must not be poisoned
    // by a stale negative dentry.
    assert!(dir.lookup_cache_entry("missing").is_none());
    let probe = Dentry::new_negative(Some(dir.clone()), String::from("missing"));
    assert!(!sb.is_dentry_cached(&probe));
    assert!(matches!(dir.lookup("missing"), Err(VfsError::NotFound)));
}