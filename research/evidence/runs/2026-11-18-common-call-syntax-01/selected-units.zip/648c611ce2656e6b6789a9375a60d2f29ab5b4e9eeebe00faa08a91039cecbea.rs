fn private_fault_readahead_honours_exclusive_file_end() {
    let inode = read_inode(&FAULT_READAHEAD_OPS, 4 * PAGE_SIZE_4K);
    let mapping = inode.address_space();
    mapping
        .readahead_for_fault(0, Some((PAGE_SIZE_4K + 13) as u64))
        .expect("ELF prefix selects two pages");
    assert_eq!(mapping.nrpages(), 2);

    mapping
        .readahead_for_fault((2 * PAGE_SIZE_4K) as u64, Some((PAGE_SIZE_4K + 13) as u64))
        .expect("BSS-only offset needs no work");
    assert_eq!(mapping.nrpages(), 2);
}