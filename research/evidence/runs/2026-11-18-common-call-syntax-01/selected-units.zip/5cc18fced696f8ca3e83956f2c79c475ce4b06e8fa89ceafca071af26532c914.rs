fn extracting_value_transfers_drop_ownership() {
    use core::sync::atomic::{AtomicUsize, Ordering};

    struct CountDrop<'a>(&'a AtomicUsize);

    impl Drop for CountDrop<'_> {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::Relaxed);
        }
    }

    let drops = AtomicUsize::new(0);
    let value = Once::initialized(CountDrop(&drops))
        .try_into_inner()
        .unwrap();
    assert_eq!(drops.load(Ordering::Relaxed), 0);
    drop(value);
    assert_eq!(drops.load(Ordering::Relaxed), 1);

    let once = Once::initialized(CountDrop(&drops));
    // SAFETY: this owned cell was initialized immediately above.
    let value = unsafe { once.into_inner_unchecked() };
    assert_eq!(drops.load(Ordering::Relaxed), 1);
    drop(value);
    assert_eq!(drops.load(Ordering::Relaxed), 2);
}