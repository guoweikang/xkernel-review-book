fn new(blocks: usize) -> Arc<Self> {
        use core::sync::atomic::{AtomicBool, AtomicUsize};
        Arc::new(Self {
            memory: Arc::new(MemoryBlockDevice {
                storage: Arc::new(Mutex::new(vec![0x35; blocks * 512])),
                block_size: 512,
                flushes: Arc::new(AtomicUsize::new(0)),
                reads: Arc::new(AtomicUsize::new(0)),
                writes: Arc::new(AtomicUsize::new(0)),
                fail_io: Arc::new(AtomicBool::new(false)),
                fail_after_write_bytes: AtomicUsize::new(usize::MAX),
            }),
            modes: Mutex::new(Vec::new()),
            ioctl_modes: Mutex::new(Vec::new()),
            releases: AtomicUsize::new(0),
            fail_open: AtomicBool::new(false),
        })
    }