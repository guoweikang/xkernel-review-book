fn write_iter_with_checks(
        &self,
        iocb: &mut Kiocb<'_>,
        iter: &mut IovIterSource<'_>,
        checks: impl FnOnce(u64, &mut usize) -> VfsResult<()>,
    ) -> VfsResult<usize> {
        let inode = self.inode().ok_or(VfsError::InvalidInput)?;
        let _data_guard = inode.lock_data();
        let mut count = iter.count();
        self.generic_write_check_limits(iocb, &mut count)?;
        if count != 0 {
            checks(iocb.ki_pos(), &mut count)?;
        }
        iter.truncate(count);
        let count = iter.count();
        if count == 0 {
            return Ok(0);
        }

        // Filesystems may defer persistence, but writes must publish timestamps
        // before taking folio locks or exposing modified data.
        iocb.file().file_update_time()?;
        let written = self.perform_write(iocb.ki_pos(), iter, count)?;
        iocb.advance(written);
        Ok(written)
    }