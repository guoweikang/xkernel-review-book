fn test_rename_directory_emptiness_is_filesystem_owned() {
    let root = make_renamable_dir_entry(62, None, "");
    let source = make_renamable_dir_entry(63, Some(root.clone()), "source");
    let target = make_renamable_dir_entry(64, Some(root.clone()), "target");
    let (cached_child, _) =
        make_file_entry(Arc::new(MockFilesystem), 65, Some(target.clone()), "cached");
    root.insert_cache(String::from("source"), source.clone());
    root.insert_cache(String::from("target"), target.clone());
    target.insert_cache(String::from("cached"), cached_child.clone());

    root.rename("source", &root, "target", RenameFlags::empty())
        .unwrap();
    assert!(root.lookup_cache("target").unwrap().ptr_eq(&source));
}