fn compare_exchange(
            &self,
            old: Status,
            new: Status,
            success: Ordering,
            failure: Ordering,
        ) -> Result<Status, Status> {
            // Try to atomically swap old state with new state
            let old_raw = old as u8;
            let new_raw = new as u8;
            let result = self.0.compare_exchange(old_raw, new_raw, success, failure);

            // Convert result values back to Status enum
            match result {
                Ok(current) => Ok(Status::from_raw(current)),
                Err(actual) => Err(Status::from_raw(actual)),
            }
        }