fn snapshot_partial_reads_are_stable_across_source_changes() {
    let source = Arc::new(crate::Mutex::new(b"abcdefgh".to_vec()));
    let observed = source.clone();
    let generations = Arc::new(crate::Mutex::new(0usize));
    let generated = generations.clone();
    let super_block = SimpleFs::new_with(&TEST_FILE_SYSTEM_TYPE, 0, move |fs| {
        let mut root = DirMapping::new();
        root.add(
            "snapshot",
            SimpleFile::new_snapshot(fs.clone(), move || {
                *generated.lock() += 1;
                Ok(observed.lock().clone())
            }),
        );
        SimpleDir::new_maker(fs, Arc::new(root))
    })
    .unwrap();
    let root = Mount::new_root(&super_block).root_path();
    let open = |flags| {
        Filename::new("/snapshot")
            .open_with_flags_at(
                &root,
                &root,
                flags,
                NodePermission::empty(),
                NodePermission::empty(),
                kcred::initial_cred(),
            )
            .unwrap()
    };
    let first = open(linux_raw_sys::general::O_RDONLY);
    let mut prefix = [0; 3];
    assert_eq!(first.read(&mut prefix), Ok(3));
    assert_eq!(&prefix, b"abc");
    *source.lock() = b"CHANGED-LONG".to_vec();
    let mut tail = [0; 5];
    assert_eq!(first.read(&mut tail), Ok(5));
    assert_eq!(&tail, b"defgh");
    let mut next = [0; 12];
    assert_eq!(
        open(linux_raw_sys::general::O_RDONLY).read(&mut next),
        Ok(12)
    );
    assert_eq!(&next, b"CHANGED-LONG");
    assert_eq!(first.llseek(0, crate::file::SEEK_END), Ok(8));
    assert_eq!(first.read(&mut next), Ok(0));
    assert_eq!(first.llseek(-2, crate::file::SEEK_END), Ok(6));
    assert_eq!(first.read(&mut next), Ok(2));
    assert_eq!(&next[..2], b"gh");
    assert_eq!(
        first.llseek(-9, crate::file::SEEK_END),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(first.llseek(0, crate::file::SEEK_CUR), Ok(8));
    assert_eq!(
        first.llseek(i64::MAX, crate::file::SEEK_END),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(first.llseek(0, -1), Err(VfsError::InvalidInput));
    assert_eq!(first.llseek(0, crate::file::SEEK_CUR), Ok(8));
    assert_eq!(first.llseek(0, crate::file::SEEK_SET), Ok(0));
    assert_eq!(
        open(linux_raw_sys::general::O_RDONLY).llseek(0, crate::file::SEEK_END),
        Ok(12)
    );
    assert_eq!(first.write(b"x"), Err(VfsError::BadFileDescriptor));
    assert_eq!(*generations.lock(), 3);
    let write_opened = open(linux_raw_sys::general::O_WRONLY);
    assert_eq!(*generations.lock(), 3);
    assert_eq!(
        write_opened
            .private_data_get::<SimpleFileSnapshot>()
            .is_none(),
        true
    );
    assert_eq!(write_opened.llseek(3, crate::file::SEEK_SET), Ok(3));
    assert_eq!(write_opened.llseek(2, crate::file::SEEK_CUR), Ok(5));
    assert_eq!(write_opened.llseek(-1, crate::file::SEEK_CUR), Ok(4));
    assert_eq!(
        write_opened.llseek(-5, crate::file::SEEK_CUR),
        Err(VfsError::InvalidInput)
    );
    assert_eq!(
        write_opened.llseek(0, crate::file::SEEK_END),
        Err(VfsError::InvalidData)
    );
    assert_eq!(write_opened.llseek(0, crate::file::SEEK_CUR), Ok(4));
    assert_eq!(*generations.lock(), 3);
    assert_eq!(write_opened.write(b"x"), Err(VfsError::InvalidInput));
    assert_eq!(*source.lock(), b"CHANGED-LONG".to_vec());
    let read_write = open(linux_raw_sys::general::O_RDWR);
    assert_eq!(*generations.lock(), 4);
    assert_eq!(read_write.read(&mut next), Ok(12));
    assert_eq!(&next, b"CHANGED-LONG");
    assert_eq!(read_write.write(b"x"), Err(VfsError::InvalidInput));
    source.lock().clear();
    let empty = open(linux_raw_sys::general::O_RDONLY);
    assert_eq!(empty.llseek(0, crate::file::SEEK_END), Ok(0));
    assert_eq!(empty.read(&mut next), Ok(0));
    assert_eq!(empty.llseek(2, crate::file::SEEK_SET), Ok(2));
    assert_eq!(empty.read(&mut next), Ok(0));
    assert_eq!(first.llseek(0, crate::file::SEEK_END), Ok(8));
}