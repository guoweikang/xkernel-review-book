fn init_special_inode(
    node_type: NodeType,
    rdev: DeviceId,
) -> (Option<Arc<dyn FileOperations>>, DeviceId) {
    match node_type {
        NodeType::CharacterDevice => (Some(character_device_file_operations()), rdev),
        NodeType::BlockDevice => (Some(block_device_file_operations()), rdev),
        NodeType::Fifo => (Some(fifo_file_operations()), DeviceId::default()),
        NodeType::Socket => (None, DeviceId::default()),
        _ => (None, DeviceId::default()),
    }
}