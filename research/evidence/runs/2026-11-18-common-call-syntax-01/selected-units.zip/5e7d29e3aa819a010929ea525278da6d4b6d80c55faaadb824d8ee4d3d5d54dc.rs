fn mount_new(
        &self,
        mountpoint: &Path,
        mount_flags: MountFlags,
        context: &mut FsContext<'_>,
        lookup_root: &Path,
        lookup_pwd: &Path,
    ) -> VfsResult<Arc<Mount>> {
        loop {
            let super_block = context.get_tree(lookup_root, lookup_pwd)?;
            let result = self.attach_with_requested_superblock_flags(
                mountpoint,
                &super_block,
                mount_flags,
                context.source(),
                Some(context.sb_flags()),
            );
            if matches!(&result, Err(VfsError::ResourceBusy)) && !super_block.is_available() {
                continue;
            }
            return result;
        }
    }