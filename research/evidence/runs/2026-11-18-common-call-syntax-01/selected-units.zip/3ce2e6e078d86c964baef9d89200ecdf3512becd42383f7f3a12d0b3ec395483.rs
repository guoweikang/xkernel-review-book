fn wake_blocked(&self, blocked: &mut MutexGuard<'_, BlockedOwners>, wake: &mut WakeQueue) {
        while let Some(waiter) = self.state(blocked).requests.pop_front() {
            self.note_pop();
            waiter.state(blocked).blocker = None;
            remove_blocked_owner(blocked, &waiter);
            // The registration moves with its existing request node. A
            // pending notification keeps `wait` populated until dequeue, so
            // even a spurious poll cannot reuse these links prematurely.
            if waiter.state(blocked).wait.is_some() {
                wake.0.push_back(waiter);
            }
        }
        debug_assert_eq!(self.waiter_count.load(Ordering::Relaxed), 0);
    }