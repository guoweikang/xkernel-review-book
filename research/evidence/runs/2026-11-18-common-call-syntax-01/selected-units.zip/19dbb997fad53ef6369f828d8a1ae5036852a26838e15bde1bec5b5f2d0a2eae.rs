fn test_node_type_conversion() {
    assert_eq!(NodeType::from(0o1), NodeType::Fifo);
    assert_eq!(NodeType::from(0o2), NodeType::CharacterDevice);
    assert_eq!(NodeType::from(0o4), NodeType::Directory);
    assert_eq!(NodeType::from(0o6), NodeType::BlockDevice);
    assert_eq!(NodeType::from(0o10), NodeType::RegularFile);
    assert_eq!(NodeType::from(0o12), NodeType::Symlink);
    assert_eq!(NodeType::from(0o14), NodeType::Socket);
    assert_eq!(NodeType::from(0o0), NodeType::Unknown);
    assert_eq!(NodeType::from(0o77), NodeType::Unknown);
}