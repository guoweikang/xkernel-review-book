fn uncontended_operations_do_not_take_wait_tree_lock() {
    let blocked = node::hold_wait_tree();
    for owner in [FileLockOwner::Posix(500), FileLockOwner::Flock(500)] {
        let context = FileLockContext::new();
        for (kind, start, length) in [
            (FileLockType::Write, 0, 10),
            (FileLockType::Write, 0, 20),
            (FileLockType::Write, 30, 10),
            (FileLockType::Write, 0, 40),
            (FileLockType::Unlock, 10, 10),
            (FileLockType::Read, 0, 40),
            (FileLockType::Unlock, 0, 0),
        ] {
            context
                .apply(
                    &FileLock::new(owner, 0, kind, start, length).unwrap(),
                    false,
                )
                .unwrap();
        }
    }
    drop(blocked);
}