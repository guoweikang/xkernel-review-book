fn exchange_cached_dentries(
        &self,
        old_key: &DentryKey,
        source: &Dentry,
        new_key: &DentryKey,
        target: &Dentry,
    ) {
        let mut cache = self.dentry_cache.lock();
        if cache.contains_key(old_key) && cache.contains_key(new_key) {
            *cache.get_mut(old_key).expect("checked cache entry") = target.clone();
            *cache.get_mut(new_key).expect("checked cache entry") = source.clone();
        } else {
            let old = cache.remove(old_key);
            let new = cache.remove(new_key);
            drop(cache);
            drop(old);
            drop(new);
        }
    }