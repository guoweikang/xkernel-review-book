fn cached_child_inode_or_insert_with(
        &self,
        name: &str,
        create: impl FnOnce(&Dentry, String) -> Dentry,
    ) -> u64 {
        if let Some(entry) = self
            .dentry
            .lookup_cache(name)
            .filter(Dentry::is_really_positive)
        {
            return entry.inode();
        }

        let name = name.to_string();
        let entry = create(&self.dentry, name.clone());
        self.dentry
            .insert_cache(name, entry.clone())
            .filter(Dentry::is_really_positive)
            .unwrap_or(entry)
            .inode()
    }