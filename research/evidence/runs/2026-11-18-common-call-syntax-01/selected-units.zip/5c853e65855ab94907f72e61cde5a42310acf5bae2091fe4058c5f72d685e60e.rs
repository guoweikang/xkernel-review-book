fn new_records_open_file_flags() {
    let file = test_file(OpenFlags::DIRECT | OpenFlags::DSYNC);
    let iocb = Kiocb::new(&file, 7);
    assert_eq!(iocb.ki_pos(), 7);
    assert_eq!(iocb.flags(), KiocbFlags::DIRECT | KiocbFlags::DSYNC);
}