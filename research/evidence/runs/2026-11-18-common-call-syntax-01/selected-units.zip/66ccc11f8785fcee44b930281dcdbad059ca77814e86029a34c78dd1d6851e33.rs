fn negative_cached_dentry_is_not_a_pathwalk_target() {
    let tree = test_tree();
    let negative = Dentry::new_negative(Some(tree.root.dentry().clone()), String::from("missing"));
    tree.root
        .dentry()
        .insert_cache(String::from("missing"), negative);

    let err = Filename::new("/missing")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::follow(),
            &kcred::initial_cred(),
        )
        .unwrap_err();
    assert_eq!(err, VfsError::NotFound);
}