fn add_alias(&self, dentry: &Dentry, is_directory: bool) -> bool {
        let mut aliases = self.aliases.lock();
        aliases.retain(DentryAlias::is_live);
        if aliases.iter().any(|alias| alias.points_to(dentry)) {
            return true;
        }
        if is_directory && !aliases.is_empty() {
            return false;
        }
        aliases.push(DentryAlias::new(dentry));
        true
    }