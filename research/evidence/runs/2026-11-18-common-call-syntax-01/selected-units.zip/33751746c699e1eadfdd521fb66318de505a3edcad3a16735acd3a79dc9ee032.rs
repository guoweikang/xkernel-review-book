fn make_non_cacheable_dir(
    fs: Arc<MockFilesystem>,
    inode: u64,
    parent: Option<Dentry>,
    name: &str,
) -> (Dentry, Arc<MockDirOps>) {
    let ops = Arc::new(MockDirOps::new(fs, inode));
    let private_data: Arc<dyn core::any::Any + Send + Sync> = ops.clone();
    let inode = VfsInode::new_dir_with_operations(
        private_data,
        ops.clone(),
        ops.clone(),
        NodeFlags::NON_CACHEABLE,
        inode_init(inode, NodeType::Directory, 0),
    );
    (
        Dentry::new_dir_from_inode(inode, parent, String::from(name)),
        ops,
    )
}