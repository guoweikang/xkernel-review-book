fn link_count_error_propagates_without_changing_cached_metadata() {
    let root = root_path(Arc::new(LinkCountOps {
        value: AtomicU64::new(7),
        fail: true,
    }));
    let cached = root.metadata();
    assert_eq!(getattr(&root).err(), Some(VfsError::Io));
    let after = root.metadata();
    assert_eq!(after.nlink, cached.nlink);
    assert!(assert_other_metadata_unchanged(&after, &cached).is_ok());
}