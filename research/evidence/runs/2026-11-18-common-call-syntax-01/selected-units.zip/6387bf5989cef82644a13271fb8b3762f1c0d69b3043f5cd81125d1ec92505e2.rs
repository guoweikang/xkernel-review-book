fn sget_dev_uses_canonical_device_object_identity() {
    FILL_COUNT.store(0, Ordering::Relaxed);
    let (old_disk, old_device) = add_test_disk("kvfs-old-device", 248);
    let registry = super_block_registry();
    let old_super_block = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            old_device,
            SuperBlockFlags::empty(),
            fill_test_bdev,
        )
        .expect("mount old device generation");
    old_super_block.activate_mount();
    block::del_gendisk(old_disk.device_number()).expect("unpublish old disk");

    let (new_disk, new_device) = add_test_disk("kvfs-new-device", 248);
    let new_super_block = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            new_device,
            SuperBlockFlags::empty(),
            fill_test_bdev,
        )
        .expect("mount replacement device generation");
    new_super_block.activate_mount();

    assert!(!Arc::ptr_eq(&old_super_block, &new_super_block));
    assert_eq!(FILL_COUNT.load(Ordering::Relaxed), 2);

    old_super_block.deactivate_mount();
    new_super_block.deactivate_mount();
    block::del_gendisk(new_disk.device_number()).expect("remove replacement disk");
}