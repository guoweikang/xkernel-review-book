fn open(self: Arc<Self>, inode: &VfsInode, file: &mut VfsFileBuilder) -> VfsResult<()> {
        let access = PipeAccess::from_mode(file.mode())?;
        let pipe = inode.acquire_fifo_pipe()?;
        let pipe_generation = match pipe.open_fifo(access, file.is_nonblocking()) {
            Ok(pipe_generation) => pipe_generation,
            Err(error) => {
                inode.release_fifo_pipe(&pipe);
                return Err(error);
            }
        };
        file.stream_open();
        file.set_pipe_generation(pipe_generation);
        file.set_private_data(pipe);
        Ok(())
    }