fn starts_with(self, prefix: &[u8]) -> bool {
        if self.first.len() >= prefix.len() {
            self.first.starts_with(prefix)
        } else {
            prefix.starts_with(self.first) && self.second.starts_with(&prefix[self.first.len()..])
        }
    }