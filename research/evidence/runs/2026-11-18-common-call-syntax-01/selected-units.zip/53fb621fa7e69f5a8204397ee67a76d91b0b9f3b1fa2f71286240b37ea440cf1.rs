fn write(&self, nonblocking: bool, request_is_atomic: bool, buf: &[u8]) -> KResult<usize> {
        if buf.is_empty() {
            return Ok(0);
        }

        let size = buf.len();
        let mut written_total = 0usize;
        block_on(poll_file_io(self, IoEvents::OUT, nonblocking, || {
            let written = {
                let mut state = self.state.lock();
                if state.readers == 0 {
                    None
                } else {
                    let available = state.available();
                    if request_is_atomic && written_total == 0 && available < size {
                        return Err(KError::WouldBlock);
                    }
                    let count = available.min(size - written_total);
                    state.write_from(&buf[written_total..written_total + count]);
                    Some(count)
                }
            };

            let Some(written) = written else {
                // Linux treats SIGPIPE delivery as best effort: write(2) must
                // still report EPIPE or the already completed byte count.
                let _ = send_sig_current(Signo::SIGPIPE);
                if written_total > 0 {
                    return Ok(written_total);
                }
                return Err(KError::BrokenPipe);
            };

            if written > 0 {
                written_total += written;
                ktask::with_wake_sync(|| self.rd_wait.wake());
                if written_total == size || nonblocking {
                    return Ok(written_total);
                }
            }

            Err(KError::WouldBlock)
        }))
        .or_else(|error| {
            // `anon_pipe_write()` returns a partial count instead of an
            // interruption or wait-registration error after making progress.
            (written_total != 0).then_some(written_total).ok_or(error)
        })
    }