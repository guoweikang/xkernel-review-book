fn chained_names_preserve_order_and_release_iterators() {
    let drops = Arc::new(AtomicU64::new(0));
    let chained = NamesOps { drops: drops.clone(), fail: false }
        .chain(NamesOps { drops: drops.clone(), fail: false });
    let names: Vec<_> = chained.child_names().unwrap().collect();
    assert_eq!(names.as_slice(), [Cow::Borrowed("entry"), Cow::Borrowed("entry")]);
    assert_eq!(drops.load(Ordering::Relaxed), 2);
}