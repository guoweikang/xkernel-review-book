fn new_special<T>(node: Arc<T>, flags: NodeFlags, mut init: VfsInodeInit) -> Arc<Self>
    where
        T: Any + Send + Sync + InodeOperations,
    {
        let node_type = init.node_type();
        debug_assert!(matches!(
            node_type,
            NodeType::CharacterDevice | NodeType::BlockDevice | NodeType::Fifo | NodeType::Socket
        ));
        let private_data: Arc<dyn Any + Send + Sync> = node.clone();
        let inode_operations: Arc<dyn InodeOperations> = node.clone();
        let (file_operations, rdev) = init_special_inode(node_type, init.rdev);
        init.rdev = rdev;
        Self::from_parts(InodeParts {
            private_data,
            inode_operations,
            file_operations,
            flags,
            address_space_operations: empty_address_space_operations(),
            init,
        })
    }