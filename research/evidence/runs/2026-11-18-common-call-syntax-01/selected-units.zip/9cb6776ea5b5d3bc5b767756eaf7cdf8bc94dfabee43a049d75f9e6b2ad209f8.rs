fn get_mut_and_as_mut_ptr_update_ready_value() {
    let mut once = Once::initialized(5usize);
    assert_eq!(
        once.get_mut().map(|value| {
            *value += 2;
            *value
        }),
        Some(7)
    );

    // SAFETY: `once` is a local, fully owned `Once::initialized` value, so
    // this is the only reference to it; `as_mut_ptr` yields a valid,
    // exclusive pointer to the stored `usize`, which is initialized.
    unsafe {
        *once.as_mut_ptr() = 13;
    }

    assert_eq!(once.get().copied(), Some(13));
}