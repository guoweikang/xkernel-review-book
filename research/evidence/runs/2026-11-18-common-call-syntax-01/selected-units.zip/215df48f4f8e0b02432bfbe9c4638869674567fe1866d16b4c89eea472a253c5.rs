fn cdev_add_named(
    device: DeviceId,
    name: String,
    class: String,
    operations: Arc<dyn DeviceFileOps>,
) -> VfsResult<CharacterDeviceRegistration> {
    if !valid_component(&name) || !valid_component(&class) {
        return Err(VfsError::InvalidInput);
    }
    let mut entry = ChrdevEntry::new(device, 1, operations)?;
    entry.identity = Some(CharacterDeviceIdentity { name, class });
    let entry = Arc::new(entry);
    let subscribers = {
        let mut registry = CHRDEV_MAP.lock();
        registry.add(&entry)?;
        registry.subscribers.clone()
    };
    for subscriber in subscribers {
        subscriber();
    }
    Ok(CharacterDeviceRegistration(entry))
}