fn block_on(&self, blocker: Blocker, wake: &mut WakeQueue) -> KResult<()> {
        let mut blocker = blocker.0;
        let mut blocked = BLOCKED_OWNERS.lock();
        // A pending notification still owns the intrusive links. Never allow
        // a second insertion to overwrite their recorded parent relationship.
        let state = self.0.state(&mut blocked);
        assert!(state.blocker.is_none() && state.wait.is_none());
        // A retry may meet a different blocker; descendants must retry too.
        self.0.wake_blocked(&mut blocked, wake);
        // SAFETY: only Waiter::new creates this handle; its range is immutable.
        let request = unsafe { self.0.record() };
        if has_deadlock(&mut blocked, &request, blocker.owner) {
            return Err(LinuxError::EDEADLK.into());
        }
        loop {
            let next = LockNode::find(&blocker.state(&mut blocked).requests, |other| {
                // SAFETY: only this method populates blocked requests, always
                // from a Waiter. Their ranges never become installed/mutable.
                request.conflicts_with(&unsafe { other.record() })
            });
            match next {
                Some(next) => blocker = next,
                None => break,
            }
        }
        self.0.state(&mut blocked).blocker = Some(Arc::downgrade(&blocker));
        blocker
            .state(&mut blocked)
            .requests
            .push_back(self.0.clone());
        blocker.note_push();
        // Indexing depends on the actual blocker, not detection eligibility.
        if blocker.owner.is_posix() {
            blocked
                .entry(self.0.owner)
                .or_default()
                .insert(Arc::as_ptr(&self.0).addr(), self.0.clone());
        }
        Ok(())
    }