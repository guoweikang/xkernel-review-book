fn wait_for_transition(&self, key: &InodeCacheKey, waiters: &Arc<WaitQueue>) {
        waiters.wait_until(|| {
            let inodes = self.inodes.lock();
            match inodes.get(key) {
                None => true,
                Some(entry) if !Arc::ptr_eq(&entry.waiters, waiters) => true,
                Some(entry) => match &entry.state {
                    CachedInodeState::Live(inode) => inode.strong_count() != 0,
                    CachedInodeState::New | CachedInodeState::Freeing(_) => false,
                },
            }
        });
    }