fn block_special_file_io_crosses_blocks_and_obeys_capacity() {
    const BLOCK_SIZE: usize = 512;
    const BLOCKS: usize = 4;
    let initial: Vec<u8> = (0..BLOCK_SIZE * BLOCKS)
        .map(|index| (index % 251) as u8)
        .collect();
    let storage = Arc::new(Mutex::new(initial.clone()));
    let flushes = Arc::new(core::sync::atomic::AtomicUsize::new(0));
    let reads = Arc::new(core::sync::atomic::AtomicUsize::new(0));
    let writes = Arc::new(core::sync::atomic::AtomicUsize::new(0));
    let fail_io = Arc::new(core::sync::atomic::AtomicBool::new(false));
    let disk = block::Gendisk::alloc(
        String::from("kvfs-block-test"),
        243,
        0,
        1,
        Box::new(MemoryBlockDevice {
            storage: storage.clone(),
            block_size: BLOCK_SIZE,
            flushes: flushes.clone(),
            reads: reads.clone(),
            writes: writes.clone(),
            fail_io: fail_io.clone(),
            fail_after_write_bytes: core::sync::atomic::AtomicUsize::new(usize::MAX),
        }),
    )
    .expect("valid KVFS test disk");
    let device = block::add_disk(disk.clone()).expect("publish KVFS test disk");

    let mut output = vec![0; 1024];
    assert_eq!(read_block_device(&device, &mut output, 256).unwrap(), 1024);
    assert_eq!(&output[..], &initial[256..1280]);

    let input = vec![0x5a; 1024];
    assert_eq!(write_block_device(&device, &input, 256).unwrap(), 1024);
    assert_eq!(&storage.lock()[256..1280], &input[..]);
    assert_eq!(flushes.load(core::sync::atomic::Ordering::Relaxed), 0);

    use core::sync::atomic::Ordering::Relaxed;
    reads.store(0, Relaxed);
    writes.store(0, Relaxed);
    let aligned = vec![0xa7; 1024];
    assert_eq!(write_block_device(&device, &aligned, 512).unwrap(), 1024);
    assert_eq!(writes.load(Relaxed), 1);
    assert_eq!(reads.load(Relaxed), 0);
    assert_eq!(&storage.lock()[512..1536], &aligned[..]);
    let mut aligned_read = vec![0; 1024];
    assert_eq!(
        read_block_device(&device, &mut aligned_read, 512).unwrap(),
        1024
    );
    assert_eq!(aligned_read, aligned);
    assert_eq!(reads.load(Relaxed), 1);

    let mut clipped = vec![0; 2048];
    assert_eq!(
        read_block_device(&device, &mut clipped, 1024).unwrap(),
        1024
    );
    assert_eq!(&clipped[..1024], &storage.lock()[1024..]);
    assert_eq!(reads.load(Relaxed), 2);
    assert_eq!(
        write_block_device(&device, &[0x39; 2048], 1024).unwrap(),
        1024
    );
    assert_eq!(writes.load(Relaxed), 2);

    fail_io.store(true, Relaxed);
    assert_eq!(
        read_block_device(&device, &mut aligned_read, 512).unwrap_err(),
        KError::Io
    );
    assert_eq!(
        write_block_device(&device, &aligned, 512).unwrap_err(),
        KError::Io
    );
    assert_eq!(reads.load(Relaxed), 3);
    assert_eq!(writes.load(Relaxed), 3);
    fail_io.store(false, Relaxed);

    let mut tail = vec![0; 1024];
    assert_eq!(
        read_block_device(&device, &mut tail, (BLOCK_SIZE * BLOCKS - 128) as u64).unwrap(),
        128
    );
    assert_eq!(
        write_block_device(&device, &[1], (BLOCK_SIZE * BLOCKS) as u64).unwrap_err(),
        VfsError::StorageFull
    );

    device
        .set_disk_read_only(true)
        .expect("set test disk read-only");
    let writes_before = writes.load(Relaxed);
    assert_eq!(
        write_block_device(&device, &[0; 1024], 0).unwrap_err(),
        VfsError::from(KError::OperationNotPermitted)
    );
    assert_eq!(writes.load(Relaxed), writes_before);
    assert_eq!(
        write_block_device(&device, &[1], 0).unwrap_err(),
        VfsError::from(KError::OperationNotPermitted)
    );

    block::del_gendisk(disk.device_number()).expect("remove KVFS test disk");
}