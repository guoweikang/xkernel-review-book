fn llseek(&self, file: &VfsFile, offset: i64, whence: i32) -> VfsResult<u64> {
        let mut position = file.position_lock();
        let base = match whence {
            crate::file::SEEK_SET => 0,
            crate::file::SEEK_CUR => {
                i64::try_from(*position).map_err(|_| VfsError::InvalidInput)?
            }
            crate::file::SEEK_END => {
                let snapshot = file
                    .private_data_get::<SimpleFileSnapshot>()
                    .ok_or(VfsError::InvalidData)?;
                i64::try_from(snapshot.0.len()).map_err(|_| VfsError::InvalidInput)?
            }
            _ => return Err(VfsError::InvalidInput),
        };
        let next = base
            .checked_add(offset)
            .filter(|next| *next >= 0)
            .ok_or(VfsError::InvalidInput)? as u64;
        *position = next;
        Ok(next)
    }