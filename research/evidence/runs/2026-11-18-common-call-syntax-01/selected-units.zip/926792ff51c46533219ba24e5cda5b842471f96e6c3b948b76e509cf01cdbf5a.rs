fn test_bind_mount_unmount_preserves_source_dentry() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::new_root(&root_fs, kcred::initial_user_namespace());
    let root = namespace.root_path();
    let mountpoint = lookup_child_in_mount(&root, "mnt").unwrap();

    let bind = namespace.attach_bind(&root, &mountpoint).unwrap();
    assert_eq!(bind.flags(), root.mount().flags());
    assert_eq!(bind.root_path().inode_key(), root.inode_key());
    assert!(Arc::ptr_eq(
        lookup_no_follow(&root, "mnt").unwrap().mount(),
        &bind
    ));

    namespace.detach(&bind.root_path()).unwrap();
    assert_eq!(
        lookup_no_follow(&root, "mnt").unwrap().node_type(),
        NodeType::Directory
    );
    assert_eq!(root.node_type(), NodeType::Directory);
}