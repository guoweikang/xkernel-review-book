fn posix_types_private_path() -> syn::Result<proc_macro2::TokenStream> {
    use proc_macro_crate::{FoundCrate, crate_name};
    let found = crate_name("posix-types").map_err(|error| {
        syn::Error::new(
            Span::call_site(),
            format!("posix-types dependency is required: {error}"),
        )
    })?;
    Ok(match found {
        FoundCrate::Itself => quote!(crate),
        FoundCrate::Name(name) => {
            let ident = Ident::new(&name, Span::call_site());
            quote!(#ident)
        }
    })
}