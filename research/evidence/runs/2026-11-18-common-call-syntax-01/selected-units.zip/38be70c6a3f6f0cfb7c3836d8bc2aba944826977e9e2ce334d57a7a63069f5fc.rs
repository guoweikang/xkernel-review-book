fn private<T>(&self) -> VfsResult<&T>
    where
        T: Any + Send + Sync + 'static,
    {
        self.private
            .get()
            .map(|private| &**private)
            .ok_or(VfsError::InvalidInput)?
            .downcast_ref::<T>()
            .ok_or(VfsError::InvalidInput)
    }