fn generate_function_test(args: Punctuated<Ident, Token![,]>, input: ItemFn) -> TokenStream {
    let mut ignore = false;
    let mut should_panic = false;
    let mut serial = false;
    let mut use_user_executor = false;

    for arg in args {
        match arg.to_string().as_str() {
            "ignore" => ignore = true,
            "should_panic" => should_panic = true,
            "serial" => serial = true,
            "user" => use_user_executor = true,
            other => {
                return Error::new(
                    arg.span(),
                    format!("unsupported def_test argument: {other}"),
                )
                .to_compile_error()
                .into();
            }
        }
    }

    let fn_name = &input.sig.ident;
    let fn_attrs = &input.attrs;
    let fn_stmts = &input.block.stmts;

    // Check if function returns TestResult
    let has_return_type = !matches!(input.sig.output, syn::ReturnType::Default);

    // Generate a unique identifier for the test descriptor
    let descriptor_name = format_ident!(
        "__UNITTEST_DESCRIPTOR_{}",
        fn_name.to_string().to_uppercase()
    );

    // clippy's `allow-*-in-tests` only recognises `#[cfg(test)]` / `#[test]`,
    // so the unittest body is exempted here.
    let unittest_allow = quote! {
        #[allow(
            clippy::unwrap_used,
            clippy::expect_used,
            clippy::panic,
            reason = "CG-021-no-panic-on-reachable-failure: unittest body: a failed assertion is the intended outcome"
        )]
        #[allow(
            clippy::too_many_lines,
            reason = "CG-028-focused-functions: unittest body: a test scenario reads as one linear script"
        )]
    };

    // The test function itself becomes the wrapper - body is embedded directly
    // This way assert macros can use `return TestResult::Failed` correctly
    let test_fn = if has_return_type {
        // Function already returns TestResult
        quote! {
            #(#fn_attrs)*
            #unittest_allow
            fn #fn_name() -> unittest::TestResult {
                #(#fn_stmts)*
            }
        }
    } else {
        // Function doesn't return anything, wrap it to return TestResult
        quote! {
            #(#fn_attrs)*
            #unittest_allow
            fn #fn_name() -> unittest::TestResult {
                #(#fn_stmts)*
                unittest::TestResult::Ok
            }
        }
    };

    let ignore_val = ignore;
    let should_panic_val = should_panic;
    let serial_val = serial;
    let execution_mode = if use_user_executor {
        quote!(unittest::TestExecutionMode::User)
    } else {
        quote!(unittest::TestExecutionMode::Standard)
    };
    let fn_name_str = fn_name.to_string();

    // Use linker section to collect test descriptors
    // The linker script defines __unittest_start and __unittest_end symbols
    let output = quote! {
        #test_fn

        #[used]
        #[unsafe(link_section = ".unittest")]
        #[allow(non_upper_case_globals)]
        static #descriptor_name: unittest::TestDescriptor = unittest::TestDescriptor::new(
            #fn_name_str,
            module_path!(),
            #fn_name,
            #should_panic_val,
            #ignore_val,
            #serial_val,
            #execution_mode,
        );
    };

    output.into()
}