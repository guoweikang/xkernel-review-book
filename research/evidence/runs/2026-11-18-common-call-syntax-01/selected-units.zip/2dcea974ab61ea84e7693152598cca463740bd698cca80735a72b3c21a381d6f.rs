fn final_symlink_follow_policy_is_typed() {
    let tree = test_tree();

    let followed = Filename::new("/link")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert!(followed.dentry().is_same_inode(tree.target.dentry()));

    let link = Filename::new("/link")
        .lookup_at(
            &tree.root,
            &tree.base,
            LookupIntent::Open,
            LookupFlags::no_follow(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(link.dentry().node_type(), NodeType::Symlink);
    assert_eq!(link.dentry().read_link().unwrap(), "/target");
}