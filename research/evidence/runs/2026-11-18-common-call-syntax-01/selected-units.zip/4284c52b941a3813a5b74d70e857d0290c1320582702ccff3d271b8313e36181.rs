fn register_poll(
        &self,
        _: &VfsFile,
        context: &mut PollContext<'_>,
        events: IoEvents,
    ) -> Result<(), PollRegisterError> {
        if self.reject_registration.load(Ordering::Relaxed) {
            return Err(PollRegisterError::InvalidState);
        }
        if events.contains(IoEvents::IN) {
            context.register(&self.waiters)?;
        }
        Ok(())
    }