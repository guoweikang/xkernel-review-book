fn getattr(
        &self,
        idmap: &crate::MountIdmap,
        path: Option<&crate::Path>,
        request_mask: crate::GetattrRequestMask,
        query_flags: crate::GetattrQueryFlags,
    ) -> VfsResult<Metadata> {
        let mut metadata = self
            .dir
            .node
            .getattr(idmap, path, request_mask, query_flags)?;
        if let Some(nlink) = self.dir.ops.link_count()? {
            // This is a query-time attribute, not a cached inode update.
            metadata.nlink = nlink;
        }
        Ok(metadata)
    }