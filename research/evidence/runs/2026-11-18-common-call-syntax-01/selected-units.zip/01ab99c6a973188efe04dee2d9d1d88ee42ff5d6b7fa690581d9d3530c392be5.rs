fn test_tree() -> TestTree {
    let root_ops = Arc::new(TestDir::new(1));
    let root_inode =
        VfsInode::new_openable_dir(root_ops.clone(), inode_init(1, NodeType::Directory, 0));
    let root = Dentry::new_dir_from_inode(root_inode, None, String::new());
    let target = file_entry(2, &root, "target", NodeType::RegularFile, b"target", None);
    root_ops.insert("target", target.clone());

    let link = file_entry(3, &root, "link", NodeType::Symlink, b"/target", None);
    root_ops.insert("link", link);

    let (target_dir, target_dir_ops) = dir_entry(4, &root, "dir");
    let leaf = file_entry(5, &target_dir, "leaf", NodeType::RegularFile, b"leaf", None);
    target_dir_ops.insert("leaf", leaf.clone());
    root_ops.insert("dir", target_dir.clone());

    let dir_link = file_entry(6, &root, "dirlink", NodeType::Symlink, b"/dir", None);
    root_ops.insert("dirlink", dir_link);

    let autodir_inode = VfsInode::new_dir(
        Arc::new(TestFile::new(9, NodeType::Directory, &[], None)),
        inode_init(9, NodeType::Directory, 0),
    );
    let autodir =
        Dentry::new_dir_from_inode(autodir_inode, Some(root.clone()), String::from("autodir"));
    root_ops.insert("autodir", autodir);

    let fs = SuperBlock::new(&TEST_FILE_SYSTEM_TYPE, &TEST_SUPER_BLOCK_OPERATIONS, |_| {
        root.clone()
    });
    let mount = Mount::new_root(&fs);
    let root_location = mount.root_path();
    let target_location = Path::new(mount.clone(), target);
    let target_dir_location = Path::new(mount.clone(), target_dir);

    let magic_file = Arc::new(TestMagicLink::new(
        "/display/target",
        target_location.clone(),
    ));
    let magic_entry = file_entry(
        7,
        &root,
        "magic",
        NodeType::Symlink,
        b"/display/target",
        Some(magic_file.clone()),
    );
    root_ops.insert("magic", magic_entry);

    let magic_dir = Arc::new(TestMagicLink::new(
        "/display/dir",
        target_dir_location.clone(),
    ));
    let magic_dir_entry = file_entry(
        8,
        &root,
        "magicdir",
        NodeType::Symlink,
        b"/display/dir",
        Some(magic_dir.clone()),
    );
    root_ops.insert("magicdir", magic_dir_entry);

    TestTree {
        fs,
        root: root_location.clone(),
        base: root_location,
        target: target_location,
        magic_file,
        magic_dir,
    }
}