fn meta(uid: u32, gid: u32, mode: u16) -> Metadata {
    Metadata {
        device: 0,
        inode: 1,
        nlink: 1,
        mode: Umode::new(
            NodeType::RegularFile,
            NodePermission::from_bits_truncate(mode),
        ),
        uid,
        gid,
        size: 0,
        block_size: 512,
        blocks: 1,
        rdev: DeviceId::default(),
        atime: SystemTime::UNIX_EPOCH,
        mtime: SystemTime::UNIX_EPOCH,
        ctime: SystemTime::UNIX_EPOCH,
    }
}