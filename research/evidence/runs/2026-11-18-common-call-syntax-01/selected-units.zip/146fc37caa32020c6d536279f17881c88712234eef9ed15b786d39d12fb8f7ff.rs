fn test_initial_namespace_layers_visible_root_over_structural_root() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::build_initial_mount_tree(&root_fs).unwrap();

    let structural_root = namespace.root_path();
    let visible_root = namespace.visible_root_path();

    assert_eq!(structural_root.mount().filesystem_name(), "nullfs");
    assert_eq!(visible_root.mount().filesystem_name(), "mockfs");
    assert!(!structural_root.ptr_eq(&visible_root));
    assert_eq!(visible_root.absolute_path(), Ok(PathBuf::from("/")));
}