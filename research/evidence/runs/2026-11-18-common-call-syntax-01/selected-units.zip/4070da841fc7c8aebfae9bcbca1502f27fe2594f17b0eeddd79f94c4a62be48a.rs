fn open_magic_link_preserves_no_follow_and_exclusive_create() {
    let tree = test_tree();
    for (flags, expected) in [
        (linux_raw_sys::general::O_NOFOLLOW, VfsError::FilesystemLoop),
        (
            linux_raw_sys::general::O_CREAT | linux_raw_sys::general::O_EXCL,
            VfsError::AlreadyExists,
        ),
    ] {
        let result = Filename::new("/magic").open_with_flags_at(
            &tree.root,
            &tree.base,
            flags,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        );
        assert_eq!(result.err(), Some(expected));
    }
    let file = Filename::new("/magic")
        .open_with_flags_at(
            &tree.root,
            &tree.base,
            linux_raw_sys::general::O_PATH | linux_raw_sys::general::O_NOFOLLOW,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .unwrap();
    assert_eq!(file.inode().node_type(), NodeType::Symlink);
    assert_eq!(tree.magic_file.follow_count(), 0);
}