fn register(
        &self,
        context: &mut PollContext<'_>,
        events: IoEvents,
    ) -> Result<(), PollRegisterError> {
        if events.contains(IoEvents::IN) {
            context.register(&self.rd_wait)?;
        }
        if events.contains(IoEvents::OUT) {
            context.register(&self.wr_wait)?;
        }
        Ok(())
    }