fn vfs_create(
        &self,
        candidate: &Dentry,
        mode: Umode,
        umask: NodePermission,
        exclusive: bool,
        cred: &Cred,
    ) -> VfsResult<()> {
        self.check_writable_mount()?;
        self.may_modify_directory(cred)?;
        let dir_inode = self.inode();
        let mode = dir_inode.prepare_create_mode(
            mode,
            umask,
            NodePermission::all(),
            NodeType::RegularFile,
            cred,
        );
        dir_inode.create_with_mode(candidate, mode, exclusive, cred)
    }