fn may_open(
        path: &Path,
        acc_mode: AccMode,
        open_flags: OpenFlags,
        cred: &Cred,
    ) -> VfsResult<MayOpenResult> {
        let f_mode = FMode::from_open_flags(open_flags);
        if f_mode.contains(FMode::PATH) || open_flags.contains(OpenFlags::PATH) {
            return Ok(MayOpenResult { truncate: false });
        }

        if d_is_symlink(path.dentry()) {
            return Err(VfsError::FilesystemLoop);
        }
        if open_flags.contains(OpenFlags::DIRECTORY) && !d_is_dir(path.dentry()) {
            return Err(VfsError::NotADirectory);
        }

        let node_type = d_inode(path.dentry()).node_type();
        let truncate =
            open_flags.contains(OpenFlags::TRUNCATE) && node_type == NodeType::RegularFile;
        if d_is_dir(path.dentry())
            && (acc_mode.requires_write() || open_flags.contains(OpenFlags::TRUNCATE))
        {
            return Err(VfsError::IsADirectory);
        }
        if matches!(node_type, NodeType::CharacterDevice | NodeType::BlockDevice)
            && path.mount().flags().contains(MountFlags::NODEV)
        {
            return Err(VfsError::PermissionDenied);
        }
        if f_mode.contains(FMode::EXEC)
            && path.mount().flags().contains(MountFlags::NOEXEC)
            && node_type == NodeType::RegularFile
        {
            return Err(VfsError::PermissionDenied);
        }
        if acc_mode.requires_write() || open_flags.contains(OpenFlags::APPEND) || truncate {
            path.check_writable_mount()?;
        }
        path.permission(crate::Permission::MAY_OPEN | acc_mode.permission(), cred)?;
        Ok(MayOpenResult { truncate })
    }