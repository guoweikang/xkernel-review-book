fn readahead(&self, control: &mut crate::ReadaheadControl<'_>) -> VfsResult<()> {
        use core::sync::atomic::Ordering;
        // The gated mapping belongs to a live test inode.
        let inode = control.mapping().inode().unwrap();
        let gate = inode.private::<ReadGate>()?;
        gate.entered.store(true, Ordering::Release);
        gate.events.notify_all(false);
        gate.events
            .wait_until(|| gate.release.load(Ordering::Acquire));
        while control.count() != 0 {
            control.complete_folio(&vec![0x5a; PAGE_SIZE_4K])?;
        }
        Ok(())
    }