fn follow(&self, intent: LookupIntent, flags: LookupFlags) -> VfsResult<ResolvedObject> {
        if flags.rejects_magic_links() || !flags.follows_final() {
            return Err(VfsError::FilesystemLoop);
        }
        *self.last_intent.lock() = Some(intent);
        *self.follow_count.lock() += 1;
        Ok(ResolvedObject::location(self.target.clone()))
    }