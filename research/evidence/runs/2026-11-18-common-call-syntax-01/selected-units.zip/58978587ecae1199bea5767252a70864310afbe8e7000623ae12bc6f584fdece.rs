fn is_mount_root(&self) -> bool {
        if !self.dentry.ptr_eq(&self.mnt.mnt.mnt_root) {
            return false;
        }

        self.mnt.location().is_none_or(|parent_path| {
            parent_path
                .mnt
                .child_mount_at(&parent_path.dentry)
                .is_some_and(|mount| Arc::ptr_eq(&mount, &self.mnt))
        })
    }