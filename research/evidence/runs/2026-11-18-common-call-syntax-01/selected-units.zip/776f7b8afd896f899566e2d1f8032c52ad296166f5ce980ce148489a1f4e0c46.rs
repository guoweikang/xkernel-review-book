fn pipe_poll(file: &VfsFile) -> IoEvents {
    let Ok(pipe) = PipeObject::from_file(file) else {
        return IoEvents::ERR;
    };
    let state = pipe.state.lock();
    let mode = file.mode();
    let mut events = IoEvents::empty();
    if mode.contains(FMode::READ) {
        events.set(IoEvents::IN, !state.buffer.is_empty());
        events.set(
            IoEvents::HUP,
            // Zero is the Linux-compatible uninitialized `f_pipe` snapshot
            // used by anonymous pipes and blocking FIFO opens.
            state.writers == 0
                && (file.pipe_generation() == 0 || file.pipe_generation() != state.w_counter),
        );
    }
    if mode.contains(FMode::WRITE) {
        events.set(IoEvents::OUT, state.buffer.len() < state.capacity);
        events.set(IoEvents::ERR, state.readers == 0);
    }
    events
}