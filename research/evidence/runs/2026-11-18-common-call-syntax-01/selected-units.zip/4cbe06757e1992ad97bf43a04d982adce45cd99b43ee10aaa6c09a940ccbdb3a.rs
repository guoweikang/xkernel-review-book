fn block_device_fallocate_validates_mode_capacity_and_alignment() {
    const BLOCK_SIZE: usize = 512;
    const BLOCKS: usize = 8;
    use FallocateFlags as F;

    let capacity = (BLOCK_SIZE * BLOCKS) as u64;

    let backend = Arc::new(MemoryBlockDevice {
        storage: Arc::new(Mutex::new(vec![0x35u8; BLOCK_SIZE * BLOCKS])),
        block_size: BLOCK_SIZE,
        flushes: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        reads: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        writes: Arc::new(core::sync::atomic::AtomicUsize::new(0)),
        fail_io: Arc::new(core::sync::atomic::AtomicBool::new(false)),
        fail_after_write_bytes: core::sync::atomic::AtomicUsize::new(usize::MAX),
    });
    let disk = block::Gendisk::alloc(
        String::from("kvfs-fallocate-test"),
        246,
        0,
        1,
        Box::new(backend.clone()),
    )
    .expect("valid fallocate test disk");
    let device = block::add_disk(disk).expect("publish fallocate test disk");
    let rdev = device.disk().device_number();
    let (file, _stat_path) = open_block_device_file(rdev).expect("open fallocate test device");

    // Aligned ZERO_RANGE zeroes exactly the range and nothing else.
    file.fallocate(F::ZERO_RANGE, 512, 1024)
        .expect("aligned zero range");
    {
        let storage = backend.storage.lock();
        assert!(storage[..512].iter().all(|&b| b == 0x35));
        assert!(storage[512..1536].iter().all(|&b| b == 0));
        assert!(storage[1536..].iter().all(|&b| b == 0x35));
    }

    // Unaligned ranges are rejected before any media write (Linux
    // blkdev_fallocate requires logical-block alignment).
    let before = backend.storage.lock().clone();
    assert_eq!(
        LinuxError::from(file.fallocate(F::ZERO_RANGE, 1, 1).unwrap_err()),
        LinuxError::EINVAL
    );
    // A KEEP_SIZE clamp only tolerates the capacity's partial trailing
    // block: an unaligned start is EINVAL regardless of KEEP_SIZE, and an
    // unaligned length without an actual clamp is EINVAL, never a silent
    // floor.
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::ZERO_RANGE | F::KEEP_SIZE, 1, capacity)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::ZERO_RANGE | F::KEEP_SIZE, 0, 513)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );
    // Order matches blkdev_fallocate: alignment first — an unaligned punch
    // answers EINVAL — then the capability gate, where an aligned punch on
    // a backend without deallocation offload answers EOPNOTSUPP.
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::PUNCH_HOLE | F::KEEP_SIZE, 512, 511)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::PUNCH_HOLE | F::KEEP_SIZE, 512, 512)
                .unwrap_err()
        ),
        LinuxError::EOPNOTSUPP
    );
    assert_eq!(*backend.storage.lock(), before);

    // Ranges beyond the capacity need KEEP_SIZE (which clamps), else EINVAL.
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::ZERO_RANGE, capacity - 512, 4096)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );
    file.fallocate(F::ZERO_RANGE | F::KEEP_SIZE, capacity - 512, 4096)
    .expect("clamped keep-size range");
    {
        let storage = backend.storage.lock();
        assert!(storage[capacity as usize - 512..].iter().all(|&b| b == 0));
    }

    // Punch hole carries deallocation semantics (Linux passes
    // BLKDEV_ZERO_NOFALLBACK there): a plain read/write backend provides no
    // deallocation operation, so it must fail with EOPNOTSUPP and leave the
    // medium untouched instead of succeeding through a software zero-fill.
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::PUNCH_HOLE | F::KEEP_SIZE, 1536, 512)
                .unwrap_err()
        ),
        LinuxError::EOPNOTSUPP
    );
    assert!(backend.storage.lock()[1536..2048].iter().all(|&b| b == 0x35));

    // Unsupported modes fail without writing: pure allocate and any
    // unlisted flag combination are EOPNOTSUPP like blkdev_fallocate.
    assert_eq!(
        LinuxError::from(file.fallocate(F::empty(), 512, 512).unwrap_err()),
        LinuxError::EOPNOTSUPP
    );
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::COLLAPSE_RANGE, 512, 512)
                .unwrap_err()
        ),
        LinuxError::EOPNOTSUPP
    );
    {
        // Zeroed: [512,1536) by the aligned call and [3584,4096) by the
        // clamped keep-size call; the failed punch hole left [1536,2048)
        // pattern-filled.
        let storage = backend.storage.lock();
        assert!(storage[..512].iter().all(|&b| b == 0x35));
        assert!(storage[512..1536].iter().all(|&b| b == 0));
        assert!(storage[1536..3584].iter().all(|&b| b == 0x35));
        assert!(storage[3584..].iter().all(|&b| b == 0));
    }

    // A capacity that is not a multiple of the logical block size is the
    // only shape that reaches the KEEP_SIZE floor branch: the clamp leaves
    // a partial trailing block, which is floored to the aligned prefix
    // instead of failing the whole request.
    let fixture = BlockIoFixture::new(4096);
    fixture
        .device
        .set_capacity(9)
        .expect("resize to non-multiple capacity");
    let capacity = 9 * 512u64;
    let (file, _stat) = open_block_device_file(
        fixture.device.disk().device_number(),
    )
    .expect("open non-multiple test device");
    file.fallocate(F::ZERO_RANGE | F::KEEP_SIZE, 0, capacity + 1)
        .expect("floor to aligned prefix");
    {
        let storage = fixture.backend.storage.lock();
        assert!(storage[..4096].iter().all(|&b| b == 0));
        assert!(storage[4096..capacity as usize].iter().all(|&b| b == 0x35));
    }
    // When flooring leaves no full block, the request cannot be honored.
    assert_eq!(
        LinuxError::from(
            file.fallocate(F::ZERO_RANGE | F::KEEP_SIZE, 4096, 1024)
                .unwrap_err()
        ),
        LinuxError::EINVAL
    );
    assert!(fixture.backend.storage.lock()[4096..capacity as usize]
        .iter()
        .all(|&b| b == 0x35));

    block::del_gendisk(device.disk().device_number()).expect("remove fallocate test disk");
}