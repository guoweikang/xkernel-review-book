fn test_rmdir_uses_directory_removal_callback() {
    let root_operations = Arc::new(MockDirOps::new_removable(44));
    let root_inode = VfsInode::new_openable_dir(
        root_operations.clone(),
        inode_init(44, NodeType::Directory, 0),
    );
    let root = Dentry::new_dir_from_inode(root_inode, None, String::new());
    let (victim, _) = make_removable_dir_entry(45, Some(root.clone()), "victim");
    let (cached_child, _) =
        make_file_entry(Arc::new(MockFilesystem), 46, Some(victim.clone()), "cached");
    victim.insert_cache(String::from("cached"), cached_child.clone());
    root.insert_cache(String::from("victim"), victim.clone());

    root.rmdir("victim").unwrap();

    assert_eq!(root_operations.unlink_count.load(Ordering::Relaxed), 0);
    assert_eq!(root_operations.rmdir_count.load(Ordering::Relaxed), 1);
    assert!(root.lookup_cache("victim").is_none());
}