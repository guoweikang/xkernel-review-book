fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        let lookahead = input.lookahead1();
        if lookahead.peek(Ident) {
            let ident: Ident = input.parse()?;
            if ident == "cmd" {
                let _: Token![=] = input.parse()?;
                let cmd: LitInt = input.parse()?;
                Ok(DrmIoctlArgs::Raw { cmd })
            } else {
                let _: Token![,] = input.parse()?;
                let nr: LitInt = input.parse()?;
                Ok(DrmIoctlArgs::Formula { dir: ident, nr })
            }
        } else {
            Err(lookahead.error())
        }
    }