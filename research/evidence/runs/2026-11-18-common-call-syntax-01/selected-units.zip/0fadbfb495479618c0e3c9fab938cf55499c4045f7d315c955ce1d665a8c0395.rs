fn write(&self, _: &VfsFile, buf: &[u8], _: u64) -> VfsResult<usize> {
        if self.0.fetch_add(1, Ordering::Relaxed) != 0 {
            return Err(VfsError::IoWaitInterrupted);
        }
        assert!(buf.iter().all(|byte| *byte == 0x37));
        Ok(buf.len())
    }