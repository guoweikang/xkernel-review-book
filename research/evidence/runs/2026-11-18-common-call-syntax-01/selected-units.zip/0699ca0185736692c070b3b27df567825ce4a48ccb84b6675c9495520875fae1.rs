fn named_entry(device: DeviceId) -> Arc<ChrdevEntry> {
    let mut entry = ChrdevEntry::new(device, 1, Arc::new(Backend)).unwrap();
    entry.identity = Some(CharacterDeviceIdentity {
        name: String::from("registration_test"),
        class: String::from("test"),
    });
    Arc::new(entry)
}