fn try_call_once_error_allows_retry() {
    let once = Once::<u32>::new();

    let result = once.try_call_once(|| Err::<u32, &'static str>("retry"));
    assert_eq!(result, Err("retry"));
    assert!(!once.is_completed());
    assert!(once.get().is_none());
    assert!(once.poll().is_none());

    let value = once.call_once(|| 11);
    assert_eq!(*value, 11);
    assert!(once.is_completed());
}