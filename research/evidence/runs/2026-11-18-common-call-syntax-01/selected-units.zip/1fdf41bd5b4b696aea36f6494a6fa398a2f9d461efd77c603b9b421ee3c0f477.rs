fn on_miss(
        &mut self,
        index: PageIndex,
        request_pages: u64,
        history: impl FnOnce(u64) -> u64,
    ) -> (Range<PageIndex>, Option<PageIndex>) {
        let max = self.ra_pages;
        if max == 0 {
            return (index..index + 1, None);
        }
        let sequential = self.prev_pos_bytes.is_some_and(|pos| {
            index
                .checked_sub(pos / PAGE_SIZE_4K as u64)
                .is_some_and(|delta| delta <= 1)
        });
        if index == 0 || request_pages > max || sequential {
            self.start = index;
            self.size_pages = Self::initial_size(request_pages, max);
            self.async_size_pages = if self.size_pages > request_pages {
                self.size_pages - request_pages
            } else {
                self.size_pages / 2
            };
        } else {
            let mut contiguous = history(max);
            if contiguous <= request_pages {
                // A small random miss must not overwrite a sequential stream's history.
                return (index..index.saturating_add(request_pages.min(max)), None);
            }
            if contiguous == index {
                contiguous *= 2;
            }
            self.start = index;
            self.size_pages = contiguous.saturating_add(request_pages).min(max);
            self.async_size_pages = 1;
        }
        self.window()
    }