fn pump(
    len: usize,
    mut step: impl FnMut(&mut [u8], usize, usize) -> KResult<Step>,
) -> KResult<usize> {
    let mut buf = vec![0; 0x1000]; // 4KB intermediate buffer
    let mut total = 0;
    let mut remaining = len;
    let mut result = Ok(0);
    while remaining > 0 {
        let chunk = buf.len().min(remaining);
        match step(&mut buf, chunk, total) {
            Ok(Step::Eof) => break,
            Ok(Step::Data { confirmed, stop }) => {
                total += confirmed;
                remaining -= confirmed;
                result = Ok(total);
                if stop || confirmed == 0 {
                    break;
                }
            }
            Err(error) => {
                result = if total > 0 { Ok(total) } else { Err(error) };
                break;
            }
        }
    }
    result
}