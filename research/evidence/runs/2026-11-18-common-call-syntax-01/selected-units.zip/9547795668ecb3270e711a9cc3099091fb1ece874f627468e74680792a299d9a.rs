fn new(block_size: usize) -> Self {
        use core::sync::atomic::{AtomicBool, AtomicUsize};
        let backend = Arc::new(MemoryBlockDevice {
            storage: Arc::new(Mutex::new(vec![0x35; block_size * 8])),
            block_size,
            flushes: Arc::new(AtomicUsize::new(0)),
            reads: Arc::new(AtomicUsize::new(0)),
            writes: Arc::new(AtomicUsize::new(0)),
            fail_io: Arc::new(AtomicBool::new(false)),
            fail_after_write_bytes: AtomicUsize::new(usize::MAX),
        });
        let disk = block::Gendisk::alloc(
            String::from("kvfs-extent-test"),
            244,
            0,
            1,
            Box::new(backend.clone()),
        )
        .expect("valid extent test disk");
        let device = block::add_disk(disk).expect("publish extent test disk");
        Self { device, backend }
    }