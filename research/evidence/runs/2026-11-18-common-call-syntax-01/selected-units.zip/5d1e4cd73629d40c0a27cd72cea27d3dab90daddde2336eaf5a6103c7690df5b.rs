fn finish_initialization(&self) {
        assert!(
            self.ops.get().is_some()
                && self.root.get().is_some()
                && self.block_size.get().is_some()
                && self.max_file_size.get().is_some()
                && self.timestamp_limits.get().is_some(),
            "fill_super must install operations, capabilities, and a root"
        );
        let mut lifecycle = self.lifecycle.lock();
        assert!(
            matches!(*lifecycle, SuperBlockLifecycle::Nascent),
            "only a nascent superblock can finish initialization"
        );
        *lifecycle = SuperBlockLifecycle::Available { active_mounts: 0 };
        drop(lifecycle);
        self.lifecycle_waiters.notify_all(false);
    }