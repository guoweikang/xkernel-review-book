fn starts(&self) -> (u64, u64) {
        match self {
            PairPositions::Distinct { input, output } => (input.start(), output.start()),
            PairPositions::Shared(slot) => {
                let start = slot.start();
                (start, start)
            }
        }
    }