fn dir_inode(inode: u64, nlink: u64) -> Arc<VfsInode> {
    VfsInode::new_openable_dir_with_flags(
        Arc::new(TestOps::new(inode, NodeType::Directory, nlink)),
        NodeFlags::empty(),
        init(inode, NodeType::Directory, nlink),
    )
}