fn make_file_entry(
    fs: Arc<MockFilesystem>,
    inode: u64,
    parent: Option<Dentry>,
    name: &str,
) -> (Dentry, Arc<MockFileOps>) {
    let ops = Arc::new(MockFileOps::new(fs, inode, b"payload"));
    let inode = VfsInode::new_file(
        ops.clone(),
        inode_init(inode, NodeType::RegularFile, b"payload".len() as u64),
    );
    let entry = Dentry::new_file_from_inode(inode, parent, String::from(name));
    (entry, ops)
}