fn iterate_shared(&self, file: &VfsFile, ctx: &mut DirContext<'_>) -> VfsResult<usize> {
        let dentry = file.path().dentry();
        let entries = [
            (DOT, NULLFS_ROOT_INO),
            (
                DOTDOT,
                dentry
                    .parent()
                    .map_or(NULLFS_ROOT_INO, |parent| parent.metadata().inode),
            ),
        ];

        let mut count = 0;
        for (index, (name, inode)) in entries.into_iter().enumerate().skip(ctx.pos() as usize) {
            if !ctx.emit(name, inode, NodeType::Directory, index as u64 + 1) {
                break;
            }
            count += 1;
        }
        Ok(count)
    }