fn add_child(
        &mut self,
        name: impl Into<String>,
        factory: impl for<'a, 'b> Fn(SimpleDirLookup<'a>, &'b str) -> VfsResult<Dentry>
        + Send
        + Sync
        + 'static,
    ) {
        self.entries.lock().insert(
            name.into(),
            Arc::new(move |parent, name| {
                let parent = parent.as_ref().ok_or(VfsError::InvalidInput)?;
                factory(SimpleDirLookup::new(parent), name)
            }),
        );
    }