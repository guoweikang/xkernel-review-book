fn walk_path_component(
        &mut self,
        last_type: LastType,
        name: &str,
        walk_component: WalkComponent,
        cred: &Cred,
    ) -> VfsResult<()> {
        if last_type == LastType::Norm {
            self.last_type = LastType::Norm;
            return match walk_component {
                WalkComponent::More => self.walk_component(name, WalkComponent::More, cred),
                WalkComponent::Final => {
                    self.hash_name(name);
                    Ok(())
                }
            };
        }
        self.last_type = last_type;
        self.hash_name(name);
        if walk_component == WalkComponent::More {
            self.handle_dots(last_type);
        }
        Ok(())
    }