fn test_rename_noreplace_rejects_target_with_source_inode() {
    let fs = Arc::new(MockFilesystem);
    let root = make_renamable_dir_entry(69, None, "");
    let (source, _) = make_file_entry(fs, 70, Some(root.clone()), "tmp");
    let target = Dentry::new_file_from_inode(
        source.vfs_inode(),
        Some(root.clone()),
        String::from("final"),
    );

    root.insert_cache(String::from("tmp"), source.clone());
    root.insert_cache(String::from("final"), target.clone());

    assert_eq!(
        root.rename("tmp", &root, "final", RenameFlags::NOREPLACE),
        Err(VfsError::AlreadyExists)
    );
    assert!(root.lookup_cache("tmp").unwrap().ptr_eq(&source));
    assert!(root.lookup_cache("final").unwrap().ptr_eq(&target));
}