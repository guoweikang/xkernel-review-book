fn follow_magic_link(&mut self, link: Path) -> VfsResult<Path> {
        let Some(mut magic_link) = d_inode(link.dentry()).magic_link() else {
            return Ok(link);
        };

        loop {
            self.reserve_link_follow()?;
            let resolved =
                magic_link.follow(self.intent, self.flags | LookupFlags::FOLLOW_FINAL)?;
            match resolved {
                ResolvedObject::Path(location) => return Ok(location),
                ResolvedObject::MagicLink(next) => magic_link = next,
            }
        }
    }