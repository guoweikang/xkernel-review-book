fn test_replace_lookup_candidate_preserves_replacer() {
    let fs = Arc::new(MockFilesystem);
    let dir = make_dir_entry(fs.clone(), 2, "dir");
    let sb = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        dir.clone()
    });

    // Simulate the concurrent-replacement window: the children slot
    // already holds another thread's candidate, so a stale replace must
    // not clobber it.
    let other = Dentry::new_negative(Some(dir.clone()), String::from("x"));
    dir.0
        .children
        .lock()
        .insert("x".into(), Arc::downgrade(&other.0));

    let candidate = Dentry::new_negative(Some(dir.clone()), String::from("x"));
    let (entry, _) = make_file_entry(fs, 3, Some(dir.clone()), "x");
    dir.replace_lookup_candidate("x", &candidate, &entry);

    // The children slot keeps the replacer; only the dcache key is
    // (defensively) refreshed with our entry.
    let cached = dir.0.children.lock().get("x").unwrap().upgrade().unwrap();
    assert!(Arc::ptr_eq(&cached, &other.0));
    assert!(sb.is_dentry_cached(&entry));
}