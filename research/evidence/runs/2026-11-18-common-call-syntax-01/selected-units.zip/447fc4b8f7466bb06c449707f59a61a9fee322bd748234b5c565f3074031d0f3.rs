fn from_access_mode(access_mode: u32) -> Self {
        match access_mode {
            O_RDONLY => Self(Permission::MAY_READ),
            O_WRONLY => Self(Permission::MAY_WRITE),
            O_RDWR => Self(Permission::MAY_READ | Permission::MAY_WRITE),
            _ => Self(Permission::MAY_READ | Permission::MAY_WRITE),
        }
    }