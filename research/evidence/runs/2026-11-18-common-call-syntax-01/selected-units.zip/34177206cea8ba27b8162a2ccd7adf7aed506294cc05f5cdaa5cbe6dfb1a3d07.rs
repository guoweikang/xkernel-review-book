fn splice_retains_rejected_and_short_written_data() {
    let pipe = PipeObject::new_anonymous();
    pipe.write(true, true, b"abcdef").unwrap();
    let mut scratch = [0; 6];
    assert_eq!(
        pipe.splice_read(true, &mut scratch, |_| Err(KError::IoWaitInterrupted)),
        Err(KError::IoWaitInterrupted)
    );
    assert_eq!(
        pipe.splice_read(true, &mut scratch, |bytes| {
            assert_eq!(bytes, b"abcdef");
            Ok(2)
        }),
        Ok(2)
    );
    let mut remaining = [0; 6];
    assert_eq!(pipe.read(true, &mut remaining), Ok(4));
    assert_eq!(&remaining[..4], b"cdef");
}