fn file_inode(inode: u64, nlink: u64) -> Arc<VfsInode> {
    let ops = Arc::new(TestOps::new(inode, NodeType::RegularFile, nlink));
    let i_private: Arc<dyn Any + Send + Sync> = ops.clone();
    let inode_operations: Arc<dyn InodeOperations> = ops.clone();
    let file_operations: Arc<dyn FileOperations> = ops;
    VfsInode::new_file_with_operations(
        i_private,
        inode_operations,
        file_operations,
        NodeFlags::empty(),
        init(inode, NodeType::RegularFile, nlink),
    )
}