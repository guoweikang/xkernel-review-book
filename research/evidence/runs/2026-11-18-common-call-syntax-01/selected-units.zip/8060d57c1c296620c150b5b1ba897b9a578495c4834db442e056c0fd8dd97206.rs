fn wait_interruptible(&self) -> KResult<()> {
        block_on_interruptible(poll_fn(|cx| self.poll_wait(cx.waker()))).map_err(
            |error| -> KError {
                if error.is_task_interrupt() {
                    LinuxError::ERESTARTSYS.into()
                } else {
                    error.into()
                }
            },
        )
    }