fn update_metadata(&self, dentry: &Dentry, mut update: MetadataUpdate) -> VfsResult<()> {
        let changed = update.size.is_some()
            || update.mode.is_some()
            || update.owner.is_some()
            || update.atime.is_some()
            || update.mtime.is_some();
        update.atime = update.atime.map(|time| self.truncate_timestamp(time));
        update.mtime = update.mtime.map(|time| self.truncate_timestamp(time));
        update.ctime = update.ctime.map(|time| self.truncate_timestamp(time));
        if changed && update.ctime.is_none() {
            update.ctime = Some(self.current_time());
        }
        let applied = self
            .inode_operations
            .as_ref()
            .setattr(&MountIdmap, dentry, update)?;
        if let Some(size) = applied.size {
            self.update_size_after_backing_change(size)?;
        }
        if let Some(atime) = applied.atime {
            self.set_accessed_at(atime);
        }
        if let Some(mtime) = applied.mtime {
            self.set_modified_at(mtime);
        }
        if let Some(ctime) = applied.ctime {
            self.set_changed_at(ctime);
        }
        if let Some(mode) = applied.mode {
            self.attributes.set_permission(mode);
        }
        if let Some((uid, gid)) = applied.owner {
            self.attributes.set_owner(uid, gid);
        }
        Ok(())
    }