fn invalidate_mappings_from(&self, object_start: u64) {
        let mut hits = Vec::new();
        let mut notifiers = Vec::new();
        let mut object_end = object_start;
        for registered in self.views.lock().values() {
            if registered.view.object_end() <= object_start {
                continue;
            }
            let len =
                usize::try_from(registered.view.object_end() - object_start).unwrap_or(usize::MAX);
            let Some(hit) = registered.view.page_hit(object_start, len) else {
                continue;
            };
            object_end = object_end.max(hit.object_end());
            hits.push(hit.clone());
            if let Some(notifier) = &registered.notifier {
                notifiers.push((hit, notifier.clone()));
            }
        }
        if hits.is_empty() {
            return;
        }
        let len = usize::try_from(object_end - object_start).unwrap_or(usize::MAX);
        let work = ObjectInvalidateWork::new(self.object_id, object_start, len, hits);
        for (hit, notifier) in notifiers {
            notifier.invalidate(&work, &hit);
        }
    }