fn splice_rejects_oversized_read_without_publishing_data() {
    for reported in [4, usize::MAX] {
        let pipe = PipeObject::new_anonymous();
        pipe.resize(PIPE_BUF).unwrap();
        let original = vec![1; PIPE_BUF - 3];
        pipe.write(true, true, &original).unwrap();
        let mut scratch = [0; 8];
        assert_eq!(
            pipe.splice_write(true, &mut scratch, |bytes| {
                assert_eq!(bytes.len(), 3);
                bytes.fill(2);
                Ok(reported)
            }),
            Err(KError::Io)
        );
        let mut remaining = vec![0; PIPE_BUF];
        assert_eq!(pipe.read(true, &mut remaining), Ok(original.len()));
        assert_eq!(&remaining[..original.len()], original.as_slice());
        assert_eq!(pipe.read(true, &mut remaining), Err(KError::WouldBlock));
    }
}