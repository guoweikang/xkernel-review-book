fn test_cross_directory_rename_moves_source_dentry() {
    let fs = Arc::new(MockFilesystem);
    let root = make_renamable_dir_entry(49, None, "");
    let old_parent = make_renamable_dir_entry(50, Some(root.clone()), "old");
    let new_parent = make_renamable_dir_entry(51, Some(root.clone()), "new");
    let (source, _) = make_file_entry(fs, 52, Some(old_parent.clone()), "source");
    root.insert_cache(String::from("old"), old_parent.clone());
    root.insert_cache(String::from("new"), new_parent.clone());
    old_parent.insert_cache(String::from("source"), source.clone());
    let _super_block = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        root.clone()
    });

    old_parent
        .rename("source", &new_parent, "target", RenameFlags::empty())
        .unwrap();

    assert!(old_parent.lookup_cache("source").is_none());
    assert!(new_parent.lookup_cache("target").unwrap().ptr_eq(&source));
    assert_eq!(source.absolute_path().unwrap().as_str(), "/new/target");
}