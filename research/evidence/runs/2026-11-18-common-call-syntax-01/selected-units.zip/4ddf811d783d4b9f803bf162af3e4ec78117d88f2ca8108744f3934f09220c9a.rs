fn metadata() -> Metadata {
        Metadata {
            device: 0,
            inode: NULLFS_ROOT_INO,
            nlink: 2,
            mode: Umode::new(
                NodeType::Directory,
                NodePermission::from_bits_truncate(0o555),
            ),
            uid: 0,
            gid: 0,
            size: 0,
            block_size: NULLFS_BLOCK_SIZE,
            blocks: 0,
            rdev: Default::default(),
            atime: SystemTime::UNIX_EPOCH,
            mtime: SystemTime::UNIX_EPOCH,
            ctime: SystemTime::UNIX_EPOCH,
        }
    }