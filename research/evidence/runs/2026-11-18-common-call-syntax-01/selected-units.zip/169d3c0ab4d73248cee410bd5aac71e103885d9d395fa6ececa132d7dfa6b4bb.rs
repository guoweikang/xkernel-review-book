fn test_bind_super_block_skips_non_cacheable_children() {
    let fs = Arc::new(MockFilesystem);
    let (dir, _) = make_non_cacheable_dir(fs.clone(), 2, None, "dir");
    let sb = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        dir.clone()
    });
    let (child, _) = make_file_entry(fs.clone(), 3, Some(dir.clone()), "child");
    dir.0
        .children
        .lock()
        .insert("child".into(), Arc::downgrade(&child.0));

    dir.bind_super_block(&sb);
    assert!(!sb.is_dentry_cached(&child));

    // Control: a cacheable directory does publish its children.
    let cacheable = make_dir_entry(fs.clone(), 4, "cacheable");
    let sb2 = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        cacheable.clone()
    });
    let (child2, _) = make_file_entry(fs, 5, Some(cacheable.clone()), "child");
    cacheable
        .0
        .children
        .lock()
        .insert("child".into(), Arc::downgrade(&child2.0));

    cacheable.bind_super_block(&sb2);
    assert!(sb2.is_dentry_cached(&child2));
}