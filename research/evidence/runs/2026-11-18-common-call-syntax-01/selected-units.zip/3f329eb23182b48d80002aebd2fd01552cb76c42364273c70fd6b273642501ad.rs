fn writable_open_lifetime_updates_inode_write_count() {
    let tree = test_tree();
    let inode = tree.target.inode().clone();
    let file_ops = inode.downcast::<TestFile>().unwrap();

    let first = dentry_open(
        tree.target.clone(),
        OpenFlags::WRITE_ONLY.bits(),
        kcred::initial_cred(),
    )
    .unwrap();
    assert_eq!(inode.write_count(), 1);
    let second = dentry_open(
        tree.target.clone(),
        OpenFlags::WRITE_ONLY.bits(),
        kcred::initial_cred(),
    )
    .unwrap();
    assert_eq!(inode.write_count(), 2);

    drop(first);
    assert_eq!(inode.write_count(), 1);
    {
        let release_write_counts = file_ops.release_write_counts.lock();
        assert_eq!(release_write_counts.as_slice(), &[2]);
    }
    drop(second);
    assert_eq!(inode.write_count(), 0);
    let release_write_counts = file_ops.release_write_counts.lock();
    assert_eq!(release_write_counts.as_slice(), &[2, 1]);
}