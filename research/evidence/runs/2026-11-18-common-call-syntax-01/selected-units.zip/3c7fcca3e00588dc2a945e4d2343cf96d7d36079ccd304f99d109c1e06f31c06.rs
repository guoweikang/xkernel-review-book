fn install_child_mount(&self, mountpoint: &Dentry, mount: &Arc<Self>) -> Option<Arc<Self>> {
        self.mnt_mounts
            .lock()
            .insert(mountpoint.key(), Arc::downgrade(mount))
            .and_then(|old| old.upgrade())
    }