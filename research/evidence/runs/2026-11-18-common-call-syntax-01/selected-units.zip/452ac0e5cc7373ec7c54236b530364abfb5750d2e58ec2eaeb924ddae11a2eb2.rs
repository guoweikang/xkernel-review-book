fn swap_locations(left: &Dentry, right: &Dentry) {
        if left.as_ptr() < right.as_ptr() {
            let mut left_location = left.0.location.write();
            let mut right_location = right.0.location.write();
            mem::swap(&mut *left_location, &mut *right_location);
        } else {
            let mut right_location = right.0.location.write();
            let mut left_location = left.0.location.write();
            mem::swap(&mut *left_location, &mut *right_location);
        }
    }