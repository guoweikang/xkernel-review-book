fn forget(&self) {
        let children = mem::take(&mut *self.0.children.lock());
        for child in children
            .into_values()
            .filter_map(|entry| entry.upgrade().map(Dentry))
        {
            if child.is_really_positive()
                && let Ok(dir) = child.as_dir()
            {
                dir.forget();
            }
            if let Some(super_block) = child.super_block() {
                super_block.uncache_dentry(&child);
            }
        }
    }