fn symlink(
        &self,
        _idmap: &crate::MountIdmap,
        dir: &VfsInode,
        dentry: &LockedDentry<'_>,
        target: &str,
        cred: &kcred::Cred,
    ) -> VfsResult<()> {
        let parent = dentry.parent().ok_or(VfsError::InvalidInput)?;
        let (mode, uid, gid) = inode_init_owner(
            dir,
            Umode::new(NodeType::Symlink, NodePermission::from_bits_truncate(0o777)),
            cred,
        );
        let node = Arc::new(SimpleFsNode::new_with_owner(
            self.dir.node.filesystem(),
            NodeType::Symlink,
            mode.permission(),
            uid,
            gid,
        ));
        node.metadata.lock().size = target.len() as u64;
        let init = node.inode_init();
        let inode = VfsInode::new_cached_symlink(node, NodeFlags::empty(), init, target.to_owned());
        let entry =
            self.dir
                .ops
                .create_inode_child(SimpleDirLookup::new(&parent), dentry.name(), inode)?;
        let inode = entry.vfs_inode();
        drop(entry);
        dentry.instantiate(inode)
    }