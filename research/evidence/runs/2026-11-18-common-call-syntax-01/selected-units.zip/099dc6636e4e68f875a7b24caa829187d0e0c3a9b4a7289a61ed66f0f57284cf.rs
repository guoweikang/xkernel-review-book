fn validates_xattr_names() {
    assert_eq!(
        XattrName::new(vec![b'a'; super::XATTR_NAME_MAX])
            .unwrap()
            .as_bytes()
            .len(),
        super::XATTR_NAME_MAX
    );
    assert!(matches!(
        XattrName::new(vec![b'a'; super::XATTR_NAME_MAX + 1]),
        Err(err) if LinuxError::from(err) == LinuxError::ERANGE
    ));
    assert!(matches!(
        XattrName::new(vec![]),
        Err(err) if LinuxError::from(err) == LinuxError::ERANGE
    ));

    let split = XattrNameRef::from_parts(b"trusted.", b"test").unwrap();
    assert_eq!(split.encoded_len(), b"trusted.test".len());
    assert!(split.is_trusted());
    assert!(matches!(
        XattrNameRef::from_parts(b"user.", b"bad\0name"),
        Err(err) if LinuxError::from(err) == LinuxError::ERANGE
    ));
}