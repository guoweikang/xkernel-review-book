fn superblock_separates_operations_from_private_state() {
    let super_block = SuperBlock::try_new_with_flags_and_private(
        &TEST_FILE_SYSTEM_TYPE,
        &TEST_SUPER_OPERATIONS,
        kalloc_types::KBox::new(TestPrivate(0x5f5f_494e_464f)).unwrap(),
        SuperBlockFlags::NOATIME,
        4096,
        1 << 30,
        |_| {
            let inode = VfsInode::new_dir_with_defaults(
                NodeFlags::empty(),
                VfsInodeInit::new(
                    2,
                    0,
                    Umode::new(NodeType::Directory, NodePermission::default()),
                ),
            );
            Ok::<_, crate::VfsError>(Dentry::new_dir_from_inode(inode, None, String::new()))
        },
    )
    .expect("construct superblock with private state");

    assert_eq!(super_block.block_size(), 4096);
    assert_eq!(super_block.max_file_size(), 1 << 30);
    assert!(super_block.private::<TestSuperOperations>().is_err());
    assert!(super_block.stat().is_ok());
    super_block.mark_read_only();
    super_block.mark_read_only();
    assert_eq!(
        super_block.flags(),
        SuperBlockFlags::NOATIME | SuperBlockFlags::RDONLY
    );
}