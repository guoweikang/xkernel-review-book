fn failed_try_lock_restores_state() {
    let m = TestSpinIrq::new(());
    let a = m.lock();
    assert_eq!(IRQ_CNT.load(Ordering::Relaxed), 1);

    let b = m.try_lock();
    assert!(b.is_none());
    assert_eq!(IRQ_CNT.load(Ordering::Relaxed), 1);

    drop(a);
    assert_eq!(IRQ_CNT.load(Ordering::Relaxed), 0);
}