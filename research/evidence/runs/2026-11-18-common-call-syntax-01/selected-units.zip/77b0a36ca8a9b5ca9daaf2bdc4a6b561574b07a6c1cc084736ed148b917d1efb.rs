fn block_open_mode(mode: FMode, flags: crate::OpenFlags) -> BlockOpenMode {
    let mut block_mode = BlockOpenMode::empty();
    if mode.contains(FMode::READ) {
        block_mode.insert(BlockOpenMode::READ);
    }
    if mode.contains(FMode::WRITE) {
        block_mode.insert(BlockOpenMode::WRITE);
    }
    block_mode.set(
        BlockOpenMode::EXCLUSIVE,
        flags.contains(crate::OpenFlags::EXCLUSIVE),
    );
    block_mode.set(
        BlockOpenMode::NONBLOCK,
        flags.contains(crate::OpenFlags::NONBLOCK),
    );
    // Linux file_to_blk_mode() preserves ioctl-only access mode 3.
    block_mode.set(
        BlockOpenMode::WRITE_IOCTL,
        flags.contains(crate::OpenFlags::READ_WRITE | crate::OpenFlags::WRITE_ONLY),
    );
    block_mode
}