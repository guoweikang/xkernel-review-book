fn render_from(&self, root: &Self) -> VfsResult<RenderedPath> {
        let (is_reachable, components) = self.render_components(Some(root))?;
        let path = Self::components_to_path(&components);
        Ok(if is_reachable {
            RenderedPath::Reachable(path)
        } else {
            RenderedPath::Unreachable(path)
        })
    }