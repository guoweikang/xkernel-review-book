fn remove_access(state: &mut PipeState, access: PipeAccess) -> (bool, bool) {
    let readers_became_zero = if access.can_read() {
        assert!(state.readers > 0, "pipe reader count underflow");
        state.readers -= 1;
        state.readers == 0
    } else {
        false
    };
    let writers_became_zero = if access.can_write() {
        assert!(state.writers > 0, "pipe writer count underflow");
        state.writers -= 1;
        state.writers == 0
    } else {
        false
    };
    let peers_remain = state.readers != 0 || state.writers != 0;
    let wake_both = peers_remain && (readers_became_zero || writers_became_zero);
    (wake_both, wake_both)
}