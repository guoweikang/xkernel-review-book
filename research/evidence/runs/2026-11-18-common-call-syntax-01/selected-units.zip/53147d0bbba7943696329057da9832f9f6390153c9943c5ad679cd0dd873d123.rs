fn buffered_read_resolves_pages_removed_during_copy() {
    let inode = read_inode(&READ_OPS, PAGE_SIZE_4K * 3);
    let mapping = inode.address_space();
    for index in 0..3 {
        mapping
            .with_folio_or_create(index, |folio| {
                folio.data().fill(0x99);
                Ok(())
            })
            .expect("populate resident pages");
    }
    let mut sink = InvalidatingSink {
        mapping: &mapping,
        output: Vec::new(),
        truncate: false,
    };
    let mut iter = iov_iter_dest(&mut sink);
    assert_eq!(
        mapping.read_from_page_cache(&mut iter, 0),
        Ok(PAGE_SIZE_4K * 3)
    );
    assert!(sink.output[..PAGE_SIZE_4K].iter().all(|byte| *byte == 0x99));
    assert!(
        sink.output[PAGE_SIZE_4K..PAGE_SIZE_4K * 2]
            .iter()
            .all(|byte| *byte == 1)
    );
    assert!(
        sink.output[PAGE_SIZE_4K * 2..]
            .iter()
            .all(|byte| *byte == 2)
    );
}