fn dying_superblock_wakes_waiter_after_shutdown() {
    reset_transition_test_state();
    let (disk, block_device) = add_test_disk("kvfs-dying-wait", 251);
    let super_block = super_block_registry()
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device.clone(),
            SuperBlockFlags::empty(),
            fill_blocking_shutdown_bdev,
        )
        .expect("mount device before blocking shutdown");
    super_block.activate_mount();

    let shutting_down = super_block.clone();
    let shutdown = ktask::spawn(move || shutting_down.deactivate_mount());
    TRANSITION_WAITERS.wait_until(|| TRANSITION_STAGE.load(Ordering::Acquire) == 1);

    let waiter = spawn_successful_waiting_mount(block_device);
    TRANSITION_WAITERS.wait_until(|| TRANSITION_WAITER_STARTED.load(Ordering::Acquire) == 1);
    ktask::yield_now();
    assert_eq!(TRANSITION_WAITER_DONE.load(Ordering::Acquire), 0);

    TRANSITION_STAGE.store(2, Ordering::Release);
    TRANSITION_WAITERS.notify_all(true);
    shutdown.join();
    waiter.join();

    assert_eq!(TRANSITION_WAITER_DONE.load(Ordering::Acquire), 1);
    assert_eq!(FILL_COUNT.load(Ordering::Relaxed), 2);
    block::del_gendisk(disk.device_number()).expect("remove dying-wait test disk");
}