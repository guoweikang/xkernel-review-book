fn create_operations_preserve_trailing_slash_policy() {
    let tree = test_tree();

    let err = Filename::new("/missing/")
        .symlink_at(&tree.root, &tree.base, "target", &kcred::initial_cred())
        .unwrap_err();
    assert_eq!(err, VfsError::NotFound);

    let created = Filename::new("/missing/")
        .mkdir_at(
            &tree.root,
            &tree.base,
            NodePermission::default(),
            NodePermission::empty(),
            &kcred::initial_cred(),
        )
        .unwrap();
    assert!(created.parent().unwrap().ptr_eq(&tree.root));
    assert_eq!(created.name(), "missing");
}