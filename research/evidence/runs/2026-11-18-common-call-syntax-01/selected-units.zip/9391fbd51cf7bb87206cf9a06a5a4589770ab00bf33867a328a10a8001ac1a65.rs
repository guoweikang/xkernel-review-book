fn test_reconfigure_rw_rejects_backend_readonly_superblock() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let child_fs = mock_filesystem(StatFsFlags::RDONLY);
    let namespace = MntNamespace::new_root(&root_fs, kcred::initial_user_namespace());
    let root = namespace.root_path();
    let mountpoint = lookup_child_in_mount(&root, "mnt").unwrap();
    let child = namespace.attach(&mountpoint, &child_fs).unwrap();
    let cred = kcred::initial_cred();
    let mut writable_context = FsContext::new_reconfigure(
        child_fs.as_ref(),
        None,
        None,
        SuperBlockFlags::empty(),
        SuperBlockFlags::RDONLY,
        &cred,
    )
    .unwrap();

    assert_eq!(
        namespace.remount(
            &child.root_path(),
            &mut writable_context,
            MountFlags::empty()
        ),
        Err(VfsError::ReadOnlyFilesystem)
    );
}