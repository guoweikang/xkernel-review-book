fn command_file_consumes_each_write_independently_of_offset() {
    let commands = Arc::new(crate::Mutex::new(Vec::<Vec<u8>>::new()));
    let observed = commands.clone();
    let super_block = SimpleFs::new_with(&TEST_FILE_SYSTEM_TYPE, 0, move |fs| {
        let mut root = DirMapping::new();
        root.add(
            "command",
            SimpleFile::new_regular_with_permission(
                fs.clone(),
                NodePermission::from_bits_truncate(0o222),
                CommandFile::new(move |operation| match operation {
                    SimpleFileOperation::Read => Ok(Some(Vec::new())),
                    SimpleFileOperation::Write { data, .. } => {
                        observed.lock().push(data.to_vec());
                        Ok(None)
                    }
                }),
            ),
        );
        SimpleDir::new_maker(fs, Arc::new(root))
    })
    .unwrap();
    let root = Mount::new_root(&super_block).root_path();
    let file = Filename::new("/command")
        .open_with_flags_at(
            &root,
            &root,
            linux_raw_sys::general::O_WRONLY,
            NodePermission::empty(),
            NodePermission::empty(),
            kcred::initial_cred(),
        )
        .unwrap();

    assert_eq!(file.write(b"first"), Ok(5));
    assert_eq!(file.position(), 5);
    assert_eq!(file.inode().size(), 0);
    assert_eq!(file.write(b""), Ok(0));
    assert_eq!(file.write(b"second"), Ok(6));
    let mut positioned_offset = 123;
    assert_eq!(
        file.write_from(b"positioned", &mut positioned_offset),
        Ok(10)
    );
    assert_eq!(positioned_offset, 133);
    assert_eq!(file.inode().size(), 0);
    assert_eq!(
        *commands.lock(),
        vec![
            b"first".to_vec(),
            b"second".to_vec(),
            b"positioned".to_vec()
        ]
    );
}