fn read_generated_bytes(data: &[u8], buf: &mut [u8], offset: u64) -> VfsResult<usize> {
    if offset >= data.len() as u64 {
        return Ok(0);
    }
    let data = &data[offset as usize..];
    let read = data.len().min(buf.len());
    buf[..read].copy_from_slice(&data[..read]);
    Ok(read)
}