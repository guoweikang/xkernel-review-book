fn finish(self) -> VfsResult<Arc<VfsFile>> {
        let Self {
            cred,
            mode,
            operations,
            location,
            private_data,
            flags,
            position,
            pipe_generation,
            created_under,
        } = self;

        let operations = operations.ok_or(VfsError::InvalidInput)?;
        let location = location.ok_or(VfsError::InvalidInput)?;
        let readahead = crate::file_ra::FileRaState::new(location.inode().readahead_pages());
        Ok(Arc::new(VfsFile {
            cred,
            mode: AtomicU32::new(mode.bits()),
            operations,
            location,
            private_data: Mutex::new(private_data),
            flags: AtomicU32::new(flags.bits()),
            position: Mutex::new(position),
            readahead: Mutex::new(readahead),
            pipe_generation,
            created_under,
        }))
    }