fn synchronous_readahead_publication_excludes_truncate() {
    use core::sync::atomic::{AtomicBool, Ordering};
    let gate = Arc::new(ReadGate {
        entered: AtomicBool::new(false),
        release: AtomicBool::new(false),
        events: ktask::WaitQueue::new(),
    });
    let inode = VfsInode::new_file_with_address_space(
        gate.clone(),
        &GATED_READ_OPS,
        VfsInodeInit::new(
            2,
            (PAGE_SIZE_4K * 2) as u64,
            Umode::new(NodeType::RegularFile, NodePermission::default()),
        ),
    );
    let reader_inode = inode.clone();
    let reader = ktask::spawn(move || {
        let mut output = vec![0; PAGE_SIZE_4K * 2];
        reader_inode
            .address_space()
            .read_from_page_cache(&mut iov_iter_kvec_dest(&mut output), 0)
            .expect("read completes");
    });
    gate.events
        .wait_until(|| gate.entered.load(Ordering::Acquire));
    let mapping = inode.address_space();
    let publication_excludes_truncate = mapping.invalidate_lock.try_write().is_none();
    let reserved = mapping.nrpages() == 2;
    gate.release.store(true, Ordering::Release);
    gate.events.notify_all(false);
    // This may start before or after initialization. Either ordering must leave
    // no late completion that can repopulate the discarded range.
    inode.set_len(17).unwrap();
    reader.join();
    assert!(publication_excludes_truncate);
    assert!(reserved);
    assert_eq!(mapping.nrpages(), 1);
    mapping
        .with_folio(0, |folio| {
            let folio = folio.unwrap();
            assert!(folio.data()[..17].iter().all(|&byte| byte == 0x5a));
            assert!(folio.data()[17..].iter().all(|&byte| byte == 0));
        })
        .unwrap();
}