fn prepared_private_owner_keeps_address_until_superblock_teardown() {
    let drops = Arc::new(AtomicUsize::new(0));
    let owner = kalloc_types::KBox::new(PrivateDropProbe(drops.clone())).unwrap();
    let address = core::ptr::from_ref(&*owner);
    let super_block = SuperBlock::new_with_flags_and_private(
        &TEST_FILE_SYSTEM_TYPE,
        &TEST_SUPER_OPERATIONS,
        owner,
        SuperBlockFlags::empty(),
        4096,
        MAX_LFS_FILESIZE,
        |_| {
            Dentry::new_dir_from_inode(
                VfsInode::new_dir_with_defaults(
                    NodeFlags::empty(),
                    VfsInodeInit::new(
                        1,
                        0,
                        Umode::new(NodeType::Directory, NodePermission::default()),
                    ),
                ),
                None,
                String::new(),
            )
        },
    );
    assert_eq!(
        core::ptr::from_ref(super_block.private::<PrivateDropProbe>().unwrap()),
        address,
    );
    assert_eq!(drops.load(Ordering::Relaxed), 0);
    drop(super_block);
    assert_eq!(drops.load(Ordering::Relaxed), 1);
}