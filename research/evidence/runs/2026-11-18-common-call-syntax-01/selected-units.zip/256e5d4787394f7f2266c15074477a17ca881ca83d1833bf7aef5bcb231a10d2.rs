fn mkdir(
        &self,
        _idmap: &crate::MountIdmap,
        dir: &VfsInode,
        dentry: &LockedDentry<'_>,
        mode: Umode,
        cred: &kcred::Cred,
    ) -> VfsResult<()> {
        let inode = self.dir.ops.mkdir(dir, dentry.name(), mode, cred)?;
        dentry.instantiate(inode)
    }