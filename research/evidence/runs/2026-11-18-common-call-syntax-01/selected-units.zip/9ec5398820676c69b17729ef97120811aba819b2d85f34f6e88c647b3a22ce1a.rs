fn test_completed_negative_lookup_remains_cacheable() {
    let fs = Arc::new(MockFilesystem);
    let dir = make_dir_entry(fs, 2, "dir");
    let candidate = Dentry::new_negative(Some(dir.clone()), String::from("missing"));
    candidate.begin_parallel_lookup();
    assert!(dir.cache_lookup_candidate("missing", &candidate).is_none());
    assert!(dir.lookup_cache_entry("missing").is_none());

    candidate.end_parallel_lookup();

    let found = dir.lookup_cache("missing").unwrap();
    assert!(found.ptr_eq(&candidate));
    assert!(found.is_negative());
}