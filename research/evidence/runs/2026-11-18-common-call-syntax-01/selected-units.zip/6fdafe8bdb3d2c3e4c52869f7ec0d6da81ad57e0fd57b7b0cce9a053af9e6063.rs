fn new(
        flags: DentryFlags,
        inode: Option<Arc<VfsInode>>,
        parent: Option<Dentry>,
        name: String,
    ) -> Self {
        let super_block = Once::new();
        let operations = Once::new();
        if let Some(parent_super_block) = parent.as_ref().and_then(Dentry::super_block) {
            if let Some(default_operations) = parent_super_block.default_dentry_operations() {
                operations.call_once(|| default_operations);
            }
            super_block.call_once(|| Arc::downgrade(&parent_super_block));
        }
        Self {
            flags: Mutex::new(flags),
            lookup_mutex: Mutex::default(),
            inode: Mutex::new(inode),
            location: RwLock::new(DentryLocation {
                parent,
                name,
                is_unlinked: false,
            }),
            operations,
            super_block,
            children: Mutex::default(),
        }
    }