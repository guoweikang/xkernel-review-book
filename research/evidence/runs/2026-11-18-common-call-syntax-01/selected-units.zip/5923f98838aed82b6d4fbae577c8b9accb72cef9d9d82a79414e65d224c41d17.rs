fn filesystem_attribute_operations_are_the_vfs_inode_state() {
    let node = Arc::new(TestChrdevInode::new(DeviceId::new(1, 3)));
    let init = VfsInodeInit::new(
        42,
        0,
        Umode::new(
            NodeType::CharacterDevice,
            NodePermission::from_bits_truncate(0o666),
        ),
    )
    .with_owner_links_and_rdev(0, 0, 1, DeviceId::new(1, 3));
    let inode = VfsInode::new_with_inode_attribute_operations(
        node.clone(),
        NodeFlags::NON_CACHEABLE,
        empty_address_space_operations(),
        init,
    );

    inode.set_link_count(5);
    inode.set_size(23);
    assert_eq!(node.metadata.lock().nlink, 5);
    assert_eq!(node.metadata.lock().size, 23);

    node.metadata.lock().uid = 1000;
    node.metadata.lock().size = 41;
    assert_eq!(inode.metadata().uid, 1000);
    assert_eq!(inode.size(), 41);
    assert_eq!(inode.generation(), 17);
}