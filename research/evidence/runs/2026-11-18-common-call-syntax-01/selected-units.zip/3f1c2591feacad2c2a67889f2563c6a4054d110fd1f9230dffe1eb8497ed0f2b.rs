fn test(&self, request: &FileLock) -> Option<FileLock> {
        let state = self.state.lock();
        state.posix.iter().find(|lock| {
            if request.kind == FileLockType::Unlock {
                request.owner == lock.owner && request.overlaps(lock)
            } else {
                request.conflicts_with(lock)
            }
        })
    }