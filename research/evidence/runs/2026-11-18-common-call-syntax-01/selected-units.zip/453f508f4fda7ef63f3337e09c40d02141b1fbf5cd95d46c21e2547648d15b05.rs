fn rename_with<F>(
        &self,
        src_name: &str,
        dst_dir: &Self,
        dst_name: &str,
        flags: RenameFlags,
        may_rename_fn: F,
    ) -> VfsResult<()>
    where
        F: FnOnce(&Dentry, &Dentry) -> VfsResult<()>,
    {
        if flags.has_conflicting_modes() {
            return Err(VfsError::InvalidInput);
        }
        self.as_dir()?;
        dst_dir.as_dir()?;
        Self::verify_child_name(src_name)?;
        Self::verify_child_name(dst_name)?;
        let supported_flags = RenameFlags::NOREPLACE | RenameFlags::EXCHANGE;
        if !supported_flags.contains(flags) {
            return Err(VfsError::InvalidInput);
        }
        RenameData {
            old_parent: self,
            old_name: src_name,
            new_parent: dst_dir,
            new_name: dst_name,
            flags,
        }
        .execute(may_rename_fn)
    }