fn add(&mut self, entry: &Arc<ChrdevEntry>) -> VfsResult<()> {
        // Named insertion is a cold publication path. A second live number
        // with the same class/name would collide in every filesystem view.
        if let Some(identity) = &entry.identity
            && self.entries.values().any(|existing| {
                existing
                    .identity
                    .as_ref()
                    .is_some_and(|other| other.matches(identity))
            })
        {
            return Err(VfsError::ResourceBusy);
        }
        let major = entry.first.major();
        if self
            .entries
            .range(..=(major, entry.last_minor))
            .next_back()
            .is_some_and(|(_, previous)| {
                previous.first.major() == major && previous.last_minor >= entry.first.minor()
            })
        {
            return Err(VfsError::ResourceBusy);
        }
        self.entries
            .insert((major, entry.first.minor()), entry.clone());
        Ok(())
    }