fn test_parallel_lookup_replacement_publishes_only_completed_entry() {
    let fs = Arc::new(MockFilesystem);
    let dir = make_dir_entry(fs.clone(), 2, "dir");
    let candidate = Dentry::new_negative(Some(dir.clone()), String::from("x"));
    let (child, _) = make_file_entry(fs, 3, Some(dir.clone()), "x");
    candidate.begin_parallel_lookup();
    assert!(dir.cache_lookup_candidate("x", &candidate).is_none());

    let observed = dir.lookup_cache_entry("x");
    dir.replace_lookup_candidate("x", &candidate, &child);
    candidate.end_parallel_lookup();

    assert!(observed.is_none());
    assert!(dir.lookup_cache("x").unwrap().ptr_eq(&child));
}