fn iterate_dir(&self, ctx: &mut DirContext<'_>) -> VfsResult<usize> {
        if self.inode().node_type() != NodeType::Directory {
            return Err(VfsError::NotADirectory);
        }
        self.verify_mode(FMode::READ)?;

        ctx.set_pos(self.position());
        let directory = self
            .operations()
            .dir_operations()
            .ok_or(VfsError::NotADirectory)?;
        let result = directory.iterate_shared(self, ctx);
        self.set_position(ctx.pos());
        result
    }