fn test_pivot_root_swaps_visible_root_and_relocates_old() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let new_root_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::build_initial_mount_tree(&root_fs).unwrap();
    let old_visible_root = namespace.visible_root_path();
    let old_root_mount = old_visible_root.mount().clone();
    let cred = kcred::initial_cred();

    // New root: a fresh filesystem mounted at a directory of the old root
    // (the OCI pattern mounts the container rootfs there and binds it).
    let mnt_dir = lookup_child_in_mount(&old_visible_root, "mnt").unwrap();
    let new_mnt = namespace.attach(&mnt_dir, &new_root_fs).unwrap();

    // put_old lives inside the new root's own filesystem (`/.pivot_root`).
    let put_old = new_mnt
        .root_path()
        .mkdir("oldroot", NodePermission::default(), &cred)
        .unwrap();

    namespace
        .pivot_root(
            &new_mnt.root_path(),
            &put_old,
            &namespace.visible_root_path(),
        )
        .unwrap();

    // `/` now resolves to the new root's filesystem.
    assert!(Arc::ptr_eq(namespace.visible_root_path().mount(), &new_mnt));
    // The old root is reachable at put_old, inside the new root.
    let relocated = lookup_child_in_mount(&new_mnt.root_path(), "oldroot")
        .unwrap()
        .resolve_final_mount();
    assert!(Arc::ptr_eq(relocated.mount(), &old_root_mount));
    // The structural root resolves through the new mount without gaps.
    assert!(Arc::ptr_eq(
        namespace.root_path().resolve_final_mount().mount(),
        &new_mnt
    ));
    assert!(!Arc::ptr_eq(
        namespace.visible_root_path().mount(),
        &old_root_mount
    ));
}