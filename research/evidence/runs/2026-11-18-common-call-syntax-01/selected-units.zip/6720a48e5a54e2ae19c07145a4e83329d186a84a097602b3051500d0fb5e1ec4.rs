fn nested_locks() {
    let arc = Arc::new(TestMutex::new(1));
    let arc2 = Arc::new(TestMutex::new(arc));

    // Single threaded nested lock test
    let lock = arc2.lock();
    let lock2 = lock.lock();
    assert_eq!(*lock2, 1);
}