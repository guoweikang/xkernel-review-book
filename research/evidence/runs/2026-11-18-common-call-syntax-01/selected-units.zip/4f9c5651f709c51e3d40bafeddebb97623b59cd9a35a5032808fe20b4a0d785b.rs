fn test_dentry_cache_retains_hashed_children_and_preserves_parent_lifetime() {
    let fs = Arc::new(MockFilesystem);
    let root = make_dir_entry(fs.clone(), 13, "");
    let _super_block = SuperBlock::new(&MOCK_FILE_SYSTEM_TYPE, &MOCK_SUPER_OPERATIONS, |_| {
        root.clone()
    });
    let cached = make_dir_entry_with_parent(fs.clone(), 14, Some(root.clone()), "cached");
    let cached_weak = Arc::downgrade(&cached.0);
    root.insert_cache(String::from("cached"), cached.clone());

    assert!(cached_weak.upgrade().is_some());
    assert!(root.lookup_cache("cached").is_some());
    drop(cached);
    assert!(cached_weak.upgrade().is_some());
    assert!(root.lookup_cache("cached").is_some());

    root.invalidate_cached_child("cached").unwrap();
    assert!(cached_weak.upgrade().is_none());

    let parent = make_dir_entry(fs.clone(), 15, "parent");
    let parent_weak = Arc::downgrade(&parent.0);
    let child = make_dir_entry_with_parent(fs, 16, Some(parent.clone()), "child");
    drop(parent);

    assert!(parent_weak.upgrade().is_some());
    assert!(child.parent().is_some());
    assert_eq!(child.absolute_path().unwrap().as_str(), "/parent/child");
}