fn test_writable_mount_allows_operations_to_reach_filesystem() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let mount = Mount::new_root(&fs);
    let root = mount.root_path();

    let result = root.create("test", NodePermission::default(), &kcred::initial_cred());
    assert!(result.is_err());
    assert_eq!(result.unwrap_err(), VfsError::OperationNotSupported);

    assert_eq!(
        root.unlink("test", &kcred::initial_cred()),
        Err(VfsError::NotFound)
    );
}