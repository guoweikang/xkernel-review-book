fn drop(&mut self) {
        self.remove_posix_locks(crate::FileLockOwner::ofd(self));
        let _ = self.operations().flock(
            self,
            &crate::FileLock::unlock(crate::FileLockOwner::flock(self)),
            false,
        );
        let old_mode = self.mode.fetch_and(!FMode::OPENED.bits(), Ordering::AcqRel);
        let old_mode = FMode::from_bits_truncate(old_mode);
        let release_result = if old_mode.contains(FMode::OPENED) {
            self.operations().release(self.inode(), self)
        } else {
            Ok(())
        };
        if old_mode.contains(FMode::WRITER) {
            self.inode().release_write_access();
        }

        if let Err(err) = release_result {
            let path = self
                .path()
                .display_path()
                .unwrap_or_else(|_| "<error>".into());
            warn!("failed to release VFS file {}: {err:?}", path);
        }
    }