fn test_pivot_root_rejects_plain_directory_new_root() {
    let root_fs = mock_filesystem(StatFsFlags::empty());
    let namespace = MntNamespace::build_initial_mount_tree(&root_fs).unwrap();
    let visible = namespace.visible_root_path();
    let cred = kcred::initial_cred();
    let plain_dir = visible
        .mkdir("plain", NodePermission::default(), &cred)
        .unwrap();
    let put_old = visible
        .mkdir("oldroot", NodePermission::default(), &cred)
        .unwrap();

    assert_eq!(
        namespace.pivot_root(&plain_dir, &put_old, &namespace.visible_root_path()),
        Err(VfsError::InvalidInput),
        "new_root must be a mount root"
    );
}