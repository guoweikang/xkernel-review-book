fn vfs_link(&self, candidate: &Dentry, source: &Self, cred: &Cred) -> VfsResult<()> {
        if !Arc::ptr_eq(&self.mnt, &source.mnt) {
            return Err(VfsError::CrossesDevices);
        }
        self.check_writable_mount()?;
        self.may_modify_directory(cred)?;
        if source.is_dir() {
            return Err(VfsError::OperationNotPermitted);
        }
        let source_inode = source.inode();
        let _source_guard = source_inode.lock_namespace_exclusive();
        self.inode().link(candidate, &source.dentry)
    }