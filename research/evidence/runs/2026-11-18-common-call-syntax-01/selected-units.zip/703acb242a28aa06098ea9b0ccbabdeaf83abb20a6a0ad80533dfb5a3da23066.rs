fn init(inode: u64, node_type: NodeType, nlink: u64) -> VfsInodeInit {
    let mode = match node_type {
        NodeType::Directory => NodePermission::from_bits_truncate(0o777),
        _ => NodePermission::default(),
    };
    VfsInodeInit::new(inode, 0, Umode::new(node_type, mode))
        .with_owner_links_and_rdev(0, 0, nlink, DeviceId::default())
        .with_stat_data(
            4096,
            0,
            SystemTime::UNIX_EPOCH,
            SystemTime::UNIX_EPOCH,
            SystemTime::UNIX_EPOCH,
        )
}