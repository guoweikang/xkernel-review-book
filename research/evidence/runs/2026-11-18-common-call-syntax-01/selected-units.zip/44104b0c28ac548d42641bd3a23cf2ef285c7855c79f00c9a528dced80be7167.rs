fn registered_mount_at<'a>(
        mounts: &HashMap<u64, Arc<Mount>>,
        target: &'a Path,
    ) -> VfsResult<&'a Arc<Mount>> {
        if !target.is_mount_root() {
            return Err(VfsError::InvalidInput);
        }

        let mount = target.mount();
        Self::require_mount(mounts, mount)?;
        Ok(mount)
    }