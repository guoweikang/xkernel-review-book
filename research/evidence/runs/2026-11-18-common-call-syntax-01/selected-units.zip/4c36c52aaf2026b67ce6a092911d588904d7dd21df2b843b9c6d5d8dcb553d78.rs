fn read_folio(&self, mapping: &AddressSpace, mut folio: FolioRead) -> VfsResult<()> {
        let inode = mapping.inode().ok_or(VfsError::InvalidInput)?;
        let data = inode.private::<MockFileOps>()?.data.lock();
        let start = folio
            .index()
            .checked_mul(PAGE_SIZE_4K as u64)
            .and_then(|offset| usize::try_from(offset).ok())
            .ok_or(VfsError::InvalidInput)?;
        if start >= data.len() {
            folio.data().fill(0);
            return folio.complete(Ok(()));
        }
        let buf = folio.data();
        let count = buf.len().min(data.len() - start);
        buf[..count].copy_from_slice(&data[start..start + count]);
        buf[count..].fill(0);
        folio.complete(Ok(()))
    }