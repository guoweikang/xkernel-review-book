fn readahead_completes_full_windows_across_batch_boundaries() {
    let window_bytes = 128 * 1024;
    for offset in [0, 1] {
        let inode = read_inode(&WINDOW_READ_OPS, window_bytes + PAGE_SIZE_4K);
        let mapping = inode.address_space();
        let _invalidate = mapping.invalidate_lock.read();
        let end = offset + window_bytes as u64;
        assert_eq!(
            mapping.sync_readahead(offset, window_bytes, inode.size()),
            end
        );
        let pages = end.div_ceil(PAGE_SIZE_4K as u64);
        assert_eq!(mapping.nrpages(), pages);
        for index in 0..pages {
            mapping
                .with_folio(index, |folio| {
                    assert!(
                        folio
                            .expect("window tail must be initialized before demand read")
                            .data()
                            .iter()
                            .all(|&byte| byte == index as u8)
                    );
                })
                .unwrap();
        }
    }
}