fn sync_test_file(operations: Arc<dyn FileOperations>, mode: FMode) -> Arc<VfsFile> {
    let super_block = crate::nullfs::new_superblock();
    let mount = crate::Mount::new_root(&super_block);
    let inode = VfsInode::new_file_with_operations(
        Arc::new(()),
        Arc::new(TestInodeOperations),
        operations.clone(),
        NodeFlags::PRIVATE,
        crate::VfsInodeInit::new(
            2,
            0,
            crate::Umode::new(NodeType::RegularFile, crate::NodePermission::default()),
        ),
    );
    let dentry = crate::Dentry::new_file_from_inode(inode, None, "sync-test".into());
    dentry.bind_super_block(&super_block);
    VfsFileBuilder::from_path_state(
        crate::Path::new(mount, dentry),
        mode,
        OpenFlags::empty(),
        operations,
        kcred::initial_cred(),
    )
    .finish()
    .unwrap()
}