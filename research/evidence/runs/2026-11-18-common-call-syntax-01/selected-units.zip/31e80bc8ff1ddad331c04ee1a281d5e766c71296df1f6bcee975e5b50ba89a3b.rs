fn add_test_disk(name: &str, major: u32) -> (block::GendiskRef, Arc<block::BlockDevice>) {
    let disk = block::Gendisk::alloc(String::from(name), major, 0, 1, Box::new(TestBlockDevice))
        .expect("valid superblock test disk");
    let block_device = block::add_disk(disk.clone()).expect("publish superblock test disk");
    (disk, block_device)
}