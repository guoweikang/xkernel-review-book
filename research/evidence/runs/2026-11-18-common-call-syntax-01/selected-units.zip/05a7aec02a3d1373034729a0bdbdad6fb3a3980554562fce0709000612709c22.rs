fn list_xattrs(&self, cred: &Cred, sink: &mut dyn XattrNameSink) -> VfsResult<()> {
        let inode = self.inode();
        let mut filtering_sink = CredentialFilteringSink {
            inner: sink,
            can_read_trusted: cred.has_sys_admin(),
        };
        inode.list_xattrs(self.dentry(), &mut filtering_sink)
    }