fn user_namespace_follows_inode_type_and_dac() {
    let name = XattrName::new(b"user.test".to_vec()).unwrap();
    let owner = Cred::new(1000, 1000);
    let other = Cred::new(2000, 2000);
    let regular = inode(NodeType::RegularFile, 0o600, 1000);
    assert_eq!(
        check_xattr_permission(&regular, &name, XattrAccess::Write, &owner),
        Ok(())
    );
    assert!(matches!(
        check_xattr_permission(&regular, &name, XattrAccess::Read, &other),
        Err(err) if LinuxError::from(err) == LinuxError::EACCES
    ));

    let group_or_other_writable = inode(NodeType::RegularFile, 0o666, 1000);
    assert_eq!(
        check_xattr_permission(&group_or_other_writable, &name, XattrAccess::Write, &other),
        Ok(())
    );

    let socket = inode(NodeType::Socket, 0o600, 1000);
    assert_eq!(
        check_xattr_permission(&socket, &name, XattrAccess::Write, &owner),
        Ok(())
    );

    let symlink = inode(NodeType::Symlink, 0o777, 1000);
    assert!(matches!(
        check_xattr_permission(&symlink, &name, XattrAccess::Write, &owner),
        Err(err) if LinuxError::from(err) == LinuxError::EPERM
    ));
    assert!(matches!(
        check_xattr_permission(&symlink, &name, XattrAccess::Read, &owner),
        Err(err) if LinuxError::from(err) == LinuxError::ENODATA
    ));
}