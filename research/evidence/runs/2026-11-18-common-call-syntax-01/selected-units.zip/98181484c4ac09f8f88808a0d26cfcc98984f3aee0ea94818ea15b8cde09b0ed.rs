fn simple_rename_exchange(
    old_dir: &VfsInode,
    old_dentry: &Dentry,
    new_dir: &VfsInode,
    new_dentry: &Dentry,
) -> VfsResult<()> {
    let old_is_dir = old_dentry.is_dir();
    let new_is_dir = new_dentry.is_dir();

    if !ptr::eq(old_dir, new_dir) && old_is_dir != new_is_dir {
        if old_is_dir {
            old_dir.decrement_link_count();
            new_dir.increment_link_count();
        } else {
            new_dir.decrement_link_count();
            old_dir.increment_link_count();
        }
    }
    simple_rename_timestamp(old_dir, old_dentry, new_dir, new_dentry);
    Ok(())
}