fn captured_poll_source_filters_cancels_and_expires() {
    let default = sync_test_file(Arc::new(EmptyFileOperations), FMode::READ);
    assert!(default.capture_poll_source().unwrap().is_none());
    let ops = Arc::new(PollCaptureOperations(kpoll::PollSet::new()));
    let file = sync_test_file(ops.clone(), FMode::READ);
    let captured = file.capture_poll_source().unwrap().unwrap();
    let context = core::task::Context::from_waker(core::task::Waker::noop());
    let mut registrations = kpoll::PollRegistrations::new();
    captured
        .register(&mut registrations.context(&context), IoEvents::OUT)
        .unwrap();
    assert!(registrations.is_empty());
    captured
        .register(&mut registrations.context(&context), IoEvents::IN)
        .unwrap();
    assert_eq!(registrations.len(), 1);
    registrations.clear();
    assert_eq!(ops.0.wake(), 0);
    captured
        .register(&mut registrations.context(&context), IoEvents::IN)
        .unwrap();
    assert_eq!(ops.0.wake(), 1);
    drop(file);
    drop(ops);
    captured
        .register(&mut registrations.context(&context), IoEvents::IN)
        .unwrap();
    assert!(registrations.is_empty());
}