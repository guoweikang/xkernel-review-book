fn record_lock_split_merge_and_failed_upgrade() {
    let context = FileLockContext::new();
    let owner = FileLockOwner::Posix(1);
    let second = FileLockOwner::Posix(2);
    context
        .apply(
            &FileLock::new(owner, 1, FileLockType::Write, 0, 100).unwrap(),
            false,
        )
        .unwrap();
    context
        .apply(
            &FileLock::new(owner, 1, FileLockType::Unlock, 20, 20).unwrap(),
            false,
        )
        .unwrap();
    let ranges = context
        .state
        .lock()
        .posix
        .iter()
        .map(|lock| (lock.start(), lock.end()))
        .collect::<Vec<_>>();
    assert_eq!(ranges, [(0, 19), (40, 99)]);
    context
        .apply(
            &FileLock::new(owner, 1, FileLockType::Write, 20, 20).unwrap(),
            false,
        )
        .unwrap();
    assert_eq!(context.state.lock().posix.iter().count(), 1);
    context
        .apply(
            &FileLock::new(owner, 1, FileLockType::Read, 0, 100).unwrap(),
            false,
        )
        .unwrap();
    context
        .apply(
            &FileLock::new(second, 2, FileLockType::Read, 0, 100).unwrap(),
            false,
        )
        .unwrap();
    assert_eq!(
        context.apply(
            &FileLock::new(owner, 1, FileLockType::Write, 0, 100).unwrap(),
            false
        ),
        Err(KError::WouldBlock)
    );
    assert!(
        context
            .state
            .lock()
            .posix
            .iter()
            .all(|lock| lock.kind == FileLockType::Read)
    );
}