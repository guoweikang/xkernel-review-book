fn sget_dev_reuses_identity_and_rejects_readonly_mismatch() {
    FILL_COUNT.store(0, Ordering::Relaxed);
    let (disk, block_device) = add_test_disk("kvfs-sget-test", 246);
    let registry = super_block_registry();

    let first = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device.clone(),
            SuperBlockFlags::empty(),
            fill_test_bdev,
        )
        .expect("first mount initializes the device superblock");
    let second = registry
        .get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device.clone(),
            SuperBlockFlags::empty(),
            fill_test_bdev,
        )
        .expect("second mount reuses the device superblock");

    assert!(Arc::ptr_eq(&first, &second));
    assert_eq!(FILL_COUNT.load(Ordering::Relaxed), 1);
    first.activate_mount();
    // Linux `get_tree_bdev()` refuses to change an extant superblock's RO
    // state in either direction, so a read-only request over the live
    // writable superblock is EBUSY (`ResourceBusy`).
    assert!(matches!(
        registry.get_or_try_init_bdev(
            &BDEV_TEST_FILE_SYSTEM_TYPE,
            block_device,
            SuperBlockFlags::RDONLY,
            fill_test_bdev,
        ),
        Err(VfsError::ResourceBusy)
    ));
    assert_eq!(FILL_COUNT.load(Ordering::Relaxed), 1);

    first.deactivate_mount();
    drop(second);
    block::del_gendisk(disk.device_number()).expect("remove sget test disk");
}