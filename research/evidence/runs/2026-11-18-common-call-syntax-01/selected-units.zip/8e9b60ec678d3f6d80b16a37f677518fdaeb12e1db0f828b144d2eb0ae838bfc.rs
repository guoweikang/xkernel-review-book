fn writepages(&self, mapping: &AddressSpace, control: &mut WritebackControl) -> VfsResult<()> {
        mapping.writeback_cached_ranges(control, PAGE_SIZE_4K * 2, |offset, data| {
            let start = usize::try_from(offset).map_err(|_| (0, VfsError::InvalidInput))?;
            let end = start
                .checked_add(data.len())
                .ok_or((0, VfsError::InvalidInput))?;
            let mut state = self.state.lock();
            if state.durable.len() < end {
                state.durable.resize(end, 0);
            }
            state.calls += 1;
            if state.fail_once {
                let prefix = data.len() / 2;
                state.durable[start..start + prefix].copy_from_slice(&data[..prefix]);
                state.fail_once = false;
                return Err((prefix, VfsError::InvalidInput));
            }
            state.durable[start..end].copy_from_slice(data);
            Ok(data.len())
        })
    }