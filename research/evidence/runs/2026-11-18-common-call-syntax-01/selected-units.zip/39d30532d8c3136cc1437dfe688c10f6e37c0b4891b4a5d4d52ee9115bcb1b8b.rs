fn assert_other_metadata_unchanged(actual: &Metadata, cached: &Metadata) -> TestResult {
    assert_eq!(actual.device, cached.device);
    assert_eq!(actual.inode, cached.inode);
    assert_eq!(actual.mode, cached.mode);
    assert_eq!(actual.uid, cached.uid);
    assert_eq!(actual.gid, cached.gid);
    assert_eq!(actual.size, cached.size);
    // getattr uses the node's block_size (0 for this directory), whereas
    // metadata() reconstructs 1 << block_bits (1). Compare only same-source
    // fields here; their pre-existing normalization difference is unrelated
    // to the dynamic link-count callback.
    assert_eq!(actual.blocks, cached.blocks);
    assert_eq!(actual.rdev, cached.rdev);
    assert_eq!(actual.atime, cached.atime);
    assert_eq!(actual.mtime, cached.mtime);
    assert_eq!(actual.ctime, cached.ctime);
    TestResult::Ok
}