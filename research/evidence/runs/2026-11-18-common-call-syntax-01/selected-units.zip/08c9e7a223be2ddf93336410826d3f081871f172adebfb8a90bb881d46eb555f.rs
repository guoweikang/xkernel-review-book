fn eq(&self, other: &Self) -> bool {
        self.name == other.name
            && match (&self.parent, &other.parent) {
                (Some(parent), Some(other_parent)) => Weak::ptr_eq(parent, other_parent),
                (None, None) => true,
                _ => false,
            }
    }