fn test_stat_rdonly_combined_with_mount_rdonly_is_readonly() {
    let fs = mock_filesystem(StatFsFlags::RDONLY);
    let mount = Mount::new_root_with_flags(&fs, MountFlags::RDONLY);
    let root = mount.root_path();

    assert!(mount.is_readonly());
    assert!(root.is_effectively_readonly());
    assert_eq!(
        root.check_writable_mount(),
        Err(VfsError::ReadOnlyFilesystem)
    );
}