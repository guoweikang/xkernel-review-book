fn writeback_inode_metadata(&self, inodes: &[Arc<VfsInode>], data_only: bool) -> VfsResult<()> {
        let mut control = WritebackControl::all(data_only);
        for inode in inodes {
            self.ops().write_inode(inode.as_ref(), &mut control)?;
        }
        Ok(())
    }