fn try_new_with_flags<E>(
        file_system_type: &'static FileSystemType,
        ops: &'static dyn SuperBlockOperations,
        flags: SuperBlockFlags,
        init_root_fn: impl FnOnce(&Arc<Self>) -> Result<Dentry, E>,
    ) -> Result<Arc<Self>, E> {
        let super_block = Self::allocate(file_system_type, None, flags);
        super_block.initialize(ops, 1, MAX_LFS_FILESIZE, init_root_fn)?;
        super_block.finish_initialization();
        super_block_registry().register(&super_block);
        Ok(super_block)
    }