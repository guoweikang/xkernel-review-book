fn test_inode_times_returns_seeded_timestamps() {
    let fs = mock_filesystem(StatFsFlags::empty());
    let root = Mount::new_root(&fs).root_path();

    let accessed_at = SystemTime::from_unix_parts(11, 111).unwrap();
    let modified_at = SystemTime::from_unix_parts(12, 222).unwrap();
    let changed_at = SystemTime::from_unix_parts(13, 333).unwrap();

    let inode = root.inode();
    inode.set_accessed_at(accessed_at);
    inode.set_modified_at(modified_at);
    inode.set_changed_at(changed_at);

    let times = inode.times();
    assert_eq!(times.accessed_at, accessed_at);
    assert_eq!(times.modified_at, modified_at);
    assert_eq!(times.changed_at, changed_at);
}