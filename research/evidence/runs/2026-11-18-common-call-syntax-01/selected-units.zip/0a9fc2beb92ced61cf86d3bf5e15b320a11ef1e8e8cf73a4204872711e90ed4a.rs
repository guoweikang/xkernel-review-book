fn execute_with_parents_locked<F>(
        &self,
        old_dir_inode: &Arc<VfsInode>,
        new_dir_inode: &Arc<VfsInode>,
        is_cross_directory: bool,
        trap: Option<&Dentry>,
        may_rename_fn: F,
    ) -> VfsResult<()>
    where
        F: FnOnce(&Dentry, &Dentry) -> VfsResult<()>,
    {
        let source = self
            .old_parent
            .lookup_positive_locked(old_dir_inode, self.old_name)?;
        let target = self
            .new_parent
            .lookup_locked(new_dir_inode, self.new_name)?;
        if target.is_negative() && self.flags.contains(RenameFlags::EXCHANGE) {
            return Err(VfsError::NotFound);
        }
        if target.is_really_positive() && self.flags.contains(RenameFlags::NOREPLACE) {
            return Err(VfsError::AlreadyExists);
        }

        self.validate_topology(&source, &target, trap)?;
        if target.is_really_positive() && source.is_same_inode(&target) {
            return Ok(());
        }

        let is_exchange = self.flags.contains(RenameFlags::EXCHANGE);
        let target_is_positive = target.is_really_positive();
        let target_is_directory = target_is_positive && target.is_dir();
        let source_inode = source.vfs_inode();
        let target_inode = target_is_positive.then(|| target.vfs_inode());
        let is_parent_inode = |inode: &Arc<VfsInode>| {
            Arc::ptr_eq(inode, old_dir_inode) || Arc::ptr_eq(inode, new_dir_inode)
        };
        let (first_participant, second_participant) = match (source.is_dir(), target_is_directory) {
            (true, _) => {
                let source_participant = if is_cross_directory && !is_parent_inode(&source_inode) {
                    Some(source_inode)
                } else {
                    None
                };
                let should_lock_target = target_is_positive
                    && (!target_is_directory || is_cross_directory || !is_exchange);
                let target_participant =
                    target_inode.filter(|inode| should_lock_target && !is_parent_inode(inode));
                (source_participant, target_participant)
            }
            (false, true) => {
                let target_participant = target_inode.filter(|inode| {
                    (is_cross_directory || !is_exchange) && !is_parent_inode(inode)
                });
                (target_participant, Some(source_inode))
            }
            (false, false) => match target_inode {
                None => (Some(source_inode), None),
                Some(target_inode) if Arc::ptr_eq(&source_inode, &target_inode) => {
                    (Some(source_inode), None)
                }
                Some(target_inode) if Arc::as_ptr(&source_inode) < Arc::as_ptr(&target_inode) => {
                    (Some(source_inode), Some(target_inode))
                }
                Some(target_inode) => (Some(target_inode), Some(source_inode)),
            },
        };
        let _first_guard = first_participant
            .as_ref()
            .map(|inode| inode.lock_namespace_exclusive());
        let _second_guard = second_participant
            .as_ref()
            .map(|inode| inode.lock_namespace_exclusive());
        self.execute_locked(
            old_dir_inode,
            new_dir_inode,
            &source,
            &target,
            may_rename_fn,
        )
    }