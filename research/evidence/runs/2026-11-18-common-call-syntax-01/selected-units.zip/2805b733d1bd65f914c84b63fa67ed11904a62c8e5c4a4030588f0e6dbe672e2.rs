fn remove_cache_entry(&self, name: &str) -> Option<Dentry> {
        let entry = self
            .0
            .children
            .lock()
            .remove(name)
            .and_then(|entry| entry.upgrade().map(Dentry));
        if let Some(entry) = &entry
            && let Some(super_block) = entry.super_block()
        {
            super_block.uncache_dentry(entry);
        }
        entry
    }