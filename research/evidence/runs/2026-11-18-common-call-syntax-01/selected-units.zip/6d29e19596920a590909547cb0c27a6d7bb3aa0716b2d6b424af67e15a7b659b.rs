fn alloc() -> Arc<Self> {
        Arc::new(Self {
            state: crate::Mutex::new(PipeState {
                buffer: VecDeque::with_capacity(RING_BUFFER_INIT_SIZE),
                capacity: RING_BUFFER_INIT_SIZE,
                files: 0,
                readers: 0,
                writers: 0,
                // Match Linux `pipe_inode_info`: an uninitialized `file::f_pipe`
                // snapshot is zero, so both connection counters start at one.
                r_counter: 1,
                w_counter: 1,
            }),
            rd_wait: PollSet::new(),
            wr_wait: PollSet::new(),
        })
    }