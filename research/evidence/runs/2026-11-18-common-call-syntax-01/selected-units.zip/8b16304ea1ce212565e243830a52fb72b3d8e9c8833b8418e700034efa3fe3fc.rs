fn path_init(&mut self, base: &Path) {
        self.pathname = self.name.as_pathname().as_str();
        self.state |= ND_ROOT_PRESET;
        let starts_at_root = self.pathname.starts_with('/') && self.state & ND_ROOT_PRESET != 0;
        let starts_at_base = self.dfd == AT_FDCWD || !starts_at_root;
        self.path = if starts_at_root {
            self.root.clone()
        } else if starts_at_base {
            base.clone()
        } else {
            self.path.clone()
        };
        self.inode = Some(d_inode(self.path.dentry()).clone());
    }