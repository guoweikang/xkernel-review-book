fn read_folio(&self, mapping: &AddressSpace, mut folio: FolioRead) -> VfsResult<()> {
        // Model an old-EOF read finishing while a write publishes a larger
        // size. The filesystem has initialized both the data and zero tail.
        folio.data().fill(0);
        folio.data()[..17].fill(0x6b);
        mapping.write_end_set_size(PAGE_SIZE_4K as u64)?;
        folio.complete(Ok(()))
    }