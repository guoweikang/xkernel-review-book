fn file_wait_rechecks_readiness_published_while_registering() {
    let _cleanup = InterruptCleanup;
    ktask::current().clear_interrupt();
    let input = Input::new();
    input.publish_on_register.set(true);
    let mut wait = Box::pin(poll_file_io(&input, IoEvents::IN, false, || input.read()));
    let mut cx = Context::from_waker(Waker::noop());
    // No wake is sent: only the post-registration recheck can see the data.
    assert_eq!(wait.as_mut().poll(&mut cx), Poll::Ready(Ok(11)));
    assert_eq!(input.value.get(), 0);
}