fn verify_io_area(&self, pos: u64, count: usize) -> VfsResult<()> {
        if count > isize::MAX as usize {
            return Err(VfsError::InvalidInput);
        }
        let count = u64::try_from(count).map_err(|_| VfsError::InvalidInput)?;
        pos.checked_add(count).ok_or(VfsError::InvalidInput)?;
        if self.inode().node_type() == NodeType::Directory {
            return Err(VfsError::IsADirectory);
        }
        Ok(())
    }