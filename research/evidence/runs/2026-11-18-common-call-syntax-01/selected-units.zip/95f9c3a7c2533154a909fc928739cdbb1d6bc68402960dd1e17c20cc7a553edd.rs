fn read(&self, _: &VfsFile, buf: &mut [u8], _: u64) -> VfsResult<usize> {
        if self.0.fetch_add(1, Ordering::Relaxed) != 0 {
            return Err(VfsError::IoWaitInterrupted);
        }
        buf.fill(0x37);
        Ok(buf.len())
    }