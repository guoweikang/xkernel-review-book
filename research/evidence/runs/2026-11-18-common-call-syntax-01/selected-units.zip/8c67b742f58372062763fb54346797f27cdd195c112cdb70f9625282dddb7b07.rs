fn for_inode(inode: &VfsInode) -> Self {
        if inode.node_type() == NodeType::Directory {
            return if inode.supports_directory_operations() {
                Self::DIRECTORY_TYPE
            } else {
                Self::AUTODIR_TYPE
            };
        }

        if inode.supports_symlink_operations() {
            return Self::SYMLINK_TYPE;
        }

        match inode.node_type() {
            NodeType::RegularFile => Self::REGULAR_TYPE,
            _ => Self::SPECIAL_TYPE,
        }
    }