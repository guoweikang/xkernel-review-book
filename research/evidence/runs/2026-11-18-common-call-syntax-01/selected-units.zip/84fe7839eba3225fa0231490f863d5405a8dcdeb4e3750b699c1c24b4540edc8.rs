fn create_inode_child(
        &self,
        lookup: SimpleDirLookup<'_>,
        name: &str,
        inode: Arc<VfsInode>,
    ) -> VfsResult<Dentry> {
        let mut entries = self.entries.lock();
        if entries.contains_key(name) {
            return Err(VfsError::AlreadyExists);
        }

        let stored_inode = inode.clone();
        entries.insert(
            name.to_owned(),
            Arc::new(move |parent, name| {
                Ok(Dentry::new_file_from_inode(
                    stored_inode.clone(),
                    parent,
                    name.to_owned(),
                ))
            }),
        );
        Ok(lookup.file_from_inode(name, inode))
    }