fn new_regular_with_type(
        fs: Arc<SimpleFs>,
        ty: NodeType,
        permission: NodePermission,
        ops: impl SimpleFileOps,
    ) -> Arc<Self> {
        let ops: Arc<dyn SimpleFileOps> = Arc::new(ops);
        Self::new_with_options(
            fs,
            ty,
            permission,
            ops.clone(),
            Arc::new(GeneratedFileOperations(ops)),
        )
    }