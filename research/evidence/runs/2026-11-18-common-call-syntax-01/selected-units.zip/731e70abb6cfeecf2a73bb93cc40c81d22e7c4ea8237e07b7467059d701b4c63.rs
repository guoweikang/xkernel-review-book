fn pseudo_fs_root_dentry() -> Dentry {
    let timestamp = ktime::realtime();
    let init = VfsInodeInit::new(
        PSEUDO_FS_ROOT_INO,
        0,
        Umode::new(
            NodeType::Directory,
            NodePermission::OWNER_READ | NodePermission::OWNER_WRITE,
        ),
    )
    .with_owner_links_and_rdev(0, 0, 1, Default::default())
    .with_stat_data(PAGE_SIZE_4K as u64, 0, timestamp, timestamp, timestamp);
    let inode = VfsInode::new_dir_with_defaults(NodeFlags::PRIVATE, init);
    Dentry::new_dir_from_inode(inode, None, String::new())
}