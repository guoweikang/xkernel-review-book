fn block_empty_eof_and_capacity_clipping_do_not_touch_outside_view() {
    use core::sync::atomic::Ordering::Relaxed;
    let fixture = BlockIoFixture::new(512);
    fixture.device.set_capacity(4).unwrap();
    for offset in [0, 2048, u64::MAX] {
        assert_eq!(
            read_block_device(&fixture.device, &mut [], offset).unwrap(),
            0
        );
        assert_eq!(write_block_device(&fixture.device, &[], offset).unwrap(), 0);
    }
    for offset in [2048, 2049, u64::MAX] {
        assert_eq!(
            read_block_device(&fixture.device, &mut [0; 512], offset).unwrap(),
            0
        );
        assert_eq!(
            write_block_device(&fixture.device, &[1; 512], offset).unwrap_err(),
            KError::StorageFull
        );
    }
    assert_eq!(fixture.backend.reads.load(Relaxed), 0);
    assert_eq!(fixture.backend.writes.load(Relaxed), 0);
    let mut output = vec![0xa9; 2048];
    assert_eq!(
        read_block_device(&fixture.device, &mut output, 1024).unwrap(),
        1024
    );
    assert!(output[..1024].iter().all(|&b| b == 0x35));
    assert!(output[1024..].iter().all(|&b| b == 0xa9));
    assert_eq!(
        write_block_device(&fixture.device, &[0x71; 2048], 1024).unwrap(),
        1024
    );
    assert!(
        fixture.backend.storage.lock()[2048..]
            .iter()
            .all(|&b| b == 0x35)
    );
    assert_eq!(fixture.backend.reads.load(Relaxed), 1);
    assert_eq!(fixture.backend.writes.load(Relaxed), 1);
    fixture.device.set_disk_read_only(true).unwrap();
    assert_eq!(write_block_device(&fixture.device, &[], 0).unwrap(), 0);
    assert_eq!(
        write_block_device(&fixture.device, &[0; 1024], 0).unwrap_err(),
        KError::OperationNotPermitted
    );
    assert_eq!(fixture.backend.writes.load(Relaxed), 1);
}