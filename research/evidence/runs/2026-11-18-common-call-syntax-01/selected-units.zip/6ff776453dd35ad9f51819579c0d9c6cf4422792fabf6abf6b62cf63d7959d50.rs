fn unsized_types() {
    let mutex: &TestMutex<[i32]> = &TestMutex::new([1, 2, 3]);
    {
        let mut b = mutex.lock();
        b[0] = 4;
        b[2] = 5;
    }
    let expected: &[i32] = &[4, 2, 5];
    assert_eq!(&*mutex.lock(), expected);
}